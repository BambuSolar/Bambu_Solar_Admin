/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang("placeholder","ko",{title:"플레이스홀더 속성",toolbar:"플레이스홀더",name:"플레이스홀더 이름",invalidName:"플레이스홀더는 빈칸이거나 다음 문자열을 포함할 수 없습니다: [, ], \x3c, \x3e",pathName:"플레이스홀더"});
