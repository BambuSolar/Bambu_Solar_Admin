CKEDITOR.plugins.setLang("font","de",{fontSize:{label:"Größe",voiceLabel:"Schrifgröße",panelTitle:"Schriftgröße"},label:"Schriftart",panelTitle:"Schriftartname",voiceLabel:"Schriftart"});
