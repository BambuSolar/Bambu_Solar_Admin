CKEDITOR.plugins.setLang("font","ar",{fontSize:{label:"حجم الخط",voiceLabel:"حجم الخط",panelTitle:"حجم الخط"},label:"خط",panelTitle:"حجم الخط",voiceLabel:"حجم الخط"});
