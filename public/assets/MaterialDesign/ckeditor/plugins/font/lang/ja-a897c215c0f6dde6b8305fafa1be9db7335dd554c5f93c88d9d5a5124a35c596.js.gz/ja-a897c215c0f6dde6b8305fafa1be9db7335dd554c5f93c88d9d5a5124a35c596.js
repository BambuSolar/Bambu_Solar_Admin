CKEDITOR.plugins.setLang("font","ja",{fontSize:{label:"サイズ",voiceLabel:"フォントサイズ",panelTitle:"フォントサイズ"},label:"フォント",panelTitle:"フォント",voiceLabel:"フォント"});
