CKEDITOR.plugins.setLang("font","pt-br",{fontSize:{label:"Tamanho",voiceLabel:"Tamanho da fonte",panelTitle:"Tamanho"},label:"Fonte",panelTitle:"Fonte",voiceLabel:"Fonte"});
