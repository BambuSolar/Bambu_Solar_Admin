CKEDITOR.plugins.setLang("font","nl",{fontSize:{label:"Lettergrootte",voiceLabel:"Lettergrootte",panelTitle:"Lettergrootte"},label:"Lettertype",panelTitle:"Lettertype",voiceLabel:"Lettertype"});
