CKEDITOR.plugins.setLang("font","tt",{fontSize:{label:"Зурлык",voiceLabel:"Шрифт зурлыклары",panelTitle:"Шрифт зурлыклары"},label:"Шрифт",panelTitle:"Шрифт исеме",voiceLabel:"Шрифт"});
