CKEDITOR.plugins.setLang("font","he",{fontSize:{label:"גודל",voiceLabel:"גודל",panelTitle:"גודל"},label:"גופן",panelTitle:"גופן",voiceLabel:"גופן"});
