CKEDITOR.plugins.setLang("font","en-gb",{fontSize:{label:"Size",voiceLabel:"Font Size",panelTitle:"Font Size"},label:"Font",panelTitle:"Font Name",voiceLabel:"Font"});
