CKEDITOR.plugins.setLang("font","tr",{fontSize:{label:"Boyut",voiceLabel:"Font Size",panelTitle:"Boyut"},label:"Yazı Türü",panelTitle:"Yazı Türü",voiceLabel:"Font"});
