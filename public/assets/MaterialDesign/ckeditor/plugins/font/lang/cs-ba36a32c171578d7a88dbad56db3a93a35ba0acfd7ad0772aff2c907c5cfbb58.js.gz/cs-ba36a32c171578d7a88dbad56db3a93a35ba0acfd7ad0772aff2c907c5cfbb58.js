CKEDITOR.plugins.setLang("font","cs",{fontSize:{label:"Velikost",voiceLabel:"Velikost písma",panelTitle:"Velikost"},label:"Písmo",panelTitle:"Písmo",voiceLabel:"Písmo"});
