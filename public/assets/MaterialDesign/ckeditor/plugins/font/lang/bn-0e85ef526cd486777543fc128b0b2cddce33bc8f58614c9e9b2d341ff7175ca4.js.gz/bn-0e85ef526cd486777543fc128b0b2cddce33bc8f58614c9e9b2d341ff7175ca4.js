CKEDITOR.plugins.setLang("font","bn",{fontSize:{label:"সাইজ",voiceLabel:"Font Size",panelTitle:"সাইজ"},label:"ফন্ট",panelTitle:"ফন্ট",voiceLabel:"ফন্ট"});
