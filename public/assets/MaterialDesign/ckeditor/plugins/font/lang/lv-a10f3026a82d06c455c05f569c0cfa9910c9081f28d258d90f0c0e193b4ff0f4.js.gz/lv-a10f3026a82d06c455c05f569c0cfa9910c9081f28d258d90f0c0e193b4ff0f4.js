CKEDITOR.plugins.setLang("font","lv",{fontSize:{label:"Izmērs",voiceLabel:"Fonta izmeŗs",panelTitle:"Izmērs"},label:"Šrifts",panelTitle:"Šrifts",voiceLabel:"Fonts"});
