CKEDITOR.plugins.setLang("font","bs",{fontSize:{label:"Velièina",voiceLabel:"Font Size",panelTitle:"Velièina"},label:"Font",panelTitle:"Font",voiceLabel:"Font"});
