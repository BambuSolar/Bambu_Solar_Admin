CKEDITOR.plugins.setLang("font","sr",{fontSize:{label:"Величина фонта",voiceLabel:"Font Size",panelTitle:"Величина фонта"},label:"Фонт",panelTitle:"Фонт",voiceLabel:"Фонт"});
