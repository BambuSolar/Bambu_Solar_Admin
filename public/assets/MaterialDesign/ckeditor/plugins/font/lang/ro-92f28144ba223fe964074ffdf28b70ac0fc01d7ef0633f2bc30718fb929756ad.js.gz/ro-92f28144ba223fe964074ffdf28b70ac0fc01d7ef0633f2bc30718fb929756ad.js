CKEDITOR.plugins.setLang("font","ro",{fontSize:{label:"Mărime",voiceLabel:"Font Size",panelTitle:"Mărime"},label:"Font",panelTitle:"Font",voiceLabel:"Font"});
