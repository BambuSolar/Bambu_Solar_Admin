CKEDITOR.plugins.setLang("font","ms",{fontSize:{label:"Saiz",voiceLabel:"Font Size",panelTitle:"Saiz"},label:"Font",panelTitle:"Font",voiceLabel:"Font"});
