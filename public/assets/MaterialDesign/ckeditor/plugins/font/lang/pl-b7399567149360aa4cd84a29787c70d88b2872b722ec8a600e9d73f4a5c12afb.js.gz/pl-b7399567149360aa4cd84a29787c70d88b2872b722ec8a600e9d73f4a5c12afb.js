CKEDITOR.plugins.setLang("font","pl",{fontSize:{label:"Rozmiar",voiceLabel:"Rozmiar czcionki",panelTitle:"Rozmiar"},label:"Czcionka",panelTitle:"Czcionka",voiceLabel:"Czcionka"});
