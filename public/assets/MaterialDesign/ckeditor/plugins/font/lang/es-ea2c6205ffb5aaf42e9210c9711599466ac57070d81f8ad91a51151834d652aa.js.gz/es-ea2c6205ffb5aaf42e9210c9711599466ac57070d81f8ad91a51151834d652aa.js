CKEDITOR.plugins.setLang("font","es",{fontSize:{label:"Tamaño",voiceLabel:"Tamaño de fuente",panelTitle:"Tamaño"},label:"Fuente",panelTitle:"Fuente",voiceLabel:"Fuente"});
