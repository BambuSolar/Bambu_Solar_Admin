CKEDITOR.plugins.setLang("font","fr-ca",{fontSize:{label:"Taille",voiceLabel:"Taille",panelTitle:"Taille"},label:"Police",panelTitle:"Police",voiceLabel:"Police"});
