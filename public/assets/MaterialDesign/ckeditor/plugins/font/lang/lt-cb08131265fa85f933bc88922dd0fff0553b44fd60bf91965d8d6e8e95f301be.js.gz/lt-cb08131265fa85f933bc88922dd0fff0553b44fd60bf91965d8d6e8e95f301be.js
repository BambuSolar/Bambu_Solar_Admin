CKEDITOR.plugins.setLang("font","lt",{fontSize:{label:"Šrifto dydis",voiceLabel:"Šrifto dydis",panelTitle:"Šrifto dydis"},label:"Šriftas",panelTitle:"Šriftas",voiceLabel:"Šriftas"});
