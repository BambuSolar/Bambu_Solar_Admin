CKEDITOR.plugins.setLang("font","de-ch",{fontSize:{label:"Grösse",voiceLabel:"Schrifgrösse",panelTitle:"Schriftgrösse"},label:"Schriftart",panelTitle:"Schriftartname",voiceLabel:"Schriftart"});
