CKEDITOR.plugins.setLang("font","fi",{fontSize:{label:"Koko",voiceLabel:"Kirjaisimen koko",panelTitle:"Koko"},label:"Kirjaisinlaji",panelTitle:"Kirjaisinlaji",voiceLabel:"Kirjaisinlaji"});
