CKEDITOR.plugins.setLang("font","id",{fontSize:{label:"Ukuran",voiceLabel:"Ukuran Huruf",panelTitle:"Ukuran Huruf"},label:"Huruf",panelTitle:"Font Name",voiceLabel:"Huruf"});
