CKEDITOR.plugins.setLang("font","ru",{fontSize:{label:"Размер",voiceLabel:"Размер шрифта",panelTitle:"Размер шрифта"},label:"Шрифт",panelTitle:"Шрифт",voiceLabel:"Шрифт"});
