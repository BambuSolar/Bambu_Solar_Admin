CKEDITOR.plugins.setLang("font","sv",{fontSize:{label:"Storlek",voiceLabel:"Teckenstorlek",panelTitle:"Teckenstorlek"},label:"Typsnitt",panelTitle:"Typsnitt",voiceLabel:"Typsnitt"});
