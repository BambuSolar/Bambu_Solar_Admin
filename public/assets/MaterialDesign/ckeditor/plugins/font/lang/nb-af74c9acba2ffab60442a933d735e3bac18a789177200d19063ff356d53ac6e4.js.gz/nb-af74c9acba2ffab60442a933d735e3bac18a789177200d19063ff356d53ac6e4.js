CKEDITOR.plugins.setLang("font","nb",{fontSize:{label:"Størrelse",voiceLabel:"Skriftstørrelse",panelTitle:"Skriftstørrelse"},label:"Skrift",panelTitle:"Skrift",voiceLabel:"Font"});
