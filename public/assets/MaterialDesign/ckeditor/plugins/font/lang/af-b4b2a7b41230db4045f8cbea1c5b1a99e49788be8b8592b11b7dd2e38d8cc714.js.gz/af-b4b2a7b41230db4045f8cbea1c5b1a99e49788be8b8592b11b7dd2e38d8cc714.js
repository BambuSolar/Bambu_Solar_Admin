CKEDITOR.plugins.setLang("font","af",{fontSize:{label:"Grootte",voiceLabel:"Fontgrootte",panelTitle:"Fontgrootte"},label:"Font",panelTitle:"Fontnaam",voiceLabel:"Font"});
