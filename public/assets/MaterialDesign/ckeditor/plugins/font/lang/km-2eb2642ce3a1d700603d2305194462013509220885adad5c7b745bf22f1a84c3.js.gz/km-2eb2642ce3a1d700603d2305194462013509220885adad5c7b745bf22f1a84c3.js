CKEDITOR.plugins.setLang("font","km",{fontSize:{label:"ទំហំ",voiceLabel:"ទំហំ​អក្សរ",panelTitle:"ទំហំ​អក្សរ"},label:"ពុម្ព​អក្សរ",panelTitle:"ឈ្មោះ​ពុម្ព​អក្សរ",voiceLabel:"ពុម្ព​អក្សរ"});
