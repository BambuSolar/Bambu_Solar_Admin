CKEDITOR.plugins.setLang("font","eo",{fontSize:{label:"Grado",voiceLabel:"Tipara grado",panelTitle:"Tipara grado"},label:"Tiparo",panelTitle:"Tipara nomo",voiceLabel:"Tiparo"});
