CKEDITOR.plugins.setLang("font","hr",{fontSize:{label:"Veličina",voiceLabel:"Veličina slova",panelTitle:"Veličina"},label:"Font",panelTitle:"Font",voiceLabel:"Font"});
