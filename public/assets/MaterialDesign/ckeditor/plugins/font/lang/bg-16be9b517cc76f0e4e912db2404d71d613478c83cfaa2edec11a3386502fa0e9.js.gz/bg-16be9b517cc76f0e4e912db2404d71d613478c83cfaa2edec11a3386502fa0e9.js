CKEDITOR.plugins.setLang("font","bg",{fontSize:{label:"Размер",voiceLabel:"Размер на шрифт",panelTitle:"Размер на шрифт"},label:"Шрифт",panelTitle:"Име на шрифт",voiceLabel:"Шрифт"});
