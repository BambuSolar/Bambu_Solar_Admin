CKEDITOR.plugins.setLang("font","sk",{fontSize:{label:"Veľkosť",voiceLabel:"Veľkosť písma",panelTitle:"Veľkosť písma"},label:"Písmo",panelTitle:"Názov písma",voiceLabel:"Písmo"});
