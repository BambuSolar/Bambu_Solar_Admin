CKEDITOR.plugins.setLang("font","it",{fontSize:{label:"Dimensione",voiceLabel:"Dimensione Carattere",panelTitle:"Dimensione"},label:"Carattere",panelTitle:"Carattere",voiceLabel:"Carattere"});
