CKEDITOR.plugins.setLang("font","ku",{fontSize:{label:"گەورەیی",voiceLabel:"گەورەیی فۆنت",panelTitle:"گەورەیی فۆنت"},label:"فۆنت",panelTitle:"ناوی فۆنت",voiceLabel:"فۆنت"});
