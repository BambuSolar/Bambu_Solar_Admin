CKEDITOR.plugins.setLang("font","ka",{fontSize:{label:"ზომა",voiceLabel:"ტექსტის ზომა",panelTitle:"ტექსტის ზომა"},label:"ფონტი",panelTitle:"ფონტის სახელი",voiceLabel:"ფონტი"});
