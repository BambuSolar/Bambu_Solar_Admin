CKEDITOR.plugins.setLang("font","fo",{fontSize:{label:"Skriftstødd",voiceLabel:"Skriftstødd",panelTitle:"Skriftstødd"},label:"Skrift",panelTitle:"Skrift",voiceLabel:"Skrift"});
