CKEDITOR.plugins.setLang("font","mk",{fontSize:{label:"Size",voiceLabel:"Font Size",panelTitle:"Font Size"},label:"Font",panelTitle:"Font Name",voiceLabel:"Font"});
