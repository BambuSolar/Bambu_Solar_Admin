CKEDITOR.plugins.setLang("font","et",{fontSize:{label:"Suurus",voiceLabel:"Kirja suurus",panelTitle:"Suurus"},label:"Kiri",panelTitle:"Kiri",voiceLabel:"Kiri"});
