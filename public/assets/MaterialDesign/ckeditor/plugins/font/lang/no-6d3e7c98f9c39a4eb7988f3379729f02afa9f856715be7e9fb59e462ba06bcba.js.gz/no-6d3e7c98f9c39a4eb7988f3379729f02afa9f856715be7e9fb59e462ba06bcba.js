CKEDITOR.plugins.setLang("font","no",{fontSize:{label:"Størrelse",voiceLabel:"Font Størrelse",panelTitle:"Størrelse"},label:"Skrift",panelTitle:"Skrift",voiceLabel:"Font"});
