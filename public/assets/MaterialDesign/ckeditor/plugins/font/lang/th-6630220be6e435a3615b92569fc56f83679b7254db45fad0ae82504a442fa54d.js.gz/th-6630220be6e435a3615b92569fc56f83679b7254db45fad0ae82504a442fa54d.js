CKEDITOR.plugins.setLang("font","th",{fontSize:{label:"ขนาด",voiceLabel:"Font Size",panelTitle:"ขนาด"},label:"แบบอักษร",panelTitle:"แบบอักษร",voiceLabel:"แบบอักษร"});
