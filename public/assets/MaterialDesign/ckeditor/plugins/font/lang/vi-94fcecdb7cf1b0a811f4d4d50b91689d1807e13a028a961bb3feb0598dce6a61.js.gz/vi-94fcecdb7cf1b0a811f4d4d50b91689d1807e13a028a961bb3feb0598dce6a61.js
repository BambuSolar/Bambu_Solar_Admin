CKEDITOR.plugins.setLang("font","vi",{fontSize:{label:"Cỡ chữ",voiceLabel:"Kích cỡ phông",panelTitle:"Cỡ chữ"},label:"Phông",panelTitle:"Phông",voiceLabel:"Phông"});
