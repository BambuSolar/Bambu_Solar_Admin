CKEDITOR.plugins.setLang("font","ug",{fontSize:{label:"چوڭلۇقى",voiceLabel:"خەت چوڭلۇقى",panelTitle:"چوڭلۇقى"},label:"خەت نۇسخا",panelTitle:"خەت نۇسخا",voiceLabel:"خەت نۇسخا"});
