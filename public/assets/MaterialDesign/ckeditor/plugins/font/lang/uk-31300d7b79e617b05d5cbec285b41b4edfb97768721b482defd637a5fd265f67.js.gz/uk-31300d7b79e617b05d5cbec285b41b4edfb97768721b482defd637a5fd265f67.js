CKEDITOR.plugins.setLang("font","uk",{fontSize:{label:"Розмір",voiceLabel:"Розмір шрифту",panelTitle:"Розмір"},label:"Шрифт",panelTitle:"Шрифт",voiceLabel:"Шрифт"});
