CKEDITOR.plugins.setLang("newpage","hi",{toolbar:"नया पेज"});
