CKEDITOR.plugins.setLang("newpage","bn",{toolbar:"নতুন পৃষ্ঠা"});
