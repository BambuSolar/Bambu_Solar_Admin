CKEDITOR.plugins.setLang("newpage","lt",{toolbar:"Naujas puslapis"});
