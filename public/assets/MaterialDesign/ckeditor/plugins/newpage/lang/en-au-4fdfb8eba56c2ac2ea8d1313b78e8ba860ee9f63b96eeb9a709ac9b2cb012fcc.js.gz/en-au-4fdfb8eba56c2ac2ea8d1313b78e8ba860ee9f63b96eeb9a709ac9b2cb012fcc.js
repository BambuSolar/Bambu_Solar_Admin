CKEDITOR.plugins.setLang("newpage","en-au",{toolbar:"New Page"});
