CKEDITOR.plugins.setLang("newpage","da",{toolbar:"Ny side"});
