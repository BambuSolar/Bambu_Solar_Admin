CKEDITOR.plugins.setLang("newpage","en",{toolbar:"New Page"});
