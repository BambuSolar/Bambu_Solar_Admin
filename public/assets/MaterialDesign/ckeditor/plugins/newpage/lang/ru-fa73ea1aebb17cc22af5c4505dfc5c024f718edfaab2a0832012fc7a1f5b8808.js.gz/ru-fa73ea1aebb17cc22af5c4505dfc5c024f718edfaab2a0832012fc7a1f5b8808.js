CKEDITOR.plugins.setLang("newpage","ru",{toolbar:"Новая страница"});
