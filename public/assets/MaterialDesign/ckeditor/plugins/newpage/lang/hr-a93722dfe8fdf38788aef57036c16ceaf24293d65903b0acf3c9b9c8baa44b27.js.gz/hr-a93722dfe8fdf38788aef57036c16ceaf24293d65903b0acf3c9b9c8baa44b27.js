CKEDITOR.plugins.setLang("newpage","hr",{toolbar:"Nova stranica"});
