CKEDITOR.plugins.setLang("newpage","fi",{toolbar:"Tyhjennä"});
