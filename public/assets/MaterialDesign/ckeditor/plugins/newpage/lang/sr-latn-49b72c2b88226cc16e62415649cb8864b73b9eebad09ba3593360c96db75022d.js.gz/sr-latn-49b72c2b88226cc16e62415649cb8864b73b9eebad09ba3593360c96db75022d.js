CKEDITOR.plugins.setLang("newpage","sr-latn",{toolbar:"Nova stranica"});
