CKEDITOR.plugins.setLang("newpage","mn",{toolbar:"Шинэ хуудас"});
