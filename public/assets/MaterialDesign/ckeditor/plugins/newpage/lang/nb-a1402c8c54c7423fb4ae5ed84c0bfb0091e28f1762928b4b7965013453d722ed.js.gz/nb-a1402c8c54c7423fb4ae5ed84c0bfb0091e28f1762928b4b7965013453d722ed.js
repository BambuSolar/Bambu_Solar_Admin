CKEDITOR.plugins.setLang("newpage","nb",{toolbar:"Ny side"});
