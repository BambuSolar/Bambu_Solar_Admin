CKEDITOR.plugins.setLang("newpage","sr",{toolbar:"Нова страница"});
