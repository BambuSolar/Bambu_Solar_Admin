CKEDITOR.plugins.setLang("newpage","zh-cn",{toolbar:"新建"});
