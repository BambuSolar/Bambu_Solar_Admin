CKEDITOR.plugins.setLang("newpage","th",{toolbar:"สร้างหน้าเอกสารใหม่"});
