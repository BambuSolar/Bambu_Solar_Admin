CKEDITOR.plugins.setLang("newpage","vi",{toolbar:"Trang mới"});
