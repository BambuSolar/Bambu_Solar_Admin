CKEDITOR.plugins.setLang("newpage","cy",{toolbar:"Tudalen Newydd"});
