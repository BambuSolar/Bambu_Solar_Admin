CKEDITOR.plugins.setLang("newpage","fr",{toolbar:"Nouvelle page"});
