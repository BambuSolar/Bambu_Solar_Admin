CKEDITOR.plugins.setLang("newpage","km",{toolbar:"ទំព័រ​ថ្មី"});
