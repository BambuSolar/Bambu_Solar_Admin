CKEDITOR.plugins.setLang("newpage","sk",{toolbar:"Nová stránka"});
