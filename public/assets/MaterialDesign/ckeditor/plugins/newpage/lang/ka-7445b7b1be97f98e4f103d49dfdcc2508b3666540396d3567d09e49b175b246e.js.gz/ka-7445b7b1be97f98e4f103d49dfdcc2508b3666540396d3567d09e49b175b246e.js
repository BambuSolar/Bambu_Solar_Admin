CKEDITOR.plugins.setLang("newpage","ka",{toolbar:"ახალი გვერდი"});
