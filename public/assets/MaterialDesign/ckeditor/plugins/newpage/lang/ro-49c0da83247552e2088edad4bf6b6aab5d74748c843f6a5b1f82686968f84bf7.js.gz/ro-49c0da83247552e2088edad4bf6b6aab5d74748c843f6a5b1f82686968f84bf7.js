CKEDITOR.plugins.setLang("newpage","ro",{toolbar:"Pagină nouă"});
