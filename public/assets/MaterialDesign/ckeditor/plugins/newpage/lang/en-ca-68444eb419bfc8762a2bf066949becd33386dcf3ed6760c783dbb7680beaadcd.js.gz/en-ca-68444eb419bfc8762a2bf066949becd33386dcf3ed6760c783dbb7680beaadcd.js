CKEDITOR.plugins.setLang("newpage","en-ca",{toolbar:"New Page"});
