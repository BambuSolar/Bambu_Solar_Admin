CKEDITOR.plugins.setLang("newpage","de-ch",{toolbar:"Neue Seite"});
