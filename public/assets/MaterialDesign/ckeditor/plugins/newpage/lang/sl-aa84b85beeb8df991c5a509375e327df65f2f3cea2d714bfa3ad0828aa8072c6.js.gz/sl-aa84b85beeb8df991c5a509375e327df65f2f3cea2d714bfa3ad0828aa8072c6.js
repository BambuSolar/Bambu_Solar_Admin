CKEDITOR.plugins.setLang("newpage","sl",{toolbar:"Nova stran"});
