CKEDITOR.plugins.setLang("newpage","pt-br",{toolbar:"Novo"});
