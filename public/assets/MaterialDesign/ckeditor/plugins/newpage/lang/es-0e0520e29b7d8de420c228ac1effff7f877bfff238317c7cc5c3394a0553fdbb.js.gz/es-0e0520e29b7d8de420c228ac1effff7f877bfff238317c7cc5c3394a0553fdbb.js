CKEDITOR.plugins.setLang("newpage","es",{toolbar:"Nueva Página"});
