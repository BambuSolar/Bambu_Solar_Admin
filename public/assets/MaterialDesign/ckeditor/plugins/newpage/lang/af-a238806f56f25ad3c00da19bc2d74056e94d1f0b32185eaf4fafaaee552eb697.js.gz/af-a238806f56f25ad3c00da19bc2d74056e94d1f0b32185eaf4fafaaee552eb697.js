CKEDITOR.plugins.setLang("newpage","af",{toolbar:"Nuwe bladsy"});
