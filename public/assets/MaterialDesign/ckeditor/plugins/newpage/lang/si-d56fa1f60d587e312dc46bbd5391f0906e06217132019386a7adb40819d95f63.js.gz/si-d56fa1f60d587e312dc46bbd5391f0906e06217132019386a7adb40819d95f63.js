CKEDITOR.plugins.setLang("newpage","si",{toolbar:"නව පිටුවක්"});
