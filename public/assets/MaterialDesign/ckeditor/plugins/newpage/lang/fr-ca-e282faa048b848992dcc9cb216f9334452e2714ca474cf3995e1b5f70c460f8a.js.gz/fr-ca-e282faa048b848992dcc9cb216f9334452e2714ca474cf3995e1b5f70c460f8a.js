CKEDITOR.plugins.setLang("newpage","fr-ca",{toolbar:"Nouvelle page"});
