CKEDITOR.plugins.setLang("newpage","gl",{toolbar:"Páxina nova"});
