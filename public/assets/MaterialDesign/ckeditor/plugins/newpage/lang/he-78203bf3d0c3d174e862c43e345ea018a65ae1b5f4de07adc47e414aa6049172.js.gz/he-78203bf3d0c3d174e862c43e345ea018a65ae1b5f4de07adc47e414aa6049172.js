CKEDITOR.plugins.setLang("newpage","he",{toolbar:"דף חדש"});
