CKEDITOR.plugins.setLang("newpage","eu",{toolbar:"Orrialde berria"});
