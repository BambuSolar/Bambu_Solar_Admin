CKEDITOR.plugins.setLang("newpage","fa",{toolbar:"برگهٴ تازه"});
