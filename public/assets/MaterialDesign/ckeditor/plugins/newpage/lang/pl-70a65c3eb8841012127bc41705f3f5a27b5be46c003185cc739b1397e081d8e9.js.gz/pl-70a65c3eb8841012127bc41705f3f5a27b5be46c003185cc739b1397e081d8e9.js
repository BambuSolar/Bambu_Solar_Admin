CKEDITOR.plugins.setLang("newpage","pl",{toolbar:"Nowa strona"});
