CKEDITOR.plugins.setLang("newpage","ug",{toolbar:"يېڭى بەت"});
