CKEDITOR.plugins.setLang("newpage","tr",{toolbar:"Yeni Sayfa"});
