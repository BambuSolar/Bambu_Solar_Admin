CKEDITOR.plugins.setLang("newpage","zh",{toolbar:"新增網頁"});
