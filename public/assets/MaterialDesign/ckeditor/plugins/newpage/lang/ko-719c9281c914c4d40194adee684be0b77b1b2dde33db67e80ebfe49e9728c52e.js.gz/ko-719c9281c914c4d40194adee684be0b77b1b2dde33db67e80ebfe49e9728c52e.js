CKEDITOR.plugins.setLang("newpage","ko",{toolbar:"새 페이지"});
