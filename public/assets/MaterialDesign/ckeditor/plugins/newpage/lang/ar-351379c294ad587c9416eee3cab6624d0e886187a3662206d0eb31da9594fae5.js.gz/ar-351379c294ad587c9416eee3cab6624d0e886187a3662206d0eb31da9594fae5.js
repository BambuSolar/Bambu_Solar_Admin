CKEDITOR.plugins.setLang("newpage","ar",{toolbar:"صفحة جديدة"});
