CKEDITOR.plugins.setLang("newpage","hu",{toolbar:"Új oldal"});
