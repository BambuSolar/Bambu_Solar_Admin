CKEDITOR.plugins.setLang("newpage","bg",{toolbar:"Нова страница"});
