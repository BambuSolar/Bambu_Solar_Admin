CKEDITOR.plugins.setLang("newpage","pt",{toolbar:"Nova página"});
