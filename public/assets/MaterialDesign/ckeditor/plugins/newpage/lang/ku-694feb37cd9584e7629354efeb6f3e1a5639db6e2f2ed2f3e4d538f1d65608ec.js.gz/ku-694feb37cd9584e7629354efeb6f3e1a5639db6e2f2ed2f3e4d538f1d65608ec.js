CKEDITOR.plugins.setLang("newpage","ku",{toolbar:"پەڕەیەکی نوێ"});
