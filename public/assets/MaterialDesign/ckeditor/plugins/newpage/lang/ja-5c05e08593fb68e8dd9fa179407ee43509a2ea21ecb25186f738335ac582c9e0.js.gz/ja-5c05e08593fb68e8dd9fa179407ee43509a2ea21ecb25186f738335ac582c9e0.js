CKEDITOR.plugins.setLang("newpage","ja",{toolbar:"新しいページ"});
