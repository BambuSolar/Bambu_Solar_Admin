CKEDITOR.plugins.setLang("newpage","gu",{toolbar:"નવુ પાનું"});
