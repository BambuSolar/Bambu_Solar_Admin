CKEDITOR.plugins.setLang("newpage","is",{toolbar:"Ný síða"});
