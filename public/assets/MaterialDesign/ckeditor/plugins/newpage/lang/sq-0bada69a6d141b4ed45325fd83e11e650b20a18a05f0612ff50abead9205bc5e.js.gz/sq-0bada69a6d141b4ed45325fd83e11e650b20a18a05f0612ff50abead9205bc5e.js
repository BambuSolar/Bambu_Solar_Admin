CKEDITOR.plugins.setLang("newpage","sq",{toolbar:"Faqe e Re"});
