CKEDITOR.plugins.setLang("newpage","tt",{toolbar:"Яңа бит"});
