CKEDITOR.plugins.setLang("newpage","ms",{toolbar:"Helaian Baru"});
