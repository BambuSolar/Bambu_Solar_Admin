CKEDITOR.plugins.setLang("newpage","no",{toolbar:"Ny side"});
