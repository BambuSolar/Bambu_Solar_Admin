CKEDITOR.plugins.setLang("newpage","uk",{toolbar:"Нова сторінка"});
