CKEDITOR.plugins.setLang("newpage","it",{toolbar:"Nuova pagina"});
