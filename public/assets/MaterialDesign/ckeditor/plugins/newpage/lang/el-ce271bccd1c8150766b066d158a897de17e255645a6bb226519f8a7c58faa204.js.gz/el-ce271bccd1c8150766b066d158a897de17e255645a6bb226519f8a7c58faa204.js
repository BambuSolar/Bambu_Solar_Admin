CKEDITOR.plugins.setLang("newpage","el",{toolbar:"Νέα Σελίδα"});
