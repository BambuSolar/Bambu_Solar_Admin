CKEDITOR.plugins.setLang("newpage","mk",{toolbar:"New Page"});
