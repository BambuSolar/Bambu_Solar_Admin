CKEDITOR.plugins.setLang("newpage","fo",{toolbar:"Nýggj síða"});
