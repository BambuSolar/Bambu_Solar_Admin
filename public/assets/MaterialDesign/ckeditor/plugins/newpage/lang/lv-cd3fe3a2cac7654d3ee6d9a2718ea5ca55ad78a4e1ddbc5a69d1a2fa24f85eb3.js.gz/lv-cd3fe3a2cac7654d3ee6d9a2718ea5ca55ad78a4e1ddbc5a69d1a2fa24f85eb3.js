CKEDITOR.plugins.setLang("newpage","lv",{toolbar:"Jauna lapa"});
