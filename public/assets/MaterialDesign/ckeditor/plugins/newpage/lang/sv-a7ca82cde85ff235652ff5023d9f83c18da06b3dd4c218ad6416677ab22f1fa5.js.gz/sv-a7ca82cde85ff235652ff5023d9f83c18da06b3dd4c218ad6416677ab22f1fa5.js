CKEDITOR.plugins.setLang("newpage","sv",{toolbar:"Ny sida"});
