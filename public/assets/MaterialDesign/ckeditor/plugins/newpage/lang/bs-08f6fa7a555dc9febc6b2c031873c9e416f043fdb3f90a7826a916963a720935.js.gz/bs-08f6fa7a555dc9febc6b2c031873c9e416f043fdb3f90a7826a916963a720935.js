CKEDITOR.plugins.setLang("newpage","bs",{toolbar:"Novi dokument"});
