CKEDITOR.plugins.setLang("newpage","id",{toolbar:"Halaman Baru"});
