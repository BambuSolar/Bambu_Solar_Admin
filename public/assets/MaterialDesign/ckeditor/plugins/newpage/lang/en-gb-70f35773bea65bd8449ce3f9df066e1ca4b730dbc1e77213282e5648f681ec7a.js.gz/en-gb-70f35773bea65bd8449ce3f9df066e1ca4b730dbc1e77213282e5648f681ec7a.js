CKEDITOR.plugins.setLang("newpage","en-gb",{toolbar:"New Page"});
