CKEDITOR.plugins.setLang("newpage","et",{toolbar:"Uus leht"});
