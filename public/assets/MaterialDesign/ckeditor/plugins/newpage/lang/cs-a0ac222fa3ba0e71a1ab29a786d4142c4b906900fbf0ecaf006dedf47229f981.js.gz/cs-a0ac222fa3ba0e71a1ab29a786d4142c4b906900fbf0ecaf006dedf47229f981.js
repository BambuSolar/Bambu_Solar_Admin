CKEDITOR.plugins.setLang("newpage","cs",{toolbar:"Nová stránka"});
