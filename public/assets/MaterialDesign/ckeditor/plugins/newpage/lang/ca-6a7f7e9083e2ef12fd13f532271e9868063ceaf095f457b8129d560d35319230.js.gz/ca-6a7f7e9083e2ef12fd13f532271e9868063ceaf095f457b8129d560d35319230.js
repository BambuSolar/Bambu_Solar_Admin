CKEDITOR.plugins.setLang("newpage","ca",{toolbar:"Nova pàgina"});
