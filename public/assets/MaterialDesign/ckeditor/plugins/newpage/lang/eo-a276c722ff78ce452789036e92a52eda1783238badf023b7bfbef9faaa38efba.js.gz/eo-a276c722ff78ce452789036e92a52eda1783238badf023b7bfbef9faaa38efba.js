CKEDITOR.plugins.setLang("newpage","eo",{toolbar:"Nova Paĝo"});
