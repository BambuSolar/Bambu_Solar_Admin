CKEDITOR.plugins.setLang("newpage","de",{toolbar:"Neue Seite"});
