CKEDITOR.plugins.setLang("newpage","nl",{toolbar:"Nieuwe pagina"});
