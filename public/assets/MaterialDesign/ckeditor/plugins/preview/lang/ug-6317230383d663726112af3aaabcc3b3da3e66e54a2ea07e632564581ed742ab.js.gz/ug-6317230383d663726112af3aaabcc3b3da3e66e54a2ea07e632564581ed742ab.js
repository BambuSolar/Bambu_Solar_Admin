CKEDITOR.plugins.setLang("preview","ug",{preview:"ئالدىن كۆزەت"});
