CKEDITOR.plugins.setLang("preview","eo",{preview:"Vidigi Aspekton"});
