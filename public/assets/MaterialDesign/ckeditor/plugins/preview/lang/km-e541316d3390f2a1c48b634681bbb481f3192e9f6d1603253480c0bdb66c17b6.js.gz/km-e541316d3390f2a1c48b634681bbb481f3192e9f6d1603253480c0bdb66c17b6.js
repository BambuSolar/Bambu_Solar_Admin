CKEDITOR.plugins.setLang("preview","km",{preview:"មើល​ជា​មុន"});
