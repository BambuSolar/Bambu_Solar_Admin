CKEDITOR.plugins.setLang("preview","ru",{preview:"Предварительный просмотр"});
