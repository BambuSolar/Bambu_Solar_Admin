CKEDITOR.plugins.setLang("preview","fr-ca",{preview:"Prévisualiser"});
