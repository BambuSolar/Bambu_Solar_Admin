CKEDITOR.plugins.setLang("preview","ro",{preview:"Previzualizare"});
