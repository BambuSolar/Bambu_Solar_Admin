CKEDITOR.plugins.setLang("preview","en-ca",{preview:"Preview"});
