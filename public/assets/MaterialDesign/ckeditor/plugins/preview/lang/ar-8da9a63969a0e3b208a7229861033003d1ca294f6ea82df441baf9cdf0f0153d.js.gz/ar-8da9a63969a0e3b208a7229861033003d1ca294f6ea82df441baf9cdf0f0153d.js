CKEDITOR.plugins.setLang("preview","ar",{preview:"معاينة الصفحة"});
