CKEDITOR.plugins.setLang("preview","pl",{preview:"Podgląd"});
