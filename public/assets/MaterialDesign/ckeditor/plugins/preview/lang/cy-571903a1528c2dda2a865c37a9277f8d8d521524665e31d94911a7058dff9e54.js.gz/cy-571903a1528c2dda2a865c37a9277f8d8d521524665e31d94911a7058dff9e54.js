CKEDITOR.plugins.setLang("preview","cy",{preview:"Rhagolwg"});
