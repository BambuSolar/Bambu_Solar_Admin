CKEDITOR.plugins.setLang("preview","id",{preview:"Pratinjau"});
