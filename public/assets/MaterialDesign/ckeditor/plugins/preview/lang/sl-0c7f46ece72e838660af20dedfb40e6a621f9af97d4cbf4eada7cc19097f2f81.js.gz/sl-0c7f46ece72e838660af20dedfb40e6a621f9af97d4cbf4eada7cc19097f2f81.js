CKEDITOR.plugins.setLang("preview","sl",{preview:"Predogled"});
