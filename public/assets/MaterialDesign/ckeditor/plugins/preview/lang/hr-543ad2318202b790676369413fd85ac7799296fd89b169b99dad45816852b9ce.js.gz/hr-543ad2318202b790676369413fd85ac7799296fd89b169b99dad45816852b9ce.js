CKEDITOR.plugins.setLang("preview","hr",{preview:"Pregledaj"});
