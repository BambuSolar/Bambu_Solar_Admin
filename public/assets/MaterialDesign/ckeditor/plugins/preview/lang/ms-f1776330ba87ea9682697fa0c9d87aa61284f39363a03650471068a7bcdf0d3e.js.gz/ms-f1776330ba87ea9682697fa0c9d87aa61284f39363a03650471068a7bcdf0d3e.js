CKEDITOR.plugins.setLang("preview","ms",{preview:"Prebiu"});
