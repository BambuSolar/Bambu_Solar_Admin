CKEDITOR.plugins.setLang("preview","si",{preview:"නැවත "});
