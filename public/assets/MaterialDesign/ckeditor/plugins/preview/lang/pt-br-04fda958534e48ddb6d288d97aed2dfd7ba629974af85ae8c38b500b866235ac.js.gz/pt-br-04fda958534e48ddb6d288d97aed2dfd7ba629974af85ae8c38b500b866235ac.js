CKEDITOR.plugins.setLang("preview","pt-br",{preview:"Visualizar"});
