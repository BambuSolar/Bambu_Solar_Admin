CKEDITOR.plugins.setLang("preview","en-au",{preview:"Preview"});
