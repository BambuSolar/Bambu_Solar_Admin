CKEDITOR.plugins.setLang("preview","ka",{preview:"გადახედვა"});
