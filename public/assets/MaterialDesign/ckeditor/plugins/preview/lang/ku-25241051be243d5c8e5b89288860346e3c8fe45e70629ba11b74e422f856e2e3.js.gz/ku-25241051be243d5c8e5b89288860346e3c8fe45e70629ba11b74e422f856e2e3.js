CKEDITOR.plugins.setLang("preview","ku",{preview:"پێشبینین"});
