CKEDITOR.plugins.setLang("preview","en-gb",{preview:"Preview"});
