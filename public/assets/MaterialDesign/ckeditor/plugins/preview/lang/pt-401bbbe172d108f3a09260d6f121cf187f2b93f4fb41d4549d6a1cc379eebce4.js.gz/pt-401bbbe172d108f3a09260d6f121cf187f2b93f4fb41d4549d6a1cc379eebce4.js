CKEDITOR.plugins.setLang("preview","pt",{preview:"Pré-visualizar"});
