CKEDITOR.plugins.setLang("preview","zh-cn",{preview:"预览"});
