CKEDITOR.plugins.setLang("preview","hu",{preview:"Előnézet"});
