CKEDITOR.plugins.setLang("preview","he",{preview:"תצוגה מקדימה"});
