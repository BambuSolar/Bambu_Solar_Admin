CKEDITOR.plugins.setLang("preview","sv",{preview:"Förhandsgranska"});
