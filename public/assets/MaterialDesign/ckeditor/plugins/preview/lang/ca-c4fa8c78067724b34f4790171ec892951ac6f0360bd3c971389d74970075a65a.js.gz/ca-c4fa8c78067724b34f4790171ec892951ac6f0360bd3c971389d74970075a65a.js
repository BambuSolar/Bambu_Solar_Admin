CKEDITOR.plugins.setLang("preview","ca",{preview:"Visualització prèvia"});
