CKEDITOR.plugins.setLang("preview","uk",{preview:"Попередній перегляд"});
