CKEDITOR.plugins.setLang("preview","nb",{preview:"Forhåndsvis"});
