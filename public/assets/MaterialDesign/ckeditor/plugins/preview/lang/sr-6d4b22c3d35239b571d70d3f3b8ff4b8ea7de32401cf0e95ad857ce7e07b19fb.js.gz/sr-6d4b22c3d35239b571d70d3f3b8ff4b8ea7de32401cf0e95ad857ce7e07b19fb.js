CKEDITOR.plugins.setLang("preview","sr",{preview:"Изглед странице"});
