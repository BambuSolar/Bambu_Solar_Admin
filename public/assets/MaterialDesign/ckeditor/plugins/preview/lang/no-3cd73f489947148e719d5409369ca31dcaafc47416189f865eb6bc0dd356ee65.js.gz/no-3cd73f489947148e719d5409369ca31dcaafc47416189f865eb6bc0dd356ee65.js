CKEDITOR.plugins.setLang("preview","no",{preview:"Forhåndsvis"});
