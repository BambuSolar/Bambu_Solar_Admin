CKEDITOR.plugins.setLang("preview","de",{preview:"Vorschau"});
