CKEDITOR.plugins.setLang("preview","eu",{preview:"Aurrebista"});
