CKEDITOR.plugins.setLang("preview","sk",{preview:"Náhľad"});
