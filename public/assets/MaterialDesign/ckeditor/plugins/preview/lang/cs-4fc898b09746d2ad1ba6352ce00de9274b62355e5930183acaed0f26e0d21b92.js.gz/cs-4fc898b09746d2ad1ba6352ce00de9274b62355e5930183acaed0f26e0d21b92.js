CKEDITOR.plugins.setLang("preview","cs",{preview:"Náhled"});
