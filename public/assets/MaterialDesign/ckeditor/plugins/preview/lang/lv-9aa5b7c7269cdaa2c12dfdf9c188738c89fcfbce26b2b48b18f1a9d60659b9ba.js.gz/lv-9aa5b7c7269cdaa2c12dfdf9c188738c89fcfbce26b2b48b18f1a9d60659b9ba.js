CKEDITOR.plugins.setLang("preview","lv",{preview:"Priekšskatīt"});
