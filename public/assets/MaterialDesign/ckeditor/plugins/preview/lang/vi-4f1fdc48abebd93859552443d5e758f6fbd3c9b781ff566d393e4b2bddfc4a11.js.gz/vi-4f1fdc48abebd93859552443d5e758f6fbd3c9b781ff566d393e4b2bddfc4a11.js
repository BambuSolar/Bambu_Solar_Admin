CKEDITOR.plugins.setLang("preview","vi",{preview:"Xem trước"});
