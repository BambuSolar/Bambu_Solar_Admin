CKEDITOR.plugins.setLang("preview","tt",{preview:"Карап алу"});
