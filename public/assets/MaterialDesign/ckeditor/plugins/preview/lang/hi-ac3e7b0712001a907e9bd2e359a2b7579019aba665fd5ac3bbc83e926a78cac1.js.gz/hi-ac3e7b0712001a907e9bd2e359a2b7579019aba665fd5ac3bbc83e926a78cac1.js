CKEDITOR.plugins.setLang("preview","hi",{preview:"प्रीव्यू"});
