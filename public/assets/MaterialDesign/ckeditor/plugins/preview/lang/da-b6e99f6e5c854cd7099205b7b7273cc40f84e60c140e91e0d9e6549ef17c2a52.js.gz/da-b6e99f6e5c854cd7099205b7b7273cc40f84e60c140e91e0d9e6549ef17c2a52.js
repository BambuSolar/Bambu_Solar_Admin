CKEDITOR.plugins.setLang("preview","da",{preview:"Vis eksempel"});
