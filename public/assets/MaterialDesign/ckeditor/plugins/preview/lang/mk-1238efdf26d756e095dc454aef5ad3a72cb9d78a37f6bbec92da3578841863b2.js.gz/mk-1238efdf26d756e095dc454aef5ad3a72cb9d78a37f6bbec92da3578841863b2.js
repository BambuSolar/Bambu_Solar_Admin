CKEDITOR.plugins.setLang("preview","mk",{preview:"Preview"});
