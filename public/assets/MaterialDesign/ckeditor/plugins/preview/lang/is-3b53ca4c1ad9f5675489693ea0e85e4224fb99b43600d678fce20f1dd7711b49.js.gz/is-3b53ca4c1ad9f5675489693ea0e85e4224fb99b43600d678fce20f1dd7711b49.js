CKEDITOR.plugins.setLang("preview","is",{preview:"Forskoða"});
