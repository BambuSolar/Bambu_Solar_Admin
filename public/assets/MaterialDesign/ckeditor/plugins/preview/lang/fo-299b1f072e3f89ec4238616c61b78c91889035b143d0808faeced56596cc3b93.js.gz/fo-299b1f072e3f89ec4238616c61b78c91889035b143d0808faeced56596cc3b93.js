CKEDITOR.plugins.setLang("preview","fo",{preview:"Frumsýning"});
