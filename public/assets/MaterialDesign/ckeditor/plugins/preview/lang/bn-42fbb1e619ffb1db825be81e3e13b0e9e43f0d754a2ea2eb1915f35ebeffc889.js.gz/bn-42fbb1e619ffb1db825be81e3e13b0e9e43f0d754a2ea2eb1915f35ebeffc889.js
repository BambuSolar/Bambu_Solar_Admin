CKEDITOR.plugins.setLang("preview","bn",{preview:"প্রাকদর্শন"});
