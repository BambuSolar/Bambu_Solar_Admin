CKEDITOR.plugins.setLang("preview","zh",{preview:"預覽"});
