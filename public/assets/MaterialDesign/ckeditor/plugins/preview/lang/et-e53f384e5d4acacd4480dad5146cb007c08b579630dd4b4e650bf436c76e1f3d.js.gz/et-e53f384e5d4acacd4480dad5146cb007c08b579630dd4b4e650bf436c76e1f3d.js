CKEDITOR.plugins.setLang("preview","et",{preview:"Eelvaade"});
