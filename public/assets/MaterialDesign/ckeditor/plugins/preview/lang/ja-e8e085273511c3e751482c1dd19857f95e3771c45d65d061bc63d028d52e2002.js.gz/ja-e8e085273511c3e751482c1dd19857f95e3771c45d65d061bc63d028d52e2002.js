CKEDITOR.plugins.setLang("preview","ja",{preview:"プレビュー"});
