CKEDITOR.plugins.setLang("preview","el",{preview:"Προεπισκόπιση"});
