CKEDITOR.plugins.setLang("preview","sr-latn",{preview:"Izgled stranice"});
