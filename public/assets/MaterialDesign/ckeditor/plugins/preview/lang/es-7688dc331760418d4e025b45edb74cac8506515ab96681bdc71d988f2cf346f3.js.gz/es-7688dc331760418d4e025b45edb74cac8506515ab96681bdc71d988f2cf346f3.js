CKEDITOR.plugins.setLang("preview","es",{preview:"Vista Previa"});
