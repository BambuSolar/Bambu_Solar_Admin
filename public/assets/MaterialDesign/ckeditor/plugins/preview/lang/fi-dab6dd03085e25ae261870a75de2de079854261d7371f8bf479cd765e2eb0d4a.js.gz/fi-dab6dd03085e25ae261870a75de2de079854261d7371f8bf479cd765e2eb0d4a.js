CKEDITOR.plugins.setLang("preview","fi",{preview:"Esikatsele"});
