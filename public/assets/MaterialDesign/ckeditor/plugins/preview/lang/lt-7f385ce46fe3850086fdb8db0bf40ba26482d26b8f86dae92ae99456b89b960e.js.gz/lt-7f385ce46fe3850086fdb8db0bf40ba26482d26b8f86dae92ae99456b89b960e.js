CKEDITOR.plugins.setLang("preview","lt",{preview:"Peržiūra"});
