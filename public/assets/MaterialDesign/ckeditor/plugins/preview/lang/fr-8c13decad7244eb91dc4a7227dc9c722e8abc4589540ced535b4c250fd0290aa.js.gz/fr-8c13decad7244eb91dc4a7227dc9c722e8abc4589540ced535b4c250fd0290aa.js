CKEDITOR.plugins.setLang("preview","fr",{preview:"Aperçu"});
