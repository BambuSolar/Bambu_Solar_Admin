CKEDITOR.plugins.setLang("preview","th",{preview:"ดูหน้าเอกสารตัวอย่าง"});
