CKEDITOR.plugins.setLang("preview","it",{preview:"Anteprima"});
