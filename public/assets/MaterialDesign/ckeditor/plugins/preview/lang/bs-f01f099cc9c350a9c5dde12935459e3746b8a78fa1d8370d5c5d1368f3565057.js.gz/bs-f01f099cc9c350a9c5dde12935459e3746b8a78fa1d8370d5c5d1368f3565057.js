CKEDITOR.plugins.setLang("preview","bs",{preview:"Prikaži"});
