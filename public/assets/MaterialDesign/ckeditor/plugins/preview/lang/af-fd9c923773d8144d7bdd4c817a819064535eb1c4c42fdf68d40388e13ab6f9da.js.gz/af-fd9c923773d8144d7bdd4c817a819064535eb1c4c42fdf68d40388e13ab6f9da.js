CKEDITOR.plugins.setLang("preview","af",{preview:"Voorbeeld"});
