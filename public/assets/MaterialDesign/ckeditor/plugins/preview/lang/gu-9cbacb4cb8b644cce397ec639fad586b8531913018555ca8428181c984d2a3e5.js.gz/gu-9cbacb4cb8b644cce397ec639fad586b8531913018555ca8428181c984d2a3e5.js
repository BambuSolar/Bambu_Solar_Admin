CKEDITOR.plugins.setLang("preview","gu",{preview:"પૂર્વદર્શન"});
