CKEDITOR.plugins.setLang("preview","nl",{preview:"Voorbeeld"});
