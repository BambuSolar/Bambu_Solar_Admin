CKEDITOR.plugins.setLang("preview","de-ch",{preview:"Vorschau"});
