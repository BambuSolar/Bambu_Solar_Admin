CKEDITOR.plugins.setLang("preview","tr",{preview:"Ön İzleme"});
