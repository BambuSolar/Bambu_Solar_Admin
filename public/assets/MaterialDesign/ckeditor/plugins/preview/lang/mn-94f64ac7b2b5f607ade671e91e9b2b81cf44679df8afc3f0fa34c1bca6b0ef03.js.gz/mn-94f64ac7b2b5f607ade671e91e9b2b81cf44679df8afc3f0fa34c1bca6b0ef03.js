CKEDITOR.plugins.setLang("preview","mn",{preview:"Уридчлан харах"});
