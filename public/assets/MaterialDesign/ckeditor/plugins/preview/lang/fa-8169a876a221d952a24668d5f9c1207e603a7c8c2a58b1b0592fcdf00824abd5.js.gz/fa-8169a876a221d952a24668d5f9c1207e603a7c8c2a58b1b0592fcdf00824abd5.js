CKEDITOR.plugins.setLang("preview","fa",{preview:"پیشنمایش"});
