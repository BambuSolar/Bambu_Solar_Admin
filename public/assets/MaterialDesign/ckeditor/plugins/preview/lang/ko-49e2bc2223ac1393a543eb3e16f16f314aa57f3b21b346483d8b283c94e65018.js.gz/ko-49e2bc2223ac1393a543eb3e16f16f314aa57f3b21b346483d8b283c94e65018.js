CKEDITOR.plugins.setLang("preview","ko",{preview:"미리보기"});
