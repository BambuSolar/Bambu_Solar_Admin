CKEDITOR.plugins.setLang("preview","gl",{preview:"Vista previa"});
