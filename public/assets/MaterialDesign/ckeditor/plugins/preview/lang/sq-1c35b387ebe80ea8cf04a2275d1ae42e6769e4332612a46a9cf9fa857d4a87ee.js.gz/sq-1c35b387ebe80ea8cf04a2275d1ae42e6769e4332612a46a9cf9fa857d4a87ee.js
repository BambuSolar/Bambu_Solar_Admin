CKEDITOR.plugins.setLang("preview","sq",{preview:"Parashiko"});
