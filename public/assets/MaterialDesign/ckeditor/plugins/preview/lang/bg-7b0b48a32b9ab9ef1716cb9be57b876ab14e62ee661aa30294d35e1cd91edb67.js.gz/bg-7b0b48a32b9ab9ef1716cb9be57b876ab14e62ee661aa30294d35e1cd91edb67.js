CKEDITOR.plugins.setLang("preview","bg",{preview:"Преглед"});
