CKEDITOR.plugins.setLang("preview","en",{preview:"Preview"});
