CKEDITOR.plugins.setLang("colordialog","km",{clear:"សម្អាត",highlight:"បន្លិច​ពណ៌",options:"ជម្រើស​ពណ៌",selected:"ពណ៌​ដែល​បាន​រើស",title:"រើស​ពណ៌"});
