CKEDITOR.plugins.setLang("colordialog","ro",{clear:"Clear",highlight:"Highlight",options:"Color Options",selected:"Selected Color",title:"Select color"});
