CKEDITOR.plugins.setLang("colordialog","el",{clear:"Εκκαθάριση",highlight:"Σήμανση",options:"Επιλογές Χρωμάτων",selected:"Επιλεγμένο Χρώμα",title:"Επιλογή χρώματος"});
