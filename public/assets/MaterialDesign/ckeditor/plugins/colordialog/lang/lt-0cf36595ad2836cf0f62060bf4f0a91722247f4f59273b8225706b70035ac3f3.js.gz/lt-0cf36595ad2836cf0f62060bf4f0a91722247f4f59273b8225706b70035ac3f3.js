CKEDITOR.plugins.setLang("colordialog","lt",{clear:"Išvalyti",highlight:"Paryškinti",options:"Spalvos nustatymai",selected:"Pasirinkta spalva",title:"Pasirinkite spalvą"});
