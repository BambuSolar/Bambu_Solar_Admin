CKEDITOR.plugins.setLang("colordialog","hi",{clear:"Clear",highlight:"Highlight",options:"Color Options",selected:"Selected Color",title:"Select color"});
