CKEDITOR.plugins.setLang("colordialog","fa",{clear:"پاک کردن",highlight:"متمایز",options:"گزینه​های رنگ",selected:"رنگ انتخاب شده",title:"انتخاب رنگ"});
