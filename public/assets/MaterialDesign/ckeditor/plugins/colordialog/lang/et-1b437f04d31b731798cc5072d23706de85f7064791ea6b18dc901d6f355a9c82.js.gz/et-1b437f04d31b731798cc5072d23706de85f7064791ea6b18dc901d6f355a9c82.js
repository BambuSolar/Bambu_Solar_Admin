CKEDITOR.plugins.setLang("colordialog","et",{clear:"Eemalda",highlight:"Näidis",options:"Värvi valikud",selected:"Valitud värv",title:"Värvi valimine"});
