CKEDITOR.plugins.setLang("colordialog","de-ch",{clear:"Entfernen",highlight:"Hervorheben",options:"Farboptionen",selected:"Ausgewählte Farbe",title:"Farbe auswählen"});
