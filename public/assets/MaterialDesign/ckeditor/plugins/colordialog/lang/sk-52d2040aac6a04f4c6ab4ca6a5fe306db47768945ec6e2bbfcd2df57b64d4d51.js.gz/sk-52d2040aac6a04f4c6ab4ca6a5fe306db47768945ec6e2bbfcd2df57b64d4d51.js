CKEDITOR.plugins.setLang("colordialog","sk",{clear:"Vyčistiť",highlight:"Zvýrazniť",options:"Možnosti farby",selected:"Vybraná farba",title:"Vybrať farbu"});
