CKEDITOR.plugins.setLang("colordialog","zh-cn",{clear:"清除",highlight:"高亮",options:"颜色选项",selected:"选择颜色",title:"选择颜色"});
