CKEDITOR.plugins.setLang("colordialog","tt",{clear:"Бушату",highlight:"Билгеләү",options:"Төс көйләүләре",selected:"Сайланган төсләр",title:"Төс сайлау"});
