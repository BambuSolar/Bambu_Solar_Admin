CKEDITOR.plugins.setLang("colordialog","eu",{clear:"Garbitu",highlight:"Nabarmendu",options:"Kolore aukerak",selected:"Hautatutako kolorea",title:"Hautatu kolorea"});
