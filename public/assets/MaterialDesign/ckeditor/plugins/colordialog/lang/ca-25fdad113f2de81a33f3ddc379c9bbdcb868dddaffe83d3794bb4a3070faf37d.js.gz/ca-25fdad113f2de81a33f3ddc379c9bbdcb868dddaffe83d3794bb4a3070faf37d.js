CKEDITOR.plugins.setLang("colordialog","ca",{clear:"Neteja",highlight:"Destacat",options:"Opcions del color",selected:"Color Seleccionat",title:"Seleccioni el color"});
