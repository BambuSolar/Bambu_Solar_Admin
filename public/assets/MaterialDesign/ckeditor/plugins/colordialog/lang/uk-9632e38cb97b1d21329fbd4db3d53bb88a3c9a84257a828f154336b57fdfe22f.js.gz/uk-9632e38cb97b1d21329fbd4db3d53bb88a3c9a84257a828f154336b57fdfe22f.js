CKEDITOR.plugins.setLang("colordialog","uk",{clear:"Очистити",highlight:"Колір, на який вказує курсор",options:"Опції кольорів",selected:"Обраний колір",title:"Обрати колір"});
