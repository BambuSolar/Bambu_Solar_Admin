CKEDITOR.plugins.setLang("colordialog","af",{clear:"Herstel",highlight:"Aktief",options:"Kleuropsies",selected:"Geselekteer",title:"Kies kleur"});
