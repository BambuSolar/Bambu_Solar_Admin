CKEDITOR.plugins.setLang("colordialog","sl",{clear:"Počisti",highlight:"Poudarjeno",options:"Možnosti barve",selected:"Izbrana barva",title:"Izberi barvo"});
