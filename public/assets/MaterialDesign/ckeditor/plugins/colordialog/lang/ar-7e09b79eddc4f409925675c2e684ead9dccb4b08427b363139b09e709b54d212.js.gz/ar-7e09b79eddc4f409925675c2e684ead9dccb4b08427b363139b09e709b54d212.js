CKEDITOR.plugins.setLang("colordialog","ar",{clear:"مسح",highlight:"تحديد",options:"اختيارات الألوان",selected:"اللون المختار",title:"اختر اللون"});
