CKEDITOR.plugins.setLang("colordialog","fr-ca",{clear:"Effacer",highlight:"Surligner",options:"Options de couleur",selected:"Couleur sélectionnée",title:"Choisir une couleur"});
