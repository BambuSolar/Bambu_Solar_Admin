CKEDITOR.plugins.setLang("sourcedialog","fa",{toolbar:"منبع",title:"منبع"});
