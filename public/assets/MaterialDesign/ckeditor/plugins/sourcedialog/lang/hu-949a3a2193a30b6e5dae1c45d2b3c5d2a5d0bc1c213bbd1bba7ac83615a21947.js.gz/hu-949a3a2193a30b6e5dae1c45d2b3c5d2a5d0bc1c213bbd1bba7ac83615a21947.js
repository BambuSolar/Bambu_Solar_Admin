CKEDITOR.plugins.setLang("sourcedialog","hu",{toolbar:"Forráskód",title:"Forráskód"});
