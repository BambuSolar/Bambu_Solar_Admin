CKEDITOR.plugins.setLang("sourcedialog","sq",{toolbar:"Burimi",title:"Burimi"});
