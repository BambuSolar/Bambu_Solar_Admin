CKEDITOR.plugins.setLang("sourcedialog","ms",{toolbar:"Sumber",title:"Sumber"});
