CKEDITOR.plugins.setLang("sourcedialog","hr",{toolbar:"Kôd",title:"Kôd"});
