CKEDITOR.plugins.setLang("sourcedialog","sk",{toolbar:"Zdroj",title:"Zdroj"});
