CKEDITOR.plugins.setLang("sourcedialog","ar",{toolbar:"المصدر",title:"المصدر"});
