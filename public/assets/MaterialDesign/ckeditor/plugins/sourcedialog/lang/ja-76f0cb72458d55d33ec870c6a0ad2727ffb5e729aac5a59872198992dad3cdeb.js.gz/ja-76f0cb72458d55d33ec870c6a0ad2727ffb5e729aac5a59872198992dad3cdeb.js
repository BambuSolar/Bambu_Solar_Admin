CKEDITOR.plugins.setLang("sourcedialog","ja",{toolbar:"ソース",title:"ソース"});
