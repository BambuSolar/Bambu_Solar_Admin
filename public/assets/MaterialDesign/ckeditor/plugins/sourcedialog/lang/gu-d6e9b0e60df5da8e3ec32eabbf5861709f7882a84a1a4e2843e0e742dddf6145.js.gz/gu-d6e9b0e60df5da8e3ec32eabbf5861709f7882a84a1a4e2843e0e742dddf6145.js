CKEDITOR.plugins.setLang("sourcedialog","gu",{toolbar:"મૂળ કે પ્રાથમિક દસ્તાવેજ",title:"મૂળ કે પ્રાથમિક દસ્તાવેજ"});
