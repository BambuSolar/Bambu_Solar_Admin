CKEDITOR.plugins.setLang("sourcedialog","en-au",{toolbar:"Source",title:"Source"});
