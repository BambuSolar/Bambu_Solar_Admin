CKEDITOR.plugins.setLang("sourcedialog","no",{toolbar:"Kilde",title:"Kilde"});
