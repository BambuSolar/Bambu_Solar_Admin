CKEDITOR.plugins.setLang("sourcedialog","pt-br",{toolbar:"Código-Fonte",title:"Código-Fonte"});
