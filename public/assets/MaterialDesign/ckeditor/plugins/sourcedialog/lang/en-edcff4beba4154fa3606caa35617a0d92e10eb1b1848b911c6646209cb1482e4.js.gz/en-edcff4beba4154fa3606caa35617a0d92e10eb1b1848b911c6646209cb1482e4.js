CKEDITOR.plugins.setLang("sourcedialog","en",{toolbar:"Source",title:"Source"});
