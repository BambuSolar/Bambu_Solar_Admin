CKEDITOR.plugins.setLang("sourcedialog","en-ca",{toolbar:"Source",title:"Source"});
