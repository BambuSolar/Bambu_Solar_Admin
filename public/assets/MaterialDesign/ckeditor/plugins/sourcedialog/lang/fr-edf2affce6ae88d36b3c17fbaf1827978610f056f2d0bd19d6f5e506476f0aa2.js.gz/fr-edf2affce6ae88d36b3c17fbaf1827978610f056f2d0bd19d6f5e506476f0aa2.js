CKEDITOR.plugins.setLang("sourcedialog","fr",{toolbar:"Source",title:"Source"});
