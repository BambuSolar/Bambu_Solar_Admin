CKEDITOR.plugins.setLang("sourcedialog","ko",{toolbar:"소스",title:"소스"});
