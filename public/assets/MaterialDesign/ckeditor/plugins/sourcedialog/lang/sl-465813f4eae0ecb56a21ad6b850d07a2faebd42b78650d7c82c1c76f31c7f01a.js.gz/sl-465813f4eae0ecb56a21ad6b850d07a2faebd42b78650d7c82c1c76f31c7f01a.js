CKEDITOR.plugins.setLang("sourcedialog","sl",{toolbar:"Izvorna koda",title:"Izvorna koda"});
