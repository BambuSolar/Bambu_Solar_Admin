CKEDITOR.plugins.setLang("sourcedialog","el",{toolbar:"Κώδικας",title:"Κώδικας"});
