CKEDITOR.plugins.setLang("sourcedialog","ru",{toolbar:"Исходник",title:"Источник"});
