CKEDITOR.plugins.setLang("sourcedialog","lv",{toolbar:"HTML kods",title:"HTML kods"});
