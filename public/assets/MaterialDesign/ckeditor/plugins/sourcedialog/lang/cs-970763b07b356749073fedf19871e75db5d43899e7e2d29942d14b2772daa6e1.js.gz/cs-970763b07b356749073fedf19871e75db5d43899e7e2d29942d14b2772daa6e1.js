CKEDITOR.plugins.setLang("sourcedialog","cs",{toolbar:"Zdroj",title:"Zdroj"});
