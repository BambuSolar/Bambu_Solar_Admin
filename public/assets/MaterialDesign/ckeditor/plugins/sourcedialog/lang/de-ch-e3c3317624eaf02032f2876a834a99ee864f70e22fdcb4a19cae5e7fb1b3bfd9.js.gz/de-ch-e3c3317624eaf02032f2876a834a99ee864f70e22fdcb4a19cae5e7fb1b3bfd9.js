CKEDITOR.plugins.setLang("sourcedialog","de-ch",{toolbar:"Quellcode",title:"Quellcode"});
