CKEDITOR.plugins.setLang("sourcedialog","uk",{toolbar:"Джерело",title:"Джерело"});
