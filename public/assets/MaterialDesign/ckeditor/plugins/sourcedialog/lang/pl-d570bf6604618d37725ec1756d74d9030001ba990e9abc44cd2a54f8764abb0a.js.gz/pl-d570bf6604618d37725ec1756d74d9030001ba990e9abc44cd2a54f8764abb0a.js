CKEDITOR.plugins.setLang("sourcedialog","pl",{toolbar:"Źródło dokumentu",title:"Źródło dokumentu"});
