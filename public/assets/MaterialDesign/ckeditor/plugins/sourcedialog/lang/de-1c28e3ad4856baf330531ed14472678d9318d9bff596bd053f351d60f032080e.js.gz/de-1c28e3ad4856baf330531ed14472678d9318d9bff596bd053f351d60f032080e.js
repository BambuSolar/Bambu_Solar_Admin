CKEDITOR.plugins.setLang("sourcedialog","de",{toolbar:"Quellcode",title:"Quellcode"});
