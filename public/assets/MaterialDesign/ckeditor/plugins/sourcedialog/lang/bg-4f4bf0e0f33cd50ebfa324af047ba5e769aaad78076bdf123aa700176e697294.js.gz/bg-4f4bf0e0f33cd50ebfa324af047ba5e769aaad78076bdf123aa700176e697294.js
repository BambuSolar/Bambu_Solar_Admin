CKEDITOR.plugins.setLang("sourcedialog","bg",{toolbar:"Източник",title:"Източник"});
