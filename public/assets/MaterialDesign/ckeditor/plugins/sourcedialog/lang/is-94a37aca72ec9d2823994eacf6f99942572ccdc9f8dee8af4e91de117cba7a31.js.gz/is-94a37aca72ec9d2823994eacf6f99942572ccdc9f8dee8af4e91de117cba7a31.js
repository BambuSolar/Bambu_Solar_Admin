CKEDITOR.plugins.setLang("sourcedialog","is",{toolbar:"Kóði",title:"Kóði"});
