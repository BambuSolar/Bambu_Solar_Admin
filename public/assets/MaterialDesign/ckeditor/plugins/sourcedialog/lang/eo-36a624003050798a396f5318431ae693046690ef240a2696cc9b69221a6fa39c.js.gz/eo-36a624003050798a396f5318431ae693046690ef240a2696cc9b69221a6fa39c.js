CKEDITOR.plugins.setLang("sourcedialog","eo",{toolbar:"Fonto",title:"Fonto"});
