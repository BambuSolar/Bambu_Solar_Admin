CKEDITOR.plugins.setLang("sourcedialog","hi",{toolbar:"सोर्स",title:"सोर्स"});
