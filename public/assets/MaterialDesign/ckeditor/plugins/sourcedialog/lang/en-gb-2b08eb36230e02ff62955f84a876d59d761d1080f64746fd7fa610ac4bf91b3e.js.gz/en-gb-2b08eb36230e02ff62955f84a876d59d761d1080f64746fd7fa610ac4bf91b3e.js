CKEDITOR.plugins.setLang("sourcedialog","en-gb",{toolbar:"Source",title:"Source"});
