CKEDITOR.plugins.setLang("sourcedialog","pt",{toolbar:"Fonte",title:"Fonte"});
