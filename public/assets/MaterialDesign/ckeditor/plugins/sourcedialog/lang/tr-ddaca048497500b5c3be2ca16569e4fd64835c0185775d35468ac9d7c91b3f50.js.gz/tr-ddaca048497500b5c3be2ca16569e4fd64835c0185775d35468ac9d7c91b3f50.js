CKEDITOR.plugins.setLang("sourcedialog","tr",{toolbar:"Kaynak",title:"Kaynak"});
