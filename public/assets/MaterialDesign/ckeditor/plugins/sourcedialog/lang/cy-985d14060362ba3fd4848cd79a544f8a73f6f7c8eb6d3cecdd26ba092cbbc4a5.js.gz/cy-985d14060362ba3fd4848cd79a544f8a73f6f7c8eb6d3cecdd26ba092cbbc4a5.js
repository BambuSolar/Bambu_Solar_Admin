CKEDITOR.plugins.setLang("sourcedialog","cy",{toolbar:"HTML",title:"HTML"});
