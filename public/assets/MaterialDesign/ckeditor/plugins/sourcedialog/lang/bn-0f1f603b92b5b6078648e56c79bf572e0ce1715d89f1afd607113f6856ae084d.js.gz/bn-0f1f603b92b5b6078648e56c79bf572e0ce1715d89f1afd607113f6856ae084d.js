CKEDITOR.plugins.setLang("sourcedialog","bn",{toolbar:"উৎস",title:"সোর্স"});
