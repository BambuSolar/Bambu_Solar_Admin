CKEDITOR.plugins.setLang("sourcedialog","ku",{toolbar:"سەرچاوە",title:"سەرچاوە"});
