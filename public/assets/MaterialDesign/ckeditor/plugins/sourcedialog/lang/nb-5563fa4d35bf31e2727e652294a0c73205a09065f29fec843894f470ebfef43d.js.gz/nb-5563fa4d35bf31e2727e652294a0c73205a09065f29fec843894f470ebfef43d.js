CKEDITOR.plugins.setLang("sourcedialog","nb",{toolbar:"Kilde",title:"Kilde"});
