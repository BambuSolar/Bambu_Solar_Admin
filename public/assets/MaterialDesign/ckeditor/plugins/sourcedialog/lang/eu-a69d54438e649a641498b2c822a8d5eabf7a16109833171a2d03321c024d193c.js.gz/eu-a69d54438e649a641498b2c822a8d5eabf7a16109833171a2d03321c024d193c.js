CKEDITOR.plugins.setLang("sourcedialog","eu",{toolbar:"Iturburua",title:"Iturburua"});
