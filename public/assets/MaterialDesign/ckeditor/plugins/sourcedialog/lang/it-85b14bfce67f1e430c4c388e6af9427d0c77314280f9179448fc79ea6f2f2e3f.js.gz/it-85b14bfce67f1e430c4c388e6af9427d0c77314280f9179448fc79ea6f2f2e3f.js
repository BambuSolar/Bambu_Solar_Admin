CKEDITOR.plugins.setLang("sourcedialog","it",{toolbar:"Sorgente",title:"Sorgente"});
