CKEDITOR.plugins.setLang("sourcedialog","af",{toolbar:"Bron",title:"Bron"});
