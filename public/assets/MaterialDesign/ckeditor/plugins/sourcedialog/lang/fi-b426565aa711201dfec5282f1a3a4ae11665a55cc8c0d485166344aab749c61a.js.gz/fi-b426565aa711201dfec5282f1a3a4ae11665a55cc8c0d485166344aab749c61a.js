CKEDITOR.plugins.setLang("sourcedialog","fi",{toolbar:"Koodi",title:"Koodi"});
