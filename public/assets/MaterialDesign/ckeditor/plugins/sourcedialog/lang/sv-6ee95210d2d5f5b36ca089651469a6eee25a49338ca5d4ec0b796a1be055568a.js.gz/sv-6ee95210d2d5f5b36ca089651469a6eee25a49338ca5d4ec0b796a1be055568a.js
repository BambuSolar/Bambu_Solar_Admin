CKEDITOR.plugins.setLang("sourcedialog","sv",{toolbar:"Källa",title:"Källa"});
