CKEDITOR.plugins.setLang("sourcedialog","nl",{toolbar:"Broncode",title:"Broncode"});
