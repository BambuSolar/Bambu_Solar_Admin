CKEDITOR.plugins.setLang("sourcedialog","th",{toolbar:"ดูรหัส HTML",title:"ดูรหัส HTML"});
