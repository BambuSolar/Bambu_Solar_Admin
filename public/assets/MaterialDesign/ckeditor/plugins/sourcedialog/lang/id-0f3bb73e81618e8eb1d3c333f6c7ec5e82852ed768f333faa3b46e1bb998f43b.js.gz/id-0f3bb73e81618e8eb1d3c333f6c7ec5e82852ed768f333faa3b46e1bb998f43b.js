CKEDITOR.plugins.setLang("sourcedialog","id",{toolbar:"Sumber",title:"Sumber"});
