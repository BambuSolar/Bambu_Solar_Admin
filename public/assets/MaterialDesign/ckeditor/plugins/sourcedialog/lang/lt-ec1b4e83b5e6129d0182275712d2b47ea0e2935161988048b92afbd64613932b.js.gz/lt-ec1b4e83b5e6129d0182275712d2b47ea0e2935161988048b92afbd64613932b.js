CKEDITOR.plugins.setLang("sourcedialog","lt",{toolbar:"Šaltinis",title:"Šaltinis"});
