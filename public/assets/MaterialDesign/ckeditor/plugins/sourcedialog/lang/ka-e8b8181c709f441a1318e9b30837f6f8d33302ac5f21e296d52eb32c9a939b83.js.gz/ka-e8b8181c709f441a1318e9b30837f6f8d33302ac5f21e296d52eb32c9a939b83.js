CKEDITOR.plugins.setLang("sourcedialog","ka",{toolbar:"კოდები",title:"კოდები"});
