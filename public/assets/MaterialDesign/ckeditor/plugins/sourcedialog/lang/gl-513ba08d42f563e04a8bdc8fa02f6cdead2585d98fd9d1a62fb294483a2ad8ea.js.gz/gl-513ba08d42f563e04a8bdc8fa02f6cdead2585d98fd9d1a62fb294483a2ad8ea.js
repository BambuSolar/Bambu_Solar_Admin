CKEDITOR.plugins.setLang("sourcedialog","gl",{toolbar:"Orixe",title:"Orixe"});
