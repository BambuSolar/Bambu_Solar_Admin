CKEDITOR.plugins.setLang("sourcedialog","sr-latn",{toolbar:"Kôd",title:"Kôd"});
