CKEDITOR.plugins.setLang("sourcedialog","fo",{toolbar:"Kelda",title:"Kelda"});
