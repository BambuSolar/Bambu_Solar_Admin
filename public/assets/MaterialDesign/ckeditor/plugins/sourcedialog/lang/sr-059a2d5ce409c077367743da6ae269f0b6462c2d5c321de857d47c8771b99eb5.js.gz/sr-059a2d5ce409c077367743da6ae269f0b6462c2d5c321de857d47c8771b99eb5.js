CKEDITOR.plugins.setLang("sourcedialog","sr",{toolbar:"Kôд",title:"Kôд"});
