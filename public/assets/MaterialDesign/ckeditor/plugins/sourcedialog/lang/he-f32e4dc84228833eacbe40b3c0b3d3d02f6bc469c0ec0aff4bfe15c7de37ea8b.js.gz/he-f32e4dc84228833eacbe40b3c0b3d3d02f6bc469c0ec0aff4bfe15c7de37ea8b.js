CKEDITOR.plugins.setLang("sourcedialog","he",{toolbar:"מקור",title:"מקור"});
