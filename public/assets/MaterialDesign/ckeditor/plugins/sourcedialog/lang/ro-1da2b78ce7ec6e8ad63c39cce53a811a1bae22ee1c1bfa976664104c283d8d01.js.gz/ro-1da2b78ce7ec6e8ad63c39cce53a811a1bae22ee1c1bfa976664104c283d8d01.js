CKEDITOR.plugins.setLang("sourcedialog","ro",{toolbar:"Sursa",title:"Sursa"});
