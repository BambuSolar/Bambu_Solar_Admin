CKEDITOR.plugins.setLang("sourcedialog","vi",{toolbar:"Mã HTML",title:"Mã HTML"});
