CKEDITOR.plugins.setLang("sourcedialog","zh-cn",{toolbar:"源码",title:"源码"});
