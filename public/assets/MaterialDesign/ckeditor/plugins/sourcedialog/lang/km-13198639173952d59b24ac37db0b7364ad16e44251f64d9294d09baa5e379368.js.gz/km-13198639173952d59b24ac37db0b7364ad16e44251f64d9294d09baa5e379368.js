CKEDITOR.plugins.setLang("sourcedialog","km",{toolbar:"អក្សរ​កូដ",title:"អក្សរ​កូដ"});
