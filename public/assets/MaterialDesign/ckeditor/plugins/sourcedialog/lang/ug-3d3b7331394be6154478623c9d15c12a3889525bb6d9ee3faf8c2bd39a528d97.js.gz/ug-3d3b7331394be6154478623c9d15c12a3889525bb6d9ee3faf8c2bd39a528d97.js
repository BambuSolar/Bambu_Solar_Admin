CKEDITOR.plugins.setLang("sourcedialog","ug",{toolbar:"مەنبە",title:"مەنبە"});
