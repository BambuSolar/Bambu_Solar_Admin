CKEDITOR.plugins.setLang("sourcedialog","fr-ca",{toolbar:"Source",title:"Source"});
