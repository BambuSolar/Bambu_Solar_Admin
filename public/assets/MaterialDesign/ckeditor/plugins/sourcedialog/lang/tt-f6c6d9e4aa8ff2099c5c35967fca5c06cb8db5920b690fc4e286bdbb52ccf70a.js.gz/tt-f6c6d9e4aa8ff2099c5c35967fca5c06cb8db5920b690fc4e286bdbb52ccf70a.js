CKEDITOR.plugins.setLang("sourcedialog","tt",{toolbar:"Чыганак",title:"Чыганак"});
