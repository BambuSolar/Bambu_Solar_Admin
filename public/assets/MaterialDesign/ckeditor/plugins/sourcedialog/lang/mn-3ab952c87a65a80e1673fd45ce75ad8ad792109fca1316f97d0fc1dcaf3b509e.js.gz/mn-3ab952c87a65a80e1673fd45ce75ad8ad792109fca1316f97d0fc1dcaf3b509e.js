CKEDITOR.plugins.setLang("sourcedialog","mn",{toolbar:"Код",title:"Код"});
