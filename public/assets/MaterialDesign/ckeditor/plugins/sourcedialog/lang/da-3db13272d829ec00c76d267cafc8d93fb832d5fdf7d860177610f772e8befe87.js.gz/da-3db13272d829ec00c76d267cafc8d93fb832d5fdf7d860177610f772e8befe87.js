CKEDITOR.plugins.setLang("sourcedialog","da",{toolbar:"Kilde",title:"Kilde"});
