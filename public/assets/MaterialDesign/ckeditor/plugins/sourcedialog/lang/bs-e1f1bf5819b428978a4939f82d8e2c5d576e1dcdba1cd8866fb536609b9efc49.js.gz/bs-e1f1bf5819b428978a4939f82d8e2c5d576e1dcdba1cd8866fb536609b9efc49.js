CKEDITOR.plugins.setLang("sourcedialog","bs",{toolbar:"HTML kôd",title:"HTML kôd"});
