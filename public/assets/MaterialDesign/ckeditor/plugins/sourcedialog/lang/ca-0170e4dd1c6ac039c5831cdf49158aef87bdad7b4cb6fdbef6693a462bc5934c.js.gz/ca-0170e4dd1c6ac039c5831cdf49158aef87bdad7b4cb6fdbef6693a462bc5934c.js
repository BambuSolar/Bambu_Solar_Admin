CKEDITOR.plugins.setLang("sourcedialog","ca",{toolbar:"Codi font",title:"Codi font"});
