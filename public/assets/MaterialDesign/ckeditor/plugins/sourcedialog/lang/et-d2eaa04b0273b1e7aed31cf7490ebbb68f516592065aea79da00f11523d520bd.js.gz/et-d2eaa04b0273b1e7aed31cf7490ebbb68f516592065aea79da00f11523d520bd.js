CKEDITOR.plugins.setLang("sourcedialog","et",{toolbar:"Lähtekood",title:"Lähtekood"});
