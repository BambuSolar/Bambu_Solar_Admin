CKEDITOR.plugins.setLang("sourcedialog","zh",{toolbar:"原始碼",title:"原始碼"});
