CKEDITOR.plugins.setLang("sourcedialog","es",{toolbar:"Fuente HTML",title:"Fuente HTML"});
