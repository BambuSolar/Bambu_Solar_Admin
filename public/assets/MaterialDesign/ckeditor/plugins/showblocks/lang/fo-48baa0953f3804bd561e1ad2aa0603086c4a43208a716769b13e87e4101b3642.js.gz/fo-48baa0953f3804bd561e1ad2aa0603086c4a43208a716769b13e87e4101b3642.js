CKEDITOR.plugins.setLang("showblocks","fo",{toolbar:"Vís blokkar"});
