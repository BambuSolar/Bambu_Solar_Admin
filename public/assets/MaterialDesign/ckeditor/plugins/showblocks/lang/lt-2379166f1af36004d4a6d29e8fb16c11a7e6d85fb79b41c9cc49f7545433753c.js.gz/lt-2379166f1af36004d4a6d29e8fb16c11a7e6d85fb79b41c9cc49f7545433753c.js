CKEDITOR.plugins.setLang("showblocks","lt",{toolbar:"Rodyti blokus"});
