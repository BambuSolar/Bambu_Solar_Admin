CKEDITOR.plugins.setLang("showblocks","fa",{toolbar:"نمایش بلوک‌ها"});
