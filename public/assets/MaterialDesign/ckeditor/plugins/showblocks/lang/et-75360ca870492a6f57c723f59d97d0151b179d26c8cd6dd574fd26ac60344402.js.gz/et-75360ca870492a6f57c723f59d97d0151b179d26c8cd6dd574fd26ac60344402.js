CKEDITOR.plugins.setLang("showblocks","et",{toolbar:"Blokkide näitamine"});
