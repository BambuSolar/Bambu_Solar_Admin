CKEDITOR.plugins.setLang("showblocks","da",{toolbar:"Vis afsnitsmærker"});
