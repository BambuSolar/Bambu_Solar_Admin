CKEDITOR.plugins.setLang("showblocks","fr",{toolbar:"Afficher les blocs"});
