CKEDITOR.plugins.setLang("showblocks","sl",{toolbar:"Prikaži ograde"});
