CKEDITOR.plugins.setLang("showblocks","hi",{toolbar:"ब्लॉक दिखायें"});
