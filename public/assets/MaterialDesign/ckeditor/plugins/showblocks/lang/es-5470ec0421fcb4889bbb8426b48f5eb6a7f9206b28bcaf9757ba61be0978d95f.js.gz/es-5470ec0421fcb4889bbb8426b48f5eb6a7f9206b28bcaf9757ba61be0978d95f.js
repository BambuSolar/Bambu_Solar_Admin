CKEDITOR.plugins.setLang("showblocks","es",{toolbar:"Mostrar bloques"});
