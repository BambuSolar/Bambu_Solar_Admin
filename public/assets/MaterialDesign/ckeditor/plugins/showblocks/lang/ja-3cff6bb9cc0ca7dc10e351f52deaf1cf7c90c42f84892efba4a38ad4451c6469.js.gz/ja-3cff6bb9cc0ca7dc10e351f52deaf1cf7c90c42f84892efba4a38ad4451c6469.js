CKEDITOR.plugins.setLang("showblocks","ja",{toolbar:"ブロック表示"});
