CKEDITOR.plugins.setLang("showblocks","el",{toolbar:"Προβολή Τμημάτων"});
