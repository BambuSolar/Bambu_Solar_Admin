CKEDITOR.plugins.setLang("showblocks","de-ch",{toolbar:"Blöcke anzeigen"});
