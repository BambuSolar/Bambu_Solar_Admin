CKEDITOR.plugins.setLang("showblocks","zh",{toolbar:"顯示區塊"});
