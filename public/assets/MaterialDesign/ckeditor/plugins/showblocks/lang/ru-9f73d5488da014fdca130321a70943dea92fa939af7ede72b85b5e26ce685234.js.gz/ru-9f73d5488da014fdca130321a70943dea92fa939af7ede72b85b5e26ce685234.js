CKEDITOR.plugins.setLang("showblocks","ru",{toolbar:"Отображать блоки"});
