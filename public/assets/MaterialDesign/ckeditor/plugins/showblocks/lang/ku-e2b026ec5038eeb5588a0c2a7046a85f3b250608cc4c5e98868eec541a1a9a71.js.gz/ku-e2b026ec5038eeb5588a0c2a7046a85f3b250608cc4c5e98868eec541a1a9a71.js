CKEDITOR.plugins.setLang("showblocks","ku",{toolbar:"نیشاندانی بەربەستەکان"});
