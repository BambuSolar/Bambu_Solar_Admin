CKEDITOR.plugins.setLang("showblocks","mn",{toolbar:"Хавтангуудыг харуулах"});
