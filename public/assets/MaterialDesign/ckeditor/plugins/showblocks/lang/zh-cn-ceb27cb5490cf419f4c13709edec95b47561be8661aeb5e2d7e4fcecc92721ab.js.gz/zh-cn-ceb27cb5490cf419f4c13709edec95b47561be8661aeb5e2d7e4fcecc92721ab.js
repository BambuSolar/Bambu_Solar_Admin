CKEDITOR.plugins.setLang("showblocks","zh-cn",{toolbar:"显示区块"});
