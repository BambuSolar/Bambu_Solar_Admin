CKEDITOR.plugins.setLang("showblocks","ms",{toolbar:"Show Blocks"});
