CKEDITOR.plugins.setLang("showblocks","si",{toolbar:"කොටස පෙන්නන්න"});
