CKEDITOR.plugins.setLang("showblocks","sq",{toolbar:"Shfaq Blloqet"});
