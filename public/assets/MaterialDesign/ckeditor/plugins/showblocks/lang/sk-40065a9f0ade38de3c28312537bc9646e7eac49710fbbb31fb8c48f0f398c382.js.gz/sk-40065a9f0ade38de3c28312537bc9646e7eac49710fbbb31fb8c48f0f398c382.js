CKEDITOR.plugins.setLang("showblocks","sk",{toolbar:"Ukázať bloky"});
