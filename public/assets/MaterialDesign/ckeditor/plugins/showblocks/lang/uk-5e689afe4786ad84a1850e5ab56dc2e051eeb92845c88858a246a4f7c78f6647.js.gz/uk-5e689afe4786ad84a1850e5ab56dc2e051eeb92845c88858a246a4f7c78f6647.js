CKEDITOR.plugins.setLang("showblocks","uk",{toolbar:"Показувати блоки"});
