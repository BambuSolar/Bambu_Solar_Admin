CKEDITOR.plugins.setLang("showblocks","sr",{toolbar:"Show Blocks"});
