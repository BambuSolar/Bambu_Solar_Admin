CKEDITOR.plugins.setLang("showblocks","pt",{toolbar:"Exibir blocos"});
