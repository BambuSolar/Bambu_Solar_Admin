CKEDITOR.plugins.setLang("showblocks","mk",{toolbar:"Show Blocks"});
