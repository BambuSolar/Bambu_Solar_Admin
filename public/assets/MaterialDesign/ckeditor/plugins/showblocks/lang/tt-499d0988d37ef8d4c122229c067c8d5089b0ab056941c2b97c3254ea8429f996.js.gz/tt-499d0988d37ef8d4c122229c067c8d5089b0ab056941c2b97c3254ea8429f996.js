CKEDITOR.plugins.setLang("showblocks","tt",{toolbar:"Блокларны күрсәтү"});
