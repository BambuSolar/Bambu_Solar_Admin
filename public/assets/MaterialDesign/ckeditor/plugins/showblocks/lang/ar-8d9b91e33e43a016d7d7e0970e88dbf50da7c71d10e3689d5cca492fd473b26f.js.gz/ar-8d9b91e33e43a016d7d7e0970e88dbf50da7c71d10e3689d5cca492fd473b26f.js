CKEDITOR.plugins.setLang("showblocks","ar",{toolbar:"مخطط تفصيلي"});
