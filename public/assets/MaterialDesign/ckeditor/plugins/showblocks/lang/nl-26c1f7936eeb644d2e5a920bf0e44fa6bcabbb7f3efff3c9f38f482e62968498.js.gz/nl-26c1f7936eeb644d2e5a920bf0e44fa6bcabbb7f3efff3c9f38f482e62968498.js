CKEDITOR.plugins.setLang("showblocks","nl",{toolbar:"Toon blokken"});
