CKEDITOR.plugins.setLang("showblocks","sv",{toolbar:"Visa block"});
