CKEDITOR.plugins.setLang("showblocks","hr",{toolbar:"Prikaži blokove"});
