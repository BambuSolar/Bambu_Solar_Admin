CKEDITOR.plugins.setLang("showblocks","ug",{toolbar:"بۆلەكنى كۆرسەت"});
