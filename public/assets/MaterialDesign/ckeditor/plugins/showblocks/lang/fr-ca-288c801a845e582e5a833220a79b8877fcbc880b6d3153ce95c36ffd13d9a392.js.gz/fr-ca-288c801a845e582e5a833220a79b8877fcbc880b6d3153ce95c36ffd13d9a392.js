CKEDITOR.plugins.setLang("showblocks","fr-ca",{toolbar:"Afficher les blocs"});
