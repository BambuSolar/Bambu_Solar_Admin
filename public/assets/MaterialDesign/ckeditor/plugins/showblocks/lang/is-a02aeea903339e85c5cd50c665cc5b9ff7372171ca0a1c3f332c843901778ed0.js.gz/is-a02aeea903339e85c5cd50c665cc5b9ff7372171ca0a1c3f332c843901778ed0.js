CKEDITOR.plugins.setLang("showblocks","is",{toolbar:"Sýna blokkir"});
