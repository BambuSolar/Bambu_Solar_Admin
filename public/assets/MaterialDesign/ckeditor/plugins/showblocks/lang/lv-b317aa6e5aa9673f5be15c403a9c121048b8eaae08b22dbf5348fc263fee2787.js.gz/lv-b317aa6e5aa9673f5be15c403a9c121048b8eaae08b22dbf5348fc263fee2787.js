CKEDITOR.plugins.setLang("showblocks","lv",{toolbar:"Parādīt blokus"});
