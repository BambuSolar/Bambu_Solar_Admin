CKEDITOR.plugins.setLang("showblocks","cs",{toolbar:"Ukázat bloky"});
