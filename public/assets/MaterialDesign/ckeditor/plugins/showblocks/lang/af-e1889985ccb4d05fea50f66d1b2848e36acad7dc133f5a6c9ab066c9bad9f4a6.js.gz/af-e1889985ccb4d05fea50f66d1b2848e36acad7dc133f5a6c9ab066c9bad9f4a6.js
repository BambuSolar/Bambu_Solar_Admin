CKEDITOR.plugins.setLang("showblocks","af",{toolbar:"Toon blokke"});
