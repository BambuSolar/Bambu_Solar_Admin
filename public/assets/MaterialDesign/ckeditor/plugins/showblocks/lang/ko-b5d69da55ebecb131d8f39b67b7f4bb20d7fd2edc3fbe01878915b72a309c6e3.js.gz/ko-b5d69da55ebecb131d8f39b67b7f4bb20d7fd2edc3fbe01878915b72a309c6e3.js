CKEDITOR.plugins.setLang("showblocks","ko",{toolbar:"블록 보기"});
