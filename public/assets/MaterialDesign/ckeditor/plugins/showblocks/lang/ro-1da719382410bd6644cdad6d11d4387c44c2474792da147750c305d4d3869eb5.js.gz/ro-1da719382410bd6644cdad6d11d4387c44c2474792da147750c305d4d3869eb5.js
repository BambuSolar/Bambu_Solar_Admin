CKEDITOR.plugins.setLang("showblocks","ro",{toolbar:"Arată blocurile"});
