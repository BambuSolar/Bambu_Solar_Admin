CKEDITOR.plugins.setLang("showblocks","fi",{toolbar:"Näytä elementit"});
