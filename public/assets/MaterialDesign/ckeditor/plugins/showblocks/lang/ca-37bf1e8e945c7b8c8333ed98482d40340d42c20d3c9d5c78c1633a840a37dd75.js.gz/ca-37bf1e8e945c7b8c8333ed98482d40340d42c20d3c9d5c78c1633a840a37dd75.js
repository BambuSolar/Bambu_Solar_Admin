CKEDITOR.plugins.setLang("showblocks","ca",{toolbar:"Mostra els blocs"});
