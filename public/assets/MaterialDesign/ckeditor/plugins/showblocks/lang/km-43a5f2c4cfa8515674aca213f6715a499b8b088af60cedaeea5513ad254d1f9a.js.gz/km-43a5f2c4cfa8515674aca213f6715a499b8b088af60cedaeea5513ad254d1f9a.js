CKEDITOR.plugins.setLang("showblocks","km",{toolbar:"បង្ហាញ​ប្លក់"});
