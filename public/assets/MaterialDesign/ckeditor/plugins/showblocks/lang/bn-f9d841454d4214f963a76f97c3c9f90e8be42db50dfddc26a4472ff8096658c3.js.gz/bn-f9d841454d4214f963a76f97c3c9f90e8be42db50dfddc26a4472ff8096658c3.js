CKEDITOR.plugins.setLang("showblocks","bn",{toolbar:"Show Blocks"});
