CKEDITOR.plugins.setLang("showblocks","bg",{toolbar:"Показва блокове"});
