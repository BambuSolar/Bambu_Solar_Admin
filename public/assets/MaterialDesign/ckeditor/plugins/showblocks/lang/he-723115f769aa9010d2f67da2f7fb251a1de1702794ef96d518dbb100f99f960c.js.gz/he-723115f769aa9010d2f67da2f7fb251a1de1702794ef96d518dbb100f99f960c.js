CKEDITOR.plugins.setLang("showblocks","he",{toolbar:"הצגת בלוקים"});
