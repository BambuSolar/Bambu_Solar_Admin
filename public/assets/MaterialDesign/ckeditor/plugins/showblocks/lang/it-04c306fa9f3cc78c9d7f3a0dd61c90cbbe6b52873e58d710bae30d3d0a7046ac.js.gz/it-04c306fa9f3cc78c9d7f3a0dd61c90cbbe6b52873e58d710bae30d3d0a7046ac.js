CKEDITOR.plugins.setLang("showblocks","it",{toolbar:"Visualizza Blocchi"});
