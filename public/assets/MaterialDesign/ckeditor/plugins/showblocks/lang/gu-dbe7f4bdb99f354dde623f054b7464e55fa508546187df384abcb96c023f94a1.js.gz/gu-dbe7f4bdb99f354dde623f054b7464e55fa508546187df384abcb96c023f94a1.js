CKEDITOR.plugins.setLang("showblocks","gu",{toolbar:"બ્લૉક બતાવવું"});
