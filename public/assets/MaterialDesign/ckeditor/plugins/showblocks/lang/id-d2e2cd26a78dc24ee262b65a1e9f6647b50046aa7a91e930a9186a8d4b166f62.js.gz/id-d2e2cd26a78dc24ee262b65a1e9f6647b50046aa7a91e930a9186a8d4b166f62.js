CKEDITOR.plugins.setLang("showblocks","id",{toolbar:"Perlihatkan Blok"});
