CKEDITOR.plugins.setLang("showblocks","ka",{toolbar:"არეების ჩვენება"});
