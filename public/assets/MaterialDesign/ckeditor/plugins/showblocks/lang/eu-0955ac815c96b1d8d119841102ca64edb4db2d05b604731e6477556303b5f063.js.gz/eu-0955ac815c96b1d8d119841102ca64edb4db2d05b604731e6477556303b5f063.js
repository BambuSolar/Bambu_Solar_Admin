CKEDITOR.plugins.setLang("showblocks","eu",{toolbar:"Erakutsi blokeak"});
