CKEDITOR.plugins.setLang("showblocks","gl",{toolbar:"Amosar os bloques"});
