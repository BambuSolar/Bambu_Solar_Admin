CKEDITOR.plugins.setLang("showblocks","pl",{toolbar:"Pokaż bloki"});
