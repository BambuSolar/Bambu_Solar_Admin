CKEDITOR.plugins.setLang("showblocks","vi",{toolbar:"Hiển thị các khối"});
