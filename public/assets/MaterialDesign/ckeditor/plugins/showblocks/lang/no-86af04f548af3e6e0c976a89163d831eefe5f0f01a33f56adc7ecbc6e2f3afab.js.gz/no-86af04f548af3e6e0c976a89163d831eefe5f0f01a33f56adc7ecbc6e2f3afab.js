CKEDITOR.plugins.setLang("showblocks","no",{toolbar:"Vis blokker"});
