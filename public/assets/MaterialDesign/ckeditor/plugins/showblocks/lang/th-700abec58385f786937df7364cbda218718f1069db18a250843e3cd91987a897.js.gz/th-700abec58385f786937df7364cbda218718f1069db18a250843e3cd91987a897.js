CKEDITOR.plugins.setLang("showblocks","th",{toolbar:"แสดงบล็อคข้อมูล"});
