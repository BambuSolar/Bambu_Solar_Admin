CKEDITOR.plugins.setLang("showblocks","cy",{toolbar:"Dangos Blociau"});
