CKEDITOR.plugins.setLang("showblocks","en-gb",{toolbar:"Show Blocks"});
