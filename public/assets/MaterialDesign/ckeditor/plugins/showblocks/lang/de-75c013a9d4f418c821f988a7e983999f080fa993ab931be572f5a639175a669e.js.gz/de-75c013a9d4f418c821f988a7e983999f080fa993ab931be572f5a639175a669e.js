CKEDITOR.plugins.setLang("showblocks","de",{toolbar:"Blöcke anzeigen"});
