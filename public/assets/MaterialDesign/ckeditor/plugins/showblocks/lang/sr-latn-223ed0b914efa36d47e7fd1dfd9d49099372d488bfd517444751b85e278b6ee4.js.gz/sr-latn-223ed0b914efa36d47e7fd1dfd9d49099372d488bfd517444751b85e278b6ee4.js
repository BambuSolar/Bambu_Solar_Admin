CKEDITOR.plugins.setLang("showblocks","sr-latn",{toolbar:"Show Blocks"});
