CKEDITOR.plugins.setLang("showblocks","eo",{toolbar:"Montri la blokojn"});
