CKEDITOR.plugins.setLang("showblocks","bs",{toolbar:"Show Blocks"});
