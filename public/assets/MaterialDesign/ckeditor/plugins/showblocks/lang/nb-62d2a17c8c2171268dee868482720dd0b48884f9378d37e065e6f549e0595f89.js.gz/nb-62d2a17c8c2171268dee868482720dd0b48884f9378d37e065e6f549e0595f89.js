CKEDITOR.plugins.setLang("showblocks","nb",{toolbar:"Vis blokker"});
