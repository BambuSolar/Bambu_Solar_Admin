CKEDITOR.plugins.setLang("showblocks","tr",{toolbar:"Blokları Göster"});
