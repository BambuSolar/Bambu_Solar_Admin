CKEDITOR.plugins.setLang("showblocks","hu",{toolbar:"Blokkok megjelenítése"});
