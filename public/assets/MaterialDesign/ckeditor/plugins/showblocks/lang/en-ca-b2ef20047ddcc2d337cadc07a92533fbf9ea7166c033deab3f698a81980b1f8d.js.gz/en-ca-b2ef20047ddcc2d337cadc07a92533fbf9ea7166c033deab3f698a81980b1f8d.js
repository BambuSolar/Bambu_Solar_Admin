CKEDITOR.plugins.setLang("showblocks","en-ca",{toolbar:"Show Blocks"});
