CKEDITOR.plugins.setLang("showblocks","pt-br",{toolbar:"Mostrar blocos de código"});
