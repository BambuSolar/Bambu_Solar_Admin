CKEDITOR.plugins.setLang("showblocks","en",{toolbar:"Show Blocks"});
