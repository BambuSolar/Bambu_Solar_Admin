CKEDITOR.plugins.setLang("pagebreak","ms",{alt:"Page Break",toolbar:"Insert Page Break for Printing"});
