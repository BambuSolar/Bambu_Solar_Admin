CKEDITOR.plugins.setLang("pagebreak","sr-latn",{alt:"Page Break",toolbar:"Insert Page Break for Printing"});
