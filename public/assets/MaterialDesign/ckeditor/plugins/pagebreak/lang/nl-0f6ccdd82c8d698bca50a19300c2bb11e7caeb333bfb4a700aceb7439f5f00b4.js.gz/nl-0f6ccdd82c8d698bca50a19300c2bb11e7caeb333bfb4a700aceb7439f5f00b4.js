CKEDITOR.plugins.setLang("pagebreak","nl",{alt:"Pagina-einde",toolbar:"Pagina-einde invoegen"});
