CKEDITOR.plugins.setLang("pagebreak","sk",{alt:"Zalomenie strany",toolbar:"Vložiť oddeľovač stránky pre tlač"});
