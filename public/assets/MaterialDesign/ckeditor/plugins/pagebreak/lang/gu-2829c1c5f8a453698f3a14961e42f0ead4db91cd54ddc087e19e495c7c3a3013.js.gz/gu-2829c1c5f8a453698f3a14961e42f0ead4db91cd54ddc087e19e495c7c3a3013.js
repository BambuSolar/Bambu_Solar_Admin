CKEDITOR.plugins.setLang("pagebreak","gu",{alt:"નવું પાનું",toolbar:"ઇન્સર્ટ પેજબ્રેક/પાનાને અલગ કરવું/દાખલ કરવું"});
