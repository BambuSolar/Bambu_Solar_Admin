CKEDITOR.plugins.setLang("pagebreak","no",{alt:"Sideskift",toolbar:"Sett inn sideskift for utskrift"});
