CKEDITOR.plugins.setLang("pagebreak","tr",{alt:"Sayfa Sonu",toolbar:"Sayfa Sonu Ekle"});
