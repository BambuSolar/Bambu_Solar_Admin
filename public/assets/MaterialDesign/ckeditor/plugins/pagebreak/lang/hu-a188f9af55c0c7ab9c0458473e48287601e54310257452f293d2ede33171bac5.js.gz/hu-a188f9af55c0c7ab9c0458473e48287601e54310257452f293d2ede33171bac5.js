CKEDITOR.plugins.setLang("pagebreak","hu",{alt:"Oldaltörés",toolbar:"Oldaltörés beillesztése"});
