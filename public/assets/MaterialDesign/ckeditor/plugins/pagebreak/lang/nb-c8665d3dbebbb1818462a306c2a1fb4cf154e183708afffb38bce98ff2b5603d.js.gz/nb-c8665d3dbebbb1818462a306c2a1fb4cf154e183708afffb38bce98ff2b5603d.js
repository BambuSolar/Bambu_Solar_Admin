CKEDITOR.plugins.setLang("pagebreak","nb",{alt:"Sideskift",toolbar:"Sett inn sideskift for utskrift"});
