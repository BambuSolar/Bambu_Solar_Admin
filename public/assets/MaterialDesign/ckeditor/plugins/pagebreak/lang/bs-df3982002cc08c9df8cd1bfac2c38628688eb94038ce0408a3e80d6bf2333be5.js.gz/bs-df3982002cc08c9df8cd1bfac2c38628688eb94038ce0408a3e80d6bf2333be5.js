CKEDITOR.plugins.setLang("pagebreak","bs",{alt:"Page Break",toolbar:"Insert Page Break for Printing"});
