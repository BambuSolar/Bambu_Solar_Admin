CKEDITOR.plugins.setLang("pagebreak","sv",{alt:"Sidbrytning",toolbar:"Infoga sidbrytning för utskrift"});
