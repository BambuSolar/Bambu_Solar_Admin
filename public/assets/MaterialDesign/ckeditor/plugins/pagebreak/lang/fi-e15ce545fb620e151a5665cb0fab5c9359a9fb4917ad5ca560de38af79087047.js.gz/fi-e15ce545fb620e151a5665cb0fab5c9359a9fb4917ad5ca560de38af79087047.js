CKEDITOR.plugins.setLang("pagebreak","fi",{alt:"Sivunvaihto",toolbar:"Lisää sivunvaihto"});
