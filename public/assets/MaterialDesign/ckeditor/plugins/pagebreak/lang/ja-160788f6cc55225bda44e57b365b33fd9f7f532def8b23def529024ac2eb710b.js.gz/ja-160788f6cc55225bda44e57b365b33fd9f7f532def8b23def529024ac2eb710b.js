CKEDITOR.plugins.setLang("pagebreak","ja",{alt:"改ページ",toolbar:"印刷の為に改ページ挿入"});
