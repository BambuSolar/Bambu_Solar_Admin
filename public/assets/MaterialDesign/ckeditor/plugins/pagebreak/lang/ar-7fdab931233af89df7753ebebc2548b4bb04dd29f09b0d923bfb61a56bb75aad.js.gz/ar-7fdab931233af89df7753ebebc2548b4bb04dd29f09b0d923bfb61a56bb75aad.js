CKEDITOR.plugins.setLang("pagebreak","ar",{alt:"فاصل الصفحة",toolbar:"إدخال صفحة جديدة"});
