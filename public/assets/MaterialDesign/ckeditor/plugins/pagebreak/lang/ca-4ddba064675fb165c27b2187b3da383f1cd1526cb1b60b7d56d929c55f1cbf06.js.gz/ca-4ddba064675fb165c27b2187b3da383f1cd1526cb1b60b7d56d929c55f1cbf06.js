CKEDITOR.plugins.setLang("pagebreak","ca",{alt:"Salt de pàgina",toolbar:"Insereix salt de pàgina"});
