CKEDITOR.plugins.setLang("pagebreak","da",{alt:"Sideskift",toolbar:"Indsæt sideskift"});
