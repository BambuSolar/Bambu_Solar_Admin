CKEDITOR.plugins.setLang("pagebreak","he",{alt:"שבירת דף",toolbar:"הוספת שבירת דף"});
