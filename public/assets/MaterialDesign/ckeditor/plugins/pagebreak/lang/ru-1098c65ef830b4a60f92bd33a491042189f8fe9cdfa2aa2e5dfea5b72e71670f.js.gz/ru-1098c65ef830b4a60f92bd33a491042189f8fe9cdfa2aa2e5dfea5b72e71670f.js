CKEDITOR.plugins.setLang("pagebreak","ru",{alt:"Разрыв страницы",toolbar:"Вставить разрыв страницы для печати"});
