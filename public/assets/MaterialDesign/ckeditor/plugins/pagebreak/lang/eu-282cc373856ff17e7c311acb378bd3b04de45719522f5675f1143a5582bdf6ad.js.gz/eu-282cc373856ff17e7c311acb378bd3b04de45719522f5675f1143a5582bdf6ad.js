CKEDITOR.plugins.setLang("pagebreak","eu",{alt:"Orrialde-jauzia",toolbar:"Txertatu orrialde-jauzia inprimatzean"});
