CKEDITOR.plugins.setLang("pagebreak","id",{alt:"Halaman Istirahat",toolbar:"Sisip Halaman Istirahat untuk Pencetakan "});
