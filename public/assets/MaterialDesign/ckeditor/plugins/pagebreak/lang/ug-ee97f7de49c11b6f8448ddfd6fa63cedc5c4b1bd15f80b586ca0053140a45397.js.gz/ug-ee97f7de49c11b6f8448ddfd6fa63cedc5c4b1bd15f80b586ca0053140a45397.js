CKEDITOR.plugins.setLang("pagebreak","ug",{alt:"بەت ئايرىغۇچ",toolbar:"بەت ئايرىغۇچ قىستۇر"});
