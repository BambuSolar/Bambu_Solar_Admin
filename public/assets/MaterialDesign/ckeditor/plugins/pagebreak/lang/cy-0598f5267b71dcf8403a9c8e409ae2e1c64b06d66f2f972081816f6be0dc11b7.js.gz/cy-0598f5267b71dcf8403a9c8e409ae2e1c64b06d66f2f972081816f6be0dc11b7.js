CKEDITOR.plugins.setLang("pagebreak","cy",{alt:"Toriad Tudalen",toolbar:"Mewnosod Toriad Tudalen i Argraffu"});
