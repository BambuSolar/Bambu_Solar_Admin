CKEDITOR.plugins.setLang("pagebreak","lt",{alt:"Puslapio skirtukas",toolbar:"Įterpti puslapių skirtuką"});
