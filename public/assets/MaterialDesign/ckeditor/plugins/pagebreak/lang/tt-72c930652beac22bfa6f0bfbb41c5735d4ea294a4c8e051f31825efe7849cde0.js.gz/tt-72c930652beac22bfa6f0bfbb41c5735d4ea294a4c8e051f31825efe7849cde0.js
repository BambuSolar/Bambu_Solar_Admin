CKEDITOR.plugins.setLang("pagebreak","tt",{alt:"Бит бүлгече",toolbar:"Бастыру өчен бит бүлгечен өстәү"});
