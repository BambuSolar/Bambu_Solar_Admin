CKEDITOR.plugins.setLang("pagebreak","uk",{alt:"Розрив Сторінки",toolbar:"Вставити розрив сторінки"});
