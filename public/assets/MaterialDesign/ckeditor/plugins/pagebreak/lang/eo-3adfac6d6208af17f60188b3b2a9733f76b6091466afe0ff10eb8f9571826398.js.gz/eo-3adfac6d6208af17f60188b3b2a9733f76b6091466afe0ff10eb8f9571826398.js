CKEDITOR.plugins.setLang("pagebreak","eo",{alt:"Paĝavanco",toolbar:"Enmeti Paĝavancon por Presado"});
