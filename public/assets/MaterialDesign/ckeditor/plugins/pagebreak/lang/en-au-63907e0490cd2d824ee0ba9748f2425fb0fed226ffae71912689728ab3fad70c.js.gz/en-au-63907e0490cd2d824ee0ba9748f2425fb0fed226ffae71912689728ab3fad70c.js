CKEDITOR.plugins.setLang("pagebreak","en-au",{alt:"Page Break",toolbar:"Insert Page Break for Printing"});
