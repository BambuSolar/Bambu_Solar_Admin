CKEDITOR.plugins.setLang("pagebreak","lv",{alt:"Lapas pārnesums",toolbar:"Ievietot lapas pārtraukumu drukai"});
