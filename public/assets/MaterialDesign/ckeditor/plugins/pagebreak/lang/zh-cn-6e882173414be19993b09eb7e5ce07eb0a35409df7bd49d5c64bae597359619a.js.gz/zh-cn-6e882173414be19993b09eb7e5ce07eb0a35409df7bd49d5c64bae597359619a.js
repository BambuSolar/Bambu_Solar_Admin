CKEDITOR.plugins.setLang("pagebreak","zh-cn",{alt:"分页符",toolbar:"插入打印分页符"});
