CKEDITOR.plugins.setLang("pagebreak","bn",{alt:"Page Break",toolbar:"পেজ ব্রেক"});
