CKEDITOR.plugins.setLang("pagebreak","sl",{alt:"Prelom strani",toolbar:"Vstavi prelom strani"});
