CKEDITOR.plugins.setLang("pagebreak","cs",{alt:"Konec stránky",toolbar:"Vložit konec stránky"});
