CKEDITOR.plugins.setLang("pagebreak","pl",{alt:"Wstaw podział strony",toolbar:"Wstaw podział strony"});
