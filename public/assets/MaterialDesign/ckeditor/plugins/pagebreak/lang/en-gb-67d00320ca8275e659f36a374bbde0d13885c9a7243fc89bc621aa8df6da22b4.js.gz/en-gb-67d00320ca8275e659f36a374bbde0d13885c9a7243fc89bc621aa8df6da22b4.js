CKEDITOR.plugins.setLang("pagebreak","en-gb",{alt:"Page Break",toolbar:"Insert Page Break for Printing"});
