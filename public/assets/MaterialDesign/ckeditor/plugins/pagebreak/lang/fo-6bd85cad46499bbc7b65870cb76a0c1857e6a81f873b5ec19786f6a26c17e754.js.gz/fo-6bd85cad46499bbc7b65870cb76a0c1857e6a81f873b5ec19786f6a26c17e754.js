CKEDITOR.plugins.setLang("pagebreak","fo",{alt:"Síðuskift",toolbar:"Ger síðuskift"});
