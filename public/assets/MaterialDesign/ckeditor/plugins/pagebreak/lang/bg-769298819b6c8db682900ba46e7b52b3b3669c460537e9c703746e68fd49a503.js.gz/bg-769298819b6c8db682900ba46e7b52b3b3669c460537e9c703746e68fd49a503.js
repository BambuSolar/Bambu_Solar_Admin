CKEDITOR.plugins.setLang("pagebreak","bg",{alt:"Разделяне на страници",toolbar:"Вмъкване на нова страница при печат"});
