CKEDITOR.plugins.setLang("pagebreak","ko",{alt:"페이지 나누기",toolbar:"인쇄시 페이지 나누기 삽입"});
