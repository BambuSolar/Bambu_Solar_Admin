CKEDITOR.plugins.setLang("pagebreak","af",{alt:"Bladsy-einde",toolbar:"Bladsy-einde invoeg"});
