CKEDITOR.plugins.setLang("pagebreak","de-ch",{alt:"Seitenumbruch",toolbar:"Seitenumbruch zum Drucken einfügen"});
