CKEDITOR.plugins.setLang("pagebreak","el",{alt:"Αλλαγή Σελίδας",toolbar:"Εισαγωγή Τέλους Σελίδας για Εκτύπωση"});
