CKEDITOR.plugins.setLang("pagebreak","mn",{alt:"Page Break",toolbar:"Хуудас тусгаарлагч оруулах"});
