CKEDITOR.plugins.setLang("pagebreak","th",{alt:"ตัวแบ่งหน้า",toolbar:"แทรกตัวแบ่งหน้า Page Break"});
