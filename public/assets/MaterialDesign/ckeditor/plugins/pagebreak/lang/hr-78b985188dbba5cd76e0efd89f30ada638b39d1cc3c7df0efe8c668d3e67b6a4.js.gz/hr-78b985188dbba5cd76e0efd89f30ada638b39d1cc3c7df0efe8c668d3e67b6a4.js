CKEDITOR.plugins.setLang("pagebreak","hr",{alt:"Prijelom stranice",toolbar:"Ubaci prijelom stranice"});
