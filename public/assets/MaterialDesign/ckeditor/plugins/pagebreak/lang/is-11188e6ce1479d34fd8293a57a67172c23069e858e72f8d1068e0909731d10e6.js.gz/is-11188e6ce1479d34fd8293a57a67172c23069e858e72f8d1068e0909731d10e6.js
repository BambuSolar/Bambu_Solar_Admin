CKEDITOR.plugins.setLang("pagebreak","is",{alt:"Page Break",toolbar:"Setja inn síðuskil"});
