CKEDITOR.plugins.setLang("pagebreak","sr",{alt:"Page Break",toolbar:"Insert Page Break for Printing"});
