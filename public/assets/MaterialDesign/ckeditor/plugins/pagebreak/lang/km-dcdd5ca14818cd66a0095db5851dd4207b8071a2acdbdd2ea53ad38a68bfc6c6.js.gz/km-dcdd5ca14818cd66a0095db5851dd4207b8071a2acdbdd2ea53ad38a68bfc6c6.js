CKEDITOR.plugins.setLang("pagebreak","km",{alt:"បំបែក​ទំព័រ",toolbar:"បន្ថែម​ការ​បំបែក​ទំព័រ​មុន​បោះពុម្ព"});
