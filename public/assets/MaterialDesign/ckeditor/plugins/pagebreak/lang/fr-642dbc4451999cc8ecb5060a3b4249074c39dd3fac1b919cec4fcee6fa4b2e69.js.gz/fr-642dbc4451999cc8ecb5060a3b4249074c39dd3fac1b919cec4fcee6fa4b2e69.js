CKEDITOR.plugins.setLang("pagebreak","fr",{alt:"Saut de page",toolbar:"Insérer un saut de page pour l'impression"});
