CKEDITOR.plugins.setLang("pagebreak","fr-ca",{alt:"Saut de page",toolbar:"Insérer un saut de page à l'impression"});
