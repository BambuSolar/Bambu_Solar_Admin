CKEDITOR.plugins.setLang("pagebreak","ka",{alt:"გვერდის წყვეტა",toolbar:"გვერდის წყვეტა ბეჭდვისთვის"});
