CKEDITOR.plugins.setLang("pagebreak","pt-br",{alt:"Quebra de Página",toolbar:"Inserir Quebra de Página"});
