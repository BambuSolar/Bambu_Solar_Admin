CKEDITOR.plugins.setLang("pagebreak","ro",{alt:"Page Break",toolbar:"Inserează separator de pagină (Page Break)"});
