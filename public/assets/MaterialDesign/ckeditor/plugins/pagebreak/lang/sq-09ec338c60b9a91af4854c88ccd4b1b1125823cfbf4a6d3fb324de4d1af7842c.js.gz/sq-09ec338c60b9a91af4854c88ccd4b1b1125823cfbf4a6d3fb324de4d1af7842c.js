CKEDITOR.plugins.setLang("pagebreak","sq",{alt:"Thyerja e Faqes",toolbar:"Vendos Thyerje Faqeje për Shtyp"});
