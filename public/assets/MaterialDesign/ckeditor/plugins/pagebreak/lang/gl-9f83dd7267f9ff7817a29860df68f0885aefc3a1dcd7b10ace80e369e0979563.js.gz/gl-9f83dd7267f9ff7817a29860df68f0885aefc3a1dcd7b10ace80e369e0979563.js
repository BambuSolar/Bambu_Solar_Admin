CKEDITOR.plugins.setLang("pagebreak","gl",{alt:"Quebra de páxina",toolbar:"Inserir quebra de páxina"});
