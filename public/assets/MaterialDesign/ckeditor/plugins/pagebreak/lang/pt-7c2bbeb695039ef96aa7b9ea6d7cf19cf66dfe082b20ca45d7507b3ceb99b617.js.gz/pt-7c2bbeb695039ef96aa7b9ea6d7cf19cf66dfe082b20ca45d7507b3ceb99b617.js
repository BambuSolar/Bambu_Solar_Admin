CKEDITOR.plugins.setLang("pagebreak","pt",{alt:"Quebra de página",toolbar:"Inserir quebra de página"});
