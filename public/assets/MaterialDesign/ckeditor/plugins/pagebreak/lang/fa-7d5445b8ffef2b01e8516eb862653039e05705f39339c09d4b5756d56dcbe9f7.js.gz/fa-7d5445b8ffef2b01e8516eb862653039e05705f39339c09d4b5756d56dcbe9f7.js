CKEDITOR.plugins.setLang("pagebreak","fa",{alt:"شکستن صفحه",toolbar:"گنجاندن شکستگی پایان برگه"});
