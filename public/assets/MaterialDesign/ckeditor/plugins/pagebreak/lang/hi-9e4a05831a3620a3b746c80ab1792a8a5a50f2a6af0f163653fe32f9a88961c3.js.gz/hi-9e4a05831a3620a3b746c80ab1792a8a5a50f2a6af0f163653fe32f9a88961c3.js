CKEDITOR.plugins.setLang("pagebreak","hi",{alt:"पेज ब्रेक",toolbar:"पेज ब्रेक इन्सर्ट् करें"});
