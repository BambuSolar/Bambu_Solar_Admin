CKEDITOR.plugins.setLang("pagebreak","es",{alt:"Salto de página",toolbar:"Insertar Salto de Página"});
