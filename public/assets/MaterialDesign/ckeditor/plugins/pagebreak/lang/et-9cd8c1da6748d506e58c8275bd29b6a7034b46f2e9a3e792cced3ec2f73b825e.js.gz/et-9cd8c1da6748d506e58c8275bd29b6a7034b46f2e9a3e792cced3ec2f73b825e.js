CKEDITOR.plugins.setLang("pagebreak","et",{alt:"Lehevahetuskoht",toolbar:"Lehevahetuskoha sisestamine"});
