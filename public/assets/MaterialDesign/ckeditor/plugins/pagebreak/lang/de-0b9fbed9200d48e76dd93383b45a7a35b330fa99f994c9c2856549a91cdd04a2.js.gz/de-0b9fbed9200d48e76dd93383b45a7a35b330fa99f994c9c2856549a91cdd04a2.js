CKEDITOR.plugins.setLang("pagebreak","de",{alt:"Seitenumbruch",toolbar:"Seitenumbruch zum Drucken einfügen"});
