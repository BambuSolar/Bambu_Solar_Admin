CKEDITOR.plugins.setLang("pagebreak","en-ca",{alt:"Page Break",toolbar:"Insert Page Break for Printing"});
