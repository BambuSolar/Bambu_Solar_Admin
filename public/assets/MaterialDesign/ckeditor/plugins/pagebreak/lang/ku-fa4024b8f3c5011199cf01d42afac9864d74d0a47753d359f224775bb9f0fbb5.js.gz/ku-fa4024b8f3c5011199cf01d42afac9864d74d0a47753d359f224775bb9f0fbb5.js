CKEDITOR.plugins.setLang("pagebreak","ku",{alt:"پشووی پەڕە",toolbar:"دانانی پشووی پەڕە بۆ چاپکردن"});
