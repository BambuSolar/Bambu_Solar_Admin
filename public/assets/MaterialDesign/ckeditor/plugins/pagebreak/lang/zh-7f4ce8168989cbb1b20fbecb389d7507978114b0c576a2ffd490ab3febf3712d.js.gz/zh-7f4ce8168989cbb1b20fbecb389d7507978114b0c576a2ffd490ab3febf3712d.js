CKEDITOR.plugins.setLang("pagebreak","zh",{alt:"換頁",toolbar:"插入換頁符號以便列印"});
