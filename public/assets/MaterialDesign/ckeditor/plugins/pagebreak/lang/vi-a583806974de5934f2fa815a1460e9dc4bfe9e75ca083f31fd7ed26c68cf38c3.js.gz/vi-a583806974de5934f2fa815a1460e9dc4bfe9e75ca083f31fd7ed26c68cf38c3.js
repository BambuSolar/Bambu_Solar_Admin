CKEDITOR.plugins.setLang("pagebreak","vi",{alt:"Ngắt trang",toolbar:"Chèn ngắt trang"});
