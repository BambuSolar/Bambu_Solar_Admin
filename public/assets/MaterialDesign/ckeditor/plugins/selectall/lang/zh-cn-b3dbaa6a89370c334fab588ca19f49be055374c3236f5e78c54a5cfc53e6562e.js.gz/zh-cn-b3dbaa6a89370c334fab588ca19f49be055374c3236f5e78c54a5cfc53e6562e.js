CKEDITOR.plugins.setLang("selectall","zh-cn",{toolbar:"全选"});
