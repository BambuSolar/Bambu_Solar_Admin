CKEDITOR.plugins.setLang("selectall","ko",{toolbar:"모두 선택"});
