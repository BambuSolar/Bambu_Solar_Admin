CKEDITOR.plugins.setLang("selectall","hu",{toolbar:"Mindent kijelöl"});
