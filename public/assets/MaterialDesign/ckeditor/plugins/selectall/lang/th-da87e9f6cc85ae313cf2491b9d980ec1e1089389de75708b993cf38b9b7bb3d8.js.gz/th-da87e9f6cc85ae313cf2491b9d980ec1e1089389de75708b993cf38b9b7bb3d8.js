CKEDITOR.plugins.setLang("selectall","th",{toolbar:"เลือกทั้งหมด"});
