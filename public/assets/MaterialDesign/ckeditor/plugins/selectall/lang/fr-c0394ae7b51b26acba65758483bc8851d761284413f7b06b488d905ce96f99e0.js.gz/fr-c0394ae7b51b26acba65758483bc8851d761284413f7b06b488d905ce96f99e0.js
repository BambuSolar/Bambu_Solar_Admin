CKEDITOR.plugins.setLang("selectall","fr",{toolbar:"Tout sélectionner"});
