CKEDITOR.plugins.setLang("selectall","pl",{toolbar:"Zaznacz wszystko"});
