CKEDITOR.plugins.setLang("selectall","si",{toolbar:"සියල්ලම "});
