CKEDITOR.plugins.setLang("selectall","ro",{toolbar:"Selectează tot"});
