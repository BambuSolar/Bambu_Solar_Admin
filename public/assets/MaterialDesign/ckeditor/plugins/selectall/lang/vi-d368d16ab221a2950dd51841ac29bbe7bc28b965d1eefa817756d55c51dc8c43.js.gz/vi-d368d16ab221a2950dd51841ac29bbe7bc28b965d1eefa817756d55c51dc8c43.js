CKEDITOR.plugins.setLang("selectall","vi",{toolbar:"Chọn tất cả"});
