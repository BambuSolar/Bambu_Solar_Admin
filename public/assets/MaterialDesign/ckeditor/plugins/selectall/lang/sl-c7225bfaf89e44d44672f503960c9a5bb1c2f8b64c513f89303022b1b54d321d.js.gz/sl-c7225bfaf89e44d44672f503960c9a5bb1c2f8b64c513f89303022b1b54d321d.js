CKEDITOR.plugins.setLang("selectall","sl",{toolbar:"Izberi vse"});
