CKEDITOR.plugins.setLang("selectall","id",{toolbar:"Pilih Semua"});
