CKEDITOR.plugins.setLang("selectall","en-au",{toolbar:"Select All"});
