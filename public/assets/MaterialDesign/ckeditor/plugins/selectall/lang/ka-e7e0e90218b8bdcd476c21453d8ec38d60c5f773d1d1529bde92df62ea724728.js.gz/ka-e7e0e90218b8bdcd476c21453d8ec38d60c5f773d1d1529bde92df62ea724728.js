CKEDITOR.plugins.setLang("selectall","ka",{toolbar:"ყველაფრის მონიშნვა"});
