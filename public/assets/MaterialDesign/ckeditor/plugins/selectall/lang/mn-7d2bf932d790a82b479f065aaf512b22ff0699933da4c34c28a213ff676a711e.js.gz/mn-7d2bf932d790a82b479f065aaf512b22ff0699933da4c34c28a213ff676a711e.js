CKEDITOR.plugins.setLang("selectall","mn",{toolbar:"Бүгдийг нь сонгох"});
