CKEDITOR.plugins.setLang("selectall","en-ca",{toolbar:"Select All"});
