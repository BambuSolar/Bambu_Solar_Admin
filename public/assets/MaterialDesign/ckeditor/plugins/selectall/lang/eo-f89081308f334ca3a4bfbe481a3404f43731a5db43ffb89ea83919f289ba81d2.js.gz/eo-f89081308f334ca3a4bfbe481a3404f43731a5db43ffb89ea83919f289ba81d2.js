CKEDITOR.plugins.setLang("selectall","eo",{toolbar:"Elekti ĉion"});
