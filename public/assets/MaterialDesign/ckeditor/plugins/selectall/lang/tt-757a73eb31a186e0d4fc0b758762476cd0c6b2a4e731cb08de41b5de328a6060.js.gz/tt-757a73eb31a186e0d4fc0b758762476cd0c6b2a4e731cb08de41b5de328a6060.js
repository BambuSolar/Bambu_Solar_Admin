CKEDITOR.plugins.setLang("selectall","tt",{toolbar:"Барысын сайлау"});
