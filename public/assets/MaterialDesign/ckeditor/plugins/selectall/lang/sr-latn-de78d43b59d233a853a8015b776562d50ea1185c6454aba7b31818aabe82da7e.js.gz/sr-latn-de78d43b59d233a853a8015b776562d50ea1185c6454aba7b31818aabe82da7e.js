CKEDITOR.plugins.setLang("selectall","sr-latn",{toolbar:"Označi sve"});
