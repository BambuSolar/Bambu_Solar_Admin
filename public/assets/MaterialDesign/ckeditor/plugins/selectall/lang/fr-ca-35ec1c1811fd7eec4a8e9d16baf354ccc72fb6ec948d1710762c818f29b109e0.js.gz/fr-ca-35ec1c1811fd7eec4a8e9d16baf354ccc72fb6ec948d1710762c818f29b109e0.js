CKEDITOR.plugins.setLang("selectall","fr-ca",{toolbar:"Sélectionner tout"});
