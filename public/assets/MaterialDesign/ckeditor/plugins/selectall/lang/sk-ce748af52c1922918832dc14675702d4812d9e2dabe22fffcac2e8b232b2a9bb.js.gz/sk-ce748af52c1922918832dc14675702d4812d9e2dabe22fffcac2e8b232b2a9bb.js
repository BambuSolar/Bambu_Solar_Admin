CKEDITOR.plugins.setLang("selectall","sk",{toolbar:"Vybrať všetko"});
