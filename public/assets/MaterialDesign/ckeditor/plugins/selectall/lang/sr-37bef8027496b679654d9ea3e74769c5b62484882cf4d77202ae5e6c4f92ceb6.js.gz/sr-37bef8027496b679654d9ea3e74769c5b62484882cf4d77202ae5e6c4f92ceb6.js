CKEDITOR.plugins.setLang("selectall","sr",{toolbar:"Означи све"});
