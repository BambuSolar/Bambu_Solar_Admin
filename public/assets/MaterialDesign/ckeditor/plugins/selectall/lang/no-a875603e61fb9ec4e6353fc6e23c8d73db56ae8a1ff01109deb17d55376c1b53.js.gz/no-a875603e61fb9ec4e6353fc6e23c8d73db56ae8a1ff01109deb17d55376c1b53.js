CKEDITOR.plugins.setLang("selectall","no",{toolbar:"Merk alt"});
