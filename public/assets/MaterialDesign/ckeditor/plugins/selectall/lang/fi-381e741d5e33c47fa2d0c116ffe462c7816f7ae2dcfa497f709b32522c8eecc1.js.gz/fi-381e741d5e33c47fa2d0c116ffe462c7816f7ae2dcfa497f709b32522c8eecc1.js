CKEDITOR.plugins.setLang("selectall","fi",{toolbar:"Valitse kaikki"});
