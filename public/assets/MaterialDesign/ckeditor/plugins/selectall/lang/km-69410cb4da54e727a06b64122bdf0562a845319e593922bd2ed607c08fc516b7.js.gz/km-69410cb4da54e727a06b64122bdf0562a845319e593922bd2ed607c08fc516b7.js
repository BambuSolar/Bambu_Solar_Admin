CKEDITOR.plugins.setLang("selectall","km",{toolbar:"រើស​ទាំង​អស់"});
