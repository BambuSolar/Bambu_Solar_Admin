CKEDITOR.plugins.setLang("selectall","nl",{toolbar:"Alles selecteren"});
