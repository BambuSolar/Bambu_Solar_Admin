CKEDITOR.plugins.setLang("selectall","el",{toolbar:"Επιλογή όλων"});
