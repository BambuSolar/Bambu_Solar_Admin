CKEDITOR.plugins.setLang("selectall","af",{toolbar:"Selekteer alles"});
