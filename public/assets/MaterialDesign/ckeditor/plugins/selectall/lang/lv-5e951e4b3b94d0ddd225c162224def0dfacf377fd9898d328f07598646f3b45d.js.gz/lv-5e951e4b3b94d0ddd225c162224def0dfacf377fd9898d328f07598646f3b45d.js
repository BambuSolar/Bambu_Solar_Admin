CKEDITOR.plugins.setLang("selectall","lv",{toolbar:"Iezīmēt visu"});
