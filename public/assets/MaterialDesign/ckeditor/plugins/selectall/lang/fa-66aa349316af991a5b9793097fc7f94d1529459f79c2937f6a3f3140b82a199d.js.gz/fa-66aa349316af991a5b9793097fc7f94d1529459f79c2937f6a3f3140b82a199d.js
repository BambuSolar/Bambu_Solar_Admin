CKEDITOR.plugins.setLang("selectall","fa",{toolbar:"گزینش همه"});
