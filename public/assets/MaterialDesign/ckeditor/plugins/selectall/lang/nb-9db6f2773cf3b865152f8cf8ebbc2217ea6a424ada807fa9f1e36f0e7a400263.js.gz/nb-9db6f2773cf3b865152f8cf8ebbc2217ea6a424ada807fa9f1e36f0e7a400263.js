CKEDITOR.plugins.setLang("selectall","nb",{toolbar:"Merk alt"});
