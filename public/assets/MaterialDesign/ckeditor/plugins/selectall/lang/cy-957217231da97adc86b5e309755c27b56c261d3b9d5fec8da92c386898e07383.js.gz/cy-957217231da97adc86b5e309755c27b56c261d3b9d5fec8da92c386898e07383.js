CKEDITOR.plugins.setLang("selectall","cy",{toolbar:"Dewis Popeth"});
