CKEDITOR.plugins.setLang("selectall","zh",{toolbar:"全選"});
