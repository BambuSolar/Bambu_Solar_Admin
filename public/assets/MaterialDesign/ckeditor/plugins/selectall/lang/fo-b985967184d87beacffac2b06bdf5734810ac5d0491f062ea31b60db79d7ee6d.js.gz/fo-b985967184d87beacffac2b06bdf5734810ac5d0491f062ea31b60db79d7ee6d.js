CKEDITOR.plugins.setLang("selectall","fo",{toolbar:"Markera alt"});
