CKEDITOR.plugins.setLang("selectall","sv",{toolbar:"Markera allt"});
