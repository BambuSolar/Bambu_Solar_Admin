CKEDITOR.plugins.setLang("selectall","ms",{toolbar:"Pilih Semua"});
