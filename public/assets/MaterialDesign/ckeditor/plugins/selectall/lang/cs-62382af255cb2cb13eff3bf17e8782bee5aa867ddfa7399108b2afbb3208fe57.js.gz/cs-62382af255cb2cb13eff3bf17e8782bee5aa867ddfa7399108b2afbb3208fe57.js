CKEDITOR.plugins.setLang("selectall","cs",{toolbar:"Vybrat vše"});
