CKEDITOR.plugins.setLang("selectall","ja",{toolbar:"すべて選択"});
