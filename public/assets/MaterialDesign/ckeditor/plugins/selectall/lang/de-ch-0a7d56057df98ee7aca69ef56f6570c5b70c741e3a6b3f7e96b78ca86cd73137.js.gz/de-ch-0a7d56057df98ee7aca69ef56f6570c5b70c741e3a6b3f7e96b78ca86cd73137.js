CKEDITOR.plugins.setLang("selectall","de-ch",{toolbar:"Alles auswählen"});
