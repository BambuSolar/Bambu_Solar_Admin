CKEDITOR.plugins.setLang("selectall","ug",{toolbar:"ھەممىنى تاللا"});
