CKEDITOR.plugins.setLang("selectall","sq",{toolbar:"Përzgjidh të Gjitha"});
