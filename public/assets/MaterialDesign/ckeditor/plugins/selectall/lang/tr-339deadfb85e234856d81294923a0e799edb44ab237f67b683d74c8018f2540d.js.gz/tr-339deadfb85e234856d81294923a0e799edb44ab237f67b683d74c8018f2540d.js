CKEDITOR.plugins.setLang("selectall","tr",{toolbar:"Tümünü Seç"});
