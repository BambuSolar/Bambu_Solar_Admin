CKEDITOR.plugins.setLang("selectall","de",{toolbar:"Alles auswählen"});
