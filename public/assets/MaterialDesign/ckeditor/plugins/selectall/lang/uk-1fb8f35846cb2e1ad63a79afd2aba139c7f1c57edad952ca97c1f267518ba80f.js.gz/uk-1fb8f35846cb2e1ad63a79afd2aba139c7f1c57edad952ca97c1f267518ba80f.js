CKEDITOR.plugins.setLang("selectall","uk",{toolbar:"Виділити все"});
