CKEDITOR.plugins.setLang("selectall","is",{toolbar:"Velja allt"});
