CKEDITOR.plugins.setLang("selectall","eu",{toolbar:"Hautatu dena"});
