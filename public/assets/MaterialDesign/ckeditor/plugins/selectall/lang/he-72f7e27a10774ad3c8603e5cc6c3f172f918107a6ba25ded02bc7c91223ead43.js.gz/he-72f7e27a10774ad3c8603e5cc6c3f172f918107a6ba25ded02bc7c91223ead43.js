CKEDITOR.plugins.setLang("selectall","he",{toolbar:"בחירת הכל"});
