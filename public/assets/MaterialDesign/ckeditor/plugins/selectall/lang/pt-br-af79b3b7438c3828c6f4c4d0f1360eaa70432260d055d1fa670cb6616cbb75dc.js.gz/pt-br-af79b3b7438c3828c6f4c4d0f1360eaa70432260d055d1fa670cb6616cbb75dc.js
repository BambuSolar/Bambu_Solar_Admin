CKEDITOR.plugins.setLang("selectall","pt-br",{toolbar:"Selecionar Tudo"});
