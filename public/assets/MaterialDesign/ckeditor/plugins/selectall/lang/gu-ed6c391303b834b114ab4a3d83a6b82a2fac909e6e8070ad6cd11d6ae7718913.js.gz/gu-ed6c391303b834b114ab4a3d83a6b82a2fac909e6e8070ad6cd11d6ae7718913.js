CKEDITOR.plugins.setLang("selectall","gu",{toolbar:"બઘું પસંદ કરવું"});
