CKEDITOR.plugins.setLang("selectall","et",{toolbar:"Kõige valimine"});
