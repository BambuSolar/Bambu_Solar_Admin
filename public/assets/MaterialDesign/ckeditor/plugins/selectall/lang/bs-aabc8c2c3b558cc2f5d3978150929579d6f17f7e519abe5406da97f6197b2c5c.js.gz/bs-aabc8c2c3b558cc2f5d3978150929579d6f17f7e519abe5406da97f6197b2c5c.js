CKEDITOR.plugins.setLang("selectall","bs",{toolbar:"Selektuj sve"});
