CKEDITOR.plugins.setLang("selectall","es",{toolbar:"Seleccionar Todo"});
