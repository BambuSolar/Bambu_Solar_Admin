CKEDITOR.plugins.setLang("selectall","hr",{toolbar:"Odaberi sve"});
