CKEDITOR.plugins.setLang("selectall","ar",{toolbar:"تحديد الكل"});
