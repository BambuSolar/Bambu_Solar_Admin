CKEDITOR.plugins.setLang("selectall","it",{toolbar:"Seleziona tutto"});
