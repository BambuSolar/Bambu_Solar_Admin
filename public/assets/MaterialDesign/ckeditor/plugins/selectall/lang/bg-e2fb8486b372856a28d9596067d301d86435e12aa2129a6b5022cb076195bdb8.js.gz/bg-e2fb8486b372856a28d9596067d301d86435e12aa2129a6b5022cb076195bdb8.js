CKEDITOR.plugins.setLang("selectall","bg",{toolbar:"Избери всичко"});
