CKEDITOR.plugins.setLang("selectall","da",{toolbar:"Vælg alt"});
