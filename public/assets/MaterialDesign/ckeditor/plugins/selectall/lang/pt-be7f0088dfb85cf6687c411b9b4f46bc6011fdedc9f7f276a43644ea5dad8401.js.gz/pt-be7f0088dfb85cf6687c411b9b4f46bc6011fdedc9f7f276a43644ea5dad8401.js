CKEDITOR.plugins.setLang("selectall","pt",{toolbar:"Selecionar tudo"});
