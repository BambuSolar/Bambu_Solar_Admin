CKEDITOR.plugins.setLang("selectall","ru",{toolbar:"Выделить все"});
