CKEDITOR.plugins.setLang("selectall","hi",{toolbar:"सब सॅलॅक्ट करें"});
