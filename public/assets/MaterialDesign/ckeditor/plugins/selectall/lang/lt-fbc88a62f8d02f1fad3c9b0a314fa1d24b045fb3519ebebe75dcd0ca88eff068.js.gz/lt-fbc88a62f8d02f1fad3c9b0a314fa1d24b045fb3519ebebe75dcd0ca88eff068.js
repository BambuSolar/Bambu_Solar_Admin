CKEDITOR.plugins.setLang("selectall","lt",{toolbar:"Pažymėti viską"});
