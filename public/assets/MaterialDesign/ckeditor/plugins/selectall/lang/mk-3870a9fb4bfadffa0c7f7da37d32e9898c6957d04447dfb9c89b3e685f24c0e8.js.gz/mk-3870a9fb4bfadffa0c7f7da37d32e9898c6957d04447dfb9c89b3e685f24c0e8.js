CKEDITOR.plugins.setLang("selectall","mk",{toolbar:"Select All"});
