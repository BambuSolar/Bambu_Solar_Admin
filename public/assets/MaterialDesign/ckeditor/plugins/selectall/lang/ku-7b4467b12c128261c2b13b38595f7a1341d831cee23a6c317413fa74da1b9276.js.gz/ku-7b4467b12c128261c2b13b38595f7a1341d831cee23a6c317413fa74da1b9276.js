CKEDITOR.plugins.setLang("selectall","ku",{toolbar:"دیاریکردنی هەمووی"});
