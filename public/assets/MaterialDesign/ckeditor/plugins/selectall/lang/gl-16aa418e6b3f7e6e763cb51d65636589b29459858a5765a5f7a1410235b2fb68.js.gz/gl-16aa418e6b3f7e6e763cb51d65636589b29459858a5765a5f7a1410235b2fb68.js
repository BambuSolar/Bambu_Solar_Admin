CKEDITOR.plugins.setLang("selectall","gl",{toolbar:"Seleccionar todo"});
