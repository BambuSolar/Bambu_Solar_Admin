CKEDITOR.plugins.setLang("selectall","ca",{toolbar:"Selecciona-ho tot"});
