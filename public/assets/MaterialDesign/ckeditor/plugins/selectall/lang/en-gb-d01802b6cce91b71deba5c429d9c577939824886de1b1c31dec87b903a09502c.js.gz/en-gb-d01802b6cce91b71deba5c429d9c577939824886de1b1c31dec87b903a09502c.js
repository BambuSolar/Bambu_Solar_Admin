CKEDITOR.plugins.setLang("selectall","en-gb",{toolbar:"Select All"});
