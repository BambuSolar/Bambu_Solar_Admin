CKEDITOR.plugins.setLang("selectall","bn",{toolbar:"সব সিলেক্ট করি"});
