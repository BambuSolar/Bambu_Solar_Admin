CKEDITOR.plugins.setLang("selectall","en",{toolbar:"Select All"});
