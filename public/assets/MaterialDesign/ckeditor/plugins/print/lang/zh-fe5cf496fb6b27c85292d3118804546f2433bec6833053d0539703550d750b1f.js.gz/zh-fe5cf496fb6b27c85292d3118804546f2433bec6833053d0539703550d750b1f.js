CKEDITOR.plugins.setLang("print","zh",{toolbar:"列印"});
