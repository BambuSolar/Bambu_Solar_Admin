CKEDITOR.plugins.setLang("print","es",{toolbar:"Imprimir"});
