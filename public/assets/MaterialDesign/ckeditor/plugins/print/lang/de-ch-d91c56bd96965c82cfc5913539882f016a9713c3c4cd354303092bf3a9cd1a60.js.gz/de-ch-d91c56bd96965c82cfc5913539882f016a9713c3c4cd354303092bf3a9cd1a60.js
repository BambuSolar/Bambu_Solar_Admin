CKEDITOR.plugins.setLang("print","de-ch",{toolbar:"Drucken"});
