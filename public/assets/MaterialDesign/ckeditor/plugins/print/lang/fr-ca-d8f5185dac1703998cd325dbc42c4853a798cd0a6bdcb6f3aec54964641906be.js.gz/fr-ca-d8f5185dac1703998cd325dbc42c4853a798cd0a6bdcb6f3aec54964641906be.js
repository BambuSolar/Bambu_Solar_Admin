CKEDITOR.plugins.setLang("print","fr-ca",{toolbar:"Imprimer"});
