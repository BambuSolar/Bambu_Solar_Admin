CKEDITOR.plugins.setLang("print","sl",{toolbar:"Natisni"});
