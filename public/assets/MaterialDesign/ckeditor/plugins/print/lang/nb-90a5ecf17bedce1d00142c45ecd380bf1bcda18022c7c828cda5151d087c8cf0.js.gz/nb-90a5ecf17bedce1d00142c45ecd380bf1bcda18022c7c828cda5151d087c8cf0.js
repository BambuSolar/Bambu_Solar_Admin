CKEDITOR.plugins.setLang("print","nb",{toolbar:"Skriv ut"});
