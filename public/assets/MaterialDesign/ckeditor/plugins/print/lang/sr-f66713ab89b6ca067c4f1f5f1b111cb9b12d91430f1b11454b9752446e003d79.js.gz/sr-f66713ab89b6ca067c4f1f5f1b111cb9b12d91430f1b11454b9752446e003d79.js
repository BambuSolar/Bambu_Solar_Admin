CKEDITOR.plugins.setLang("print","sr",{toolbar:"Штампа"});
