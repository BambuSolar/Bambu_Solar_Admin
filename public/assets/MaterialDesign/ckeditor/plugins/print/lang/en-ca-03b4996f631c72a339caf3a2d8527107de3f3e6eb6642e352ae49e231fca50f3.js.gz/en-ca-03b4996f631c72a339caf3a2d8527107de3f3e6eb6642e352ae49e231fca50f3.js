CKEDITOR.plugins.setLang("print","en-ca",{toolbar:"Print"});
