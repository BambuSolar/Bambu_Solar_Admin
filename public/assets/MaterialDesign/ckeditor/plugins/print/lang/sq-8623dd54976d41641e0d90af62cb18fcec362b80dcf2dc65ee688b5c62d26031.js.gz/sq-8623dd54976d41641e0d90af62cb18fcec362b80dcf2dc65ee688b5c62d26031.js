CKEDITOR.plugins.setLang("print","sq",{toolbar:"Shtype"});
