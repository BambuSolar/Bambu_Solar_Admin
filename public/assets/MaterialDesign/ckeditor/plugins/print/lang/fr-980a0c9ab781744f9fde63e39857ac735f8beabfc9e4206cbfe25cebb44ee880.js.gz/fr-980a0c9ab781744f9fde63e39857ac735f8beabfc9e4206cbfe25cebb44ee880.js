CKEDITOR.plugins.setLang("print","fr",{toolbar:"Imprimer"});
