CKEDITOR.plugins.setLang("print","cs",{toolbar:"Tisk"});
