CKEDITOR.plugins.setLang("print","tr",{toolbar:"Yazdır"});
