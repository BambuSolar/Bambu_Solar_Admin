CKEDITOR.plugins.setLang("print","ug",{toolbar:"باس "});
