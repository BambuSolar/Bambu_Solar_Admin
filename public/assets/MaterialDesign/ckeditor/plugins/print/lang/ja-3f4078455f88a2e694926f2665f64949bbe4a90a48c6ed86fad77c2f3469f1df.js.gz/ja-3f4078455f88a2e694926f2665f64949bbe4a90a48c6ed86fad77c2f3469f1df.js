CKEDITOR.plugins.setLang("print","ja",{toolbar:"印刷"});
