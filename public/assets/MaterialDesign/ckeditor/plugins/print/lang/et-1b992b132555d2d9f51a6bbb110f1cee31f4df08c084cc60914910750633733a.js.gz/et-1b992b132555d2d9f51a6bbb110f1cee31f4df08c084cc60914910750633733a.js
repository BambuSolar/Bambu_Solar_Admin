CKEDITOR.plugins.setLang("print","et",{toolbar:"Printimine"});
