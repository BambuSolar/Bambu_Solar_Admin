CKEDITOR.plugins.setLang("print","km",{toolbar:"បោះពុម្ព"});
