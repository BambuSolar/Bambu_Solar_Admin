CKEDITOR.plugins.setLang("print","el",{toolbar:"Εκτύπωση"});
