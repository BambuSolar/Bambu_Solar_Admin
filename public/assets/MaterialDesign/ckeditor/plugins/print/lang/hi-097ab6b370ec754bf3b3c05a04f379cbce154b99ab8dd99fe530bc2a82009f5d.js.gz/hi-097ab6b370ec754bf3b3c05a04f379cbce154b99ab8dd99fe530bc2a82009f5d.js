CKEDITOR.plugins.setLang("print","hi",{toolbar:"प्रिन्ट"});
