CKEDITOR.plugins.setLang("print","th",{toolbar:"สั่งพิมพ์"});
