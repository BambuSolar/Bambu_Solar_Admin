CKEDITOR.plugins.setLang("print","ku",{toolbar:"چاپکردن"});
