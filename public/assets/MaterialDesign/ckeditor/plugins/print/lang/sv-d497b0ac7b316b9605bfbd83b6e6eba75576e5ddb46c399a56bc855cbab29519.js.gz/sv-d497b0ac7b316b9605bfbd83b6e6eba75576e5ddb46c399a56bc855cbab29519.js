CKEDITOR.plugins.setLang("print","sv",{toolbar:"Skriv ut"});
