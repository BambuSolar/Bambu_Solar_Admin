CKEDITOR.plugins.setLang("print","sk",{toolbar:"Tlač"});
