CKEDITOR.plugins.setLang("print","zh-cn",{toolbar:"打印"});
