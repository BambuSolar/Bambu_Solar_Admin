CKEDITOR.plugins.setLang("print","gl",{toolbar:"Imprimir"});
