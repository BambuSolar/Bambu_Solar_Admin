CKEDITOR.plugins.setLang("print","ro",{toolbar:"Printează"});
