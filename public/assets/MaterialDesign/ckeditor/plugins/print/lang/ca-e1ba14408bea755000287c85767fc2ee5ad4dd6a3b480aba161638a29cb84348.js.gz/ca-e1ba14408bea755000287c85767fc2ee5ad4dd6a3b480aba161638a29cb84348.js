CKEDITOR.plugins.setLang("print","ca",{toolbar:"Imprimeix"});
