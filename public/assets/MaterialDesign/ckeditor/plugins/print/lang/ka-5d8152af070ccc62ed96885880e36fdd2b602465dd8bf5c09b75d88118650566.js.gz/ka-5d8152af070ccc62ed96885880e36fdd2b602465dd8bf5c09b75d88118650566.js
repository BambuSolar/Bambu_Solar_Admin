CKEDITOR.plugins.setLang("print","ka",{toolbar:"ბეჭდვა"});
