CKEDITOR.plugins.setLang("print","uk",{toolbar:"Друк"});
