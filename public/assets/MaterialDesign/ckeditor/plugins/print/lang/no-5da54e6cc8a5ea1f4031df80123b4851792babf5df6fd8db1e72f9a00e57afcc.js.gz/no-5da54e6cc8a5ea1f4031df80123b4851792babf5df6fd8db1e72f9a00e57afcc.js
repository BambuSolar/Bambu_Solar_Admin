CKEDITOR.plugins.setLang("print","no",{toolbar:"Skriv ut"});
