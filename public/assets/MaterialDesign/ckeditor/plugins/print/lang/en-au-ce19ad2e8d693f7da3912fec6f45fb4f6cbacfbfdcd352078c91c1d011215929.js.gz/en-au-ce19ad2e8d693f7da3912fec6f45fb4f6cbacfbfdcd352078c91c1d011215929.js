CKEDITOR.plugins.setLang("print","en-au",{toolbar:"Print"});
