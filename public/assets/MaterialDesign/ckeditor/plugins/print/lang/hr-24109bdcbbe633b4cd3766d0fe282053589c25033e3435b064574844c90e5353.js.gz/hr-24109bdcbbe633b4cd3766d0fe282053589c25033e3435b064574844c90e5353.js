CKEDITOR.plugins.setLang("print","hr",{toolbar:"Ispiši"});
