CKEDITOR.plugins.setLang("print","id",{toolbar:"Cetak"});
