CKEDITOR.plugins.setLang("print","lv",{toolbar:"Drukāt"});
