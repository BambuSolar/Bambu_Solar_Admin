CKEDITOR.plugins.setLang("print","it",{toolbar:"Stampa"});
