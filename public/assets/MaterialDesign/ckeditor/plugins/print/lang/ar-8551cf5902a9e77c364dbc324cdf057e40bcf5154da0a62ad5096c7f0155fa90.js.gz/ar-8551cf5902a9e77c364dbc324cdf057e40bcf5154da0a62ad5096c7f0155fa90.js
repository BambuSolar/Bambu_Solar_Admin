CKEDITOR.plugins.setLang("print","ar",{toolbar:"طباعة"});
