CKEDITOR.plugins.setLang("print","lt",{toolbar:"Spausdinti"});
