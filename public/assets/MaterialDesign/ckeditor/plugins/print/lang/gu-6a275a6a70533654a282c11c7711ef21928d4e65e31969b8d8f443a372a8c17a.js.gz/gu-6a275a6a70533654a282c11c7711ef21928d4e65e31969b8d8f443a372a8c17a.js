CKEDITOR.plugins.setLang("print","gu",{toolbar:"પ્રિન્ટ"});
