CKEDITOR.plugins.setLang("print","pt-br",{toolbar:"Imprimir"});
