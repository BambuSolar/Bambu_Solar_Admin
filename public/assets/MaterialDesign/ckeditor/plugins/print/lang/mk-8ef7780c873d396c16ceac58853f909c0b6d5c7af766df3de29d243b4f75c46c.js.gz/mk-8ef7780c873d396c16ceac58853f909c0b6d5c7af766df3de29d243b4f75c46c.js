CKEDITOR.plugins.setLang("print","mk",{toolbar:"Print"});
