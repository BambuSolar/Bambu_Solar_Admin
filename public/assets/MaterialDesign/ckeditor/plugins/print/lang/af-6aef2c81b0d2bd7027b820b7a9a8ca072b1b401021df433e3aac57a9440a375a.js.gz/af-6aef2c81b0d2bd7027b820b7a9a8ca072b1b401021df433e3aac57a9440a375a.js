CKEDITOR.plugins.setLang("print","af",{toolbar:"Druk"});
