CKEDITOR.plugins.setLang("print","vi",{toolbar:"In"});
