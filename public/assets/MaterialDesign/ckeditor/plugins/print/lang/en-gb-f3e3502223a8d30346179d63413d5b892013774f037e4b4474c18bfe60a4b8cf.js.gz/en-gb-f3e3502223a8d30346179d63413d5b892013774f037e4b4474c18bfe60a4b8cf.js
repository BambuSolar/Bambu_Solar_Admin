CKEDITOR.plugins.setLang("print","en-gb",{toolbar:"Print"});
