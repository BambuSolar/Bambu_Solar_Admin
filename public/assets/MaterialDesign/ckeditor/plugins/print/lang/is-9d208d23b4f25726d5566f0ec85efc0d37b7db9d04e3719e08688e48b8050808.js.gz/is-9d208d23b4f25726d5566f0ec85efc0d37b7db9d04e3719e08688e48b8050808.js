CKEDITOR.plugins.setLang("print","is",{toolbar:"Prenta"});
