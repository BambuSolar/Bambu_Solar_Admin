CKEDITOR.plugins.setLang("print","nl",{toolbar:"Afdrukken"});
