CKEDITOR.plugins.setLang("print","bs",{toolbar:"Štampaj"});
