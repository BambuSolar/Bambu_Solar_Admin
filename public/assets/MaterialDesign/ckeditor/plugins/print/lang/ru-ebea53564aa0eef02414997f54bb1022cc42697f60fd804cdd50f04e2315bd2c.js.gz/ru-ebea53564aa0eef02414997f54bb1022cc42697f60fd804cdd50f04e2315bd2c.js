CKEDITOR.plugins.setLang("print","ru",{toolbar:"Печать"});
