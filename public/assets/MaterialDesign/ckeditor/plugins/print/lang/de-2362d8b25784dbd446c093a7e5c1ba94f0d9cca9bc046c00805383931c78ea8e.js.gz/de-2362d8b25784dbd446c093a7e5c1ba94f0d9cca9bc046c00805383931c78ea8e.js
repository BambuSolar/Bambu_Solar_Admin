CKEDITOR.plugins.setLang("print","de",{toolbar:"Drucken"});
