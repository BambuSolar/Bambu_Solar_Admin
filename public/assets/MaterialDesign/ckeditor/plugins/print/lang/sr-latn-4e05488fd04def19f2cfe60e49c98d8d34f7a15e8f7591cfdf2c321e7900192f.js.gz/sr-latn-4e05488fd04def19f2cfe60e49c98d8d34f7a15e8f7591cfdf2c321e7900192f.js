CKEDITOR.plugins.setLang("print","sr-latn",{toolbar:"Štampa"});
