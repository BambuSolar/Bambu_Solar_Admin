CKEDITOR.plugins.setLang("print","pl",{toolbar:"Drukuj"});
