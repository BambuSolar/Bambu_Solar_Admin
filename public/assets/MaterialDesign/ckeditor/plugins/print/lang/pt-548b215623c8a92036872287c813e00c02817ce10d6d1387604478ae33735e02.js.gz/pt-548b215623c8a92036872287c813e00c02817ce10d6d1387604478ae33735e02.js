CKEDITOR.plugins.setLang("print","pt",{toolbar:"Imprimir"});
