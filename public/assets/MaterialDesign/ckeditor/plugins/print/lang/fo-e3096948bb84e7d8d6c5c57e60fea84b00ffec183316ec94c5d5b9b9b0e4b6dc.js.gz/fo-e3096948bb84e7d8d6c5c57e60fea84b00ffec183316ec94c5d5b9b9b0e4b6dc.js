CKEDITOR.plugins.setLang("print","fo",{toolbar:"Prenta"});
