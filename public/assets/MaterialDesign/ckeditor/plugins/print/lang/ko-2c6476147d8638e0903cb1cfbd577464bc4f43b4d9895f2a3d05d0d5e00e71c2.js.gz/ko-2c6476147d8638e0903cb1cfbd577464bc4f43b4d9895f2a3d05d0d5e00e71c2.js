CKEDITOR.plugins.setLang("print","ko",{toolbar:"인쇄"});
