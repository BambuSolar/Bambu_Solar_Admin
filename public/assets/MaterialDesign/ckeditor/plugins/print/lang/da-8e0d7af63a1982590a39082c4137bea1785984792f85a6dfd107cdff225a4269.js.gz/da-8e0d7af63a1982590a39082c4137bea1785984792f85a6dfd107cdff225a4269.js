CKEDITOR.plugins.setLang("print","da",{toolbar:"Udskriv"});
