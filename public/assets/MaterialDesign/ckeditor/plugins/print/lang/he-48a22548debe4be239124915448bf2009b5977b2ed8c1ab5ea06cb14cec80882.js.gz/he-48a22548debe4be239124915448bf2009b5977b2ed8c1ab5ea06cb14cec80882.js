CKEDITOR.plugins.setLang("print","he",{toolbar:"הדפסה"});
