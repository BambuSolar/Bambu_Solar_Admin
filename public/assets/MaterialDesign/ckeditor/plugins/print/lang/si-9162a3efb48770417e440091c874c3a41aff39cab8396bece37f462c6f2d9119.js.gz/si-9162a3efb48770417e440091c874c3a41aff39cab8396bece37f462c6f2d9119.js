CKEDITOR.plugins.setLang("print","si",{toolbar:"මුද්‍රණය කරන්න"});
