CKEDITOR.plugins.setLang("print","hu",{toolbar:"Nyomtatás"});
