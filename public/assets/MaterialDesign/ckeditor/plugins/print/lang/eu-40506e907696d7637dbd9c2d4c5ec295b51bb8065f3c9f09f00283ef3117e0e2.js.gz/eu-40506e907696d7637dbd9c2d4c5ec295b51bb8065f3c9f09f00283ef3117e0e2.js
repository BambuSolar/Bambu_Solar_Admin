CKEDITOR.plugins.setLang("print","eu",{toolbar:"Inprimatu"});
