CKEDITOR.plugins.setLang("print","tt",{toolbar:"Бастыру"});
