CKEDITOR.plugins.setLang("print","cy",{toolbar:"Argraffu"});
