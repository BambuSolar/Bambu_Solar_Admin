CKEDITOR.plugins.setLang("print","fi",{toolbar:"Tulosta"});
