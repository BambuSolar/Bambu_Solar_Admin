CKEDITOR.plugins.setLang("print","fa",{toolbar:"چاپ"});
