CKEDITOR.plugins.setLang("print","bn",{toolbar:"প্রিন্ট করি"});
