CKEDITOR.plugins.setLang("print","en",{toolbar:"Print"});
