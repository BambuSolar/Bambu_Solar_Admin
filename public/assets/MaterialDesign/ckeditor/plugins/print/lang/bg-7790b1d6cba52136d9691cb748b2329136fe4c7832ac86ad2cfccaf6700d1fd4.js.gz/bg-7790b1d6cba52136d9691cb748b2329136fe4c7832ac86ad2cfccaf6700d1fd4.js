CKEDITOR.plugins.setLang("print","bg",{toolbar:"Печат"});
