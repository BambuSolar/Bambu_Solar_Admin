CKEDITOR.plugins.setLang("print","eo",{toolbar:"Presi"});
