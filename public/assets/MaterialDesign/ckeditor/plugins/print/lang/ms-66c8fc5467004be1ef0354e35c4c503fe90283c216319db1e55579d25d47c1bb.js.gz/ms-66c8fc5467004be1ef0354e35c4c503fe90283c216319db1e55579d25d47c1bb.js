CKEDITOR.plugins.setLang("print","ms",{toolbar:"Cetak"});
