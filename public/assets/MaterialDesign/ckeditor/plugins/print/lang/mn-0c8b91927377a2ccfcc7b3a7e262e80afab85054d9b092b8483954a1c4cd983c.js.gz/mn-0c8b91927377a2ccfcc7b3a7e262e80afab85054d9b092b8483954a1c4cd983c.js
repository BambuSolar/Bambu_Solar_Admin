CKEDITOR.plugins.setLang("print","mn",{toolbar:"Хэвлэх"});
