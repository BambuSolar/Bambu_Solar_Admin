/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang("uicolor","en",{title:"UI Color Picker",preview:"Live preview",config:"Paste this string into your config.js file",predefined:"Predefined color sets"});
