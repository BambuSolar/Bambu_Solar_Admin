CKEDITOR.plugins.setLang("autoembed","eo",{embeddingInProgress:"Provas enkorpigi la algluitan URL ...",embeddingFailed:"Ne eblis enkorpigi aŭtomate tiun URL."});
