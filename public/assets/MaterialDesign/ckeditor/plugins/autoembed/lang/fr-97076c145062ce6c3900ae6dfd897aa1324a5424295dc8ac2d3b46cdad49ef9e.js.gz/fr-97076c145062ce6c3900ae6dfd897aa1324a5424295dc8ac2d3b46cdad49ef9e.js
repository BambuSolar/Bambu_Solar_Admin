CKEDITOR.plugins.setLang("autoembed","fr",{embeddingInProgress:"Incorporation de l'URL collée...",embeddingFailed:"Cette URL n'a pas pu être incorporée automatiquement."});
