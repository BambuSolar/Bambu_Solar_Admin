CKEDITOR.plugins.setLang("autoembed","pt-br",{embeddingInProgress:"Tentando embutir a URL colada...",embeddingFailed:"Esta URL não pode ser embutida automaticamente."});
