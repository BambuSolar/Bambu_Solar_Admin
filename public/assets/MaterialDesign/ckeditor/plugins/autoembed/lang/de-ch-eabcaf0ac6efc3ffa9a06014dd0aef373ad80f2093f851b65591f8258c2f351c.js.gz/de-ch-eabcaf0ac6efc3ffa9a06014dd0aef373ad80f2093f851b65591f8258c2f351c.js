CKEDITOR.plugins.setLang("autoembed","de-ch",{embeddingInProgress:"Einbetten der eingefügten URL wird versucht...",embeddingFailed:"Diese URL konnte nicht automatisch eingebettet werden."});
