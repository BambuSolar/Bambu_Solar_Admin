CKEDITOR.plugins.setLang("autoembed","mk",{embeddingInProgress:"Обид за вметнување копирано URL...",embeddingFailed:"Ова URL не може да биде вметнато автоматски."});
