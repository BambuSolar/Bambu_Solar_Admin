CKEDITOR.plugins.setLang("autoembed","uk",{embeddingInProgress:"Намагаюсь вбудувати вставлене URL посилання...",embeddingFailed:"Це URl посилання не може бути автоматично вбудовано."});
