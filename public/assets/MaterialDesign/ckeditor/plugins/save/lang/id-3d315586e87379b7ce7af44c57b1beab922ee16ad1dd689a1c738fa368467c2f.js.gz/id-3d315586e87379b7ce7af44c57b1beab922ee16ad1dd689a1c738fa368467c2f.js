CKEDITOR.plugins.setLang("save","id",{toolbar:"Simpan"});
