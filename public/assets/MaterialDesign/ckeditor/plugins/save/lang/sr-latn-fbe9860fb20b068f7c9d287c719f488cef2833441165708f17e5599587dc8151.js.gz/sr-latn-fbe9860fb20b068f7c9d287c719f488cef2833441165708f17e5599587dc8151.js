CKEDITOR.plugins.setLang("save","sr-latn",{toolbar:"Sačuvaj"});
