CKEDITOR.plugins.setLang("save","nb",{toolbar:"Lagre"});
