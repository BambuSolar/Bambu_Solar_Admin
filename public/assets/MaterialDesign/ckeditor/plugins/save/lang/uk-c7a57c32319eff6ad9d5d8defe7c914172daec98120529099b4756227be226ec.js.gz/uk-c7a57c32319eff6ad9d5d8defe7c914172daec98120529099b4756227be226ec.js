CKEDITOR.plugins.setLang("save","uk",{toolbar:"Зберегти"});
