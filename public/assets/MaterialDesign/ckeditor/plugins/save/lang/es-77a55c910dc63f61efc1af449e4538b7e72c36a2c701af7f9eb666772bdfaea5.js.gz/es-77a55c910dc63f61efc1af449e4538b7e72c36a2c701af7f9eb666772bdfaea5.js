CKEDITOR.plugins.setLang("save","es",{toolbar:"Guardar"});
