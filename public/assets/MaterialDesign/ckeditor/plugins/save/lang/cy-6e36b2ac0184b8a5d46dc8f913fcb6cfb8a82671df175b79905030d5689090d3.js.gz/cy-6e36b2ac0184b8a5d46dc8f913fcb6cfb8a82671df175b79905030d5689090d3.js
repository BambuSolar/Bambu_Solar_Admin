CKEDITOR.plugins.setLang("save","cy",{toolbar:"Cadw"});
