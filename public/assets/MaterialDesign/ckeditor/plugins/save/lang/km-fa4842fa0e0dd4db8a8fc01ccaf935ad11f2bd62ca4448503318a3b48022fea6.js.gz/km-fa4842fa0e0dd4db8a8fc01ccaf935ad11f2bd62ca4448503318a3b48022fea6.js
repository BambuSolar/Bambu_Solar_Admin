CKEDITOR.plugins.setLang("save","km",{toolbar:"រក្សាទុក"});
