CKEDITOR.plugins.setLang("save","en-ca",{toolbar:"Save"});
