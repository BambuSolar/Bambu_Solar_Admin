CKEDITOR.plugins.setLang("save","lt",{toolbar:"Išsaugoti"});
