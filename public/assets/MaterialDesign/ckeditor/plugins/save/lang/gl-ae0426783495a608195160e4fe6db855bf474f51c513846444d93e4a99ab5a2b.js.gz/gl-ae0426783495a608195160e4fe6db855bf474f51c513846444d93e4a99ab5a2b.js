CKEDITOR.plugins.setLang("save","gl",{toolbar:"Gardar"});
