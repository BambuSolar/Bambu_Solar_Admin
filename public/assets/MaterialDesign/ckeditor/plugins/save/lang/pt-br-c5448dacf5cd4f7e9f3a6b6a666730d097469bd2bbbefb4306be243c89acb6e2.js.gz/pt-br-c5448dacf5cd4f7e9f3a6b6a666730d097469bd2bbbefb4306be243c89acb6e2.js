CKEDITOR.plugins.setLang("save","pt-br",{toolbar:"Salvar"});
