CKEDITOR.plugins.setLang("save","he",{toolbar:"שמירה"});
