CKEDITOR.plugins.setLang("save","eu",{toolbar:"Gorde"});
