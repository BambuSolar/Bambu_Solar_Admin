CKEDITOR.plugins.setLang("save","fa",{toolbar:"ذخیره"});
