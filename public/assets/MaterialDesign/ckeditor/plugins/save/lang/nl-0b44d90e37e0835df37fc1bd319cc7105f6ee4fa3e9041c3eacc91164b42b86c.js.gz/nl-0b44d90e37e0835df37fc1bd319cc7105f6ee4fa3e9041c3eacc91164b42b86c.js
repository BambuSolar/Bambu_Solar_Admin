CKEDITOR.plugins.setLang("save","nl",{toolbar:"Opslaan"});
