CKEDITOR.plugins.setLang("save","sk",{toolbar:"Uložiť"});
