CKEDITOR.plugins.setLang("save","ru",{toolbar:"Сохранить"});
