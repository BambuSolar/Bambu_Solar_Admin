CKEDITOR.plugins.setLang("save","zh-cn",{toolbar:"保存"});
