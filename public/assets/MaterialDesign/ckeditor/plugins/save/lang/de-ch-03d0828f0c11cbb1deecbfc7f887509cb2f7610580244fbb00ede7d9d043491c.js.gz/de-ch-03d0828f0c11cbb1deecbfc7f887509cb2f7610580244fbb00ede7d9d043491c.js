CKEDITOR.plugins.setLang("save","de-ch",{toolbar:"Speichern"});
