CKEDITOR.plugins.setLang("save","ka",{toolbar:"ჩაწერა"});
