CKEDITOR.plugins.setLang("save","hr",{toolbar:"Snimi"});
