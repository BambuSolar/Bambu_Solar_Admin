CKEDITOR.plugins.setLang("save","gu",{toolbar:"સેવ"});
