CKEDITOR.plugins.setLang("save","ug",{toolbar:"ساقلا"});
