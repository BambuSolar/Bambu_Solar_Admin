CKEDITOR.plugins.setLang("save","sq",{toolbar:"Ruaje"});
