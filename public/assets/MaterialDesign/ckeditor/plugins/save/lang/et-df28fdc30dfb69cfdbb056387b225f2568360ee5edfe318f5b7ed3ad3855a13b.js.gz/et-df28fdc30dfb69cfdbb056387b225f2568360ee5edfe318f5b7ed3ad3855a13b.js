CKEDITOR.plugins.setLang("save","et",{toolbar:"Salvestamine"});
