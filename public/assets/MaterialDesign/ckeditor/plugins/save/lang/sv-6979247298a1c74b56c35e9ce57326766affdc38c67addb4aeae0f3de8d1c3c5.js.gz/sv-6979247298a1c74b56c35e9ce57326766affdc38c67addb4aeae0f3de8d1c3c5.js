CKEDITOR.plugins.setLang("save","sv",{toolbar:"Spara"});
