CKEDITOR.plugins.setLang("save","ar",{toolbar:"حفظ"});
