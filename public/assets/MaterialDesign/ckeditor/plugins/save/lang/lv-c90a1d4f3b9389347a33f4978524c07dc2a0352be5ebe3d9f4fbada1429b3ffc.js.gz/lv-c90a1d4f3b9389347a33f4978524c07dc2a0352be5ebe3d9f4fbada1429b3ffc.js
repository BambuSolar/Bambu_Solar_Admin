CKEDITOR.plugins.setLang("save","lv",{toolbar:"Saglabāt"});
