CKEDITOR.plugins.setLang("save","mk",{toolbar:"Save"});
