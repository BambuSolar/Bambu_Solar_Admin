CKEDITOR.plugins.setLang("save","si",{toolbar:"ආරක්ෂා කරන්න"});
