CKEDITOR.plugins.setLang("save","tt",{toolbar:"Саклау"});
