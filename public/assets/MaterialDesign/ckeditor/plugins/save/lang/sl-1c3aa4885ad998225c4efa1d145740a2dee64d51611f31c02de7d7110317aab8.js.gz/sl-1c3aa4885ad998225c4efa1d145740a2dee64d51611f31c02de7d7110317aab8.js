CKEDITOR.plugins.setLang("save","sl",{toolbar:"Shrani"});
