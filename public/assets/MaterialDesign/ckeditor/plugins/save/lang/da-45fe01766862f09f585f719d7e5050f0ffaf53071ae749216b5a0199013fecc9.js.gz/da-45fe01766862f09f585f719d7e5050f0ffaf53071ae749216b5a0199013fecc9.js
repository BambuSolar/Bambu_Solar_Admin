CKEDITOR.plugins.setLang("save","da",{toolbar:"Gem"});
