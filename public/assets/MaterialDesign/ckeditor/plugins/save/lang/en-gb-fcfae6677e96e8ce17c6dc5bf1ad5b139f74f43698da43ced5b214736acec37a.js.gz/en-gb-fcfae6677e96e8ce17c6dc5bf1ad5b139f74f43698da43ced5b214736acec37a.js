CKEDITOR.plugins.setLang("save","en-gb",{toolbar:"Save"});
