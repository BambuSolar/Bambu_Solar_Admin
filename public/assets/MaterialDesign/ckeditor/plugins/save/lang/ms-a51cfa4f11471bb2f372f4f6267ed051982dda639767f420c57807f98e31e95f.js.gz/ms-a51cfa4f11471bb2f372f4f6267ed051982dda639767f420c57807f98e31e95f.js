CKEDITOR.plugins.setLang("save","ms",{toolbar:"Simpan"});
