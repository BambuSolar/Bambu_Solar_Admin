CKEDITOR.plugins.setLang("save","is",{toolbar:"Vista"});
