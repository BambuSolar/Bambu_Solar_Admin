CKEDITOR.plugins.setLang("save","vi",{toolbar:"Lưu"});
