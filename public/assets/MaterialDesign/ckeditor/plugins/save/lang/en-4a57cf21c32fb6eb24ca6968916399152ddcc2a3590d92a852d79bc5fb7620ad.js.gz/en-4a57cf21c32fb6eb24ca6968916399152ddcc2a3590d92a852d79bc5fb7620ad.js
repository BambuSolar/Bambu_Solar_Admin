CKEDITOR.plugins.setLang("save","en",{toolbar:"Save"});
