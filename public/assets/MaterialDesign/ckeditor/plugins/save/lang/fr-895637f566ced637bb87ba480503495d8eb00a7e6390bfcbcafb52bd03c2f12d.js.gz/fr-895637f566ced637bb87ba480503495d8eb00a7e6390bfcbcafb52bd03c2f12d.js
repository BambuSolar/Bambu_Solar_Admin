CKEDITOR.plugins.setLang("save","fr",{toolbar:"Enregistrer"});
