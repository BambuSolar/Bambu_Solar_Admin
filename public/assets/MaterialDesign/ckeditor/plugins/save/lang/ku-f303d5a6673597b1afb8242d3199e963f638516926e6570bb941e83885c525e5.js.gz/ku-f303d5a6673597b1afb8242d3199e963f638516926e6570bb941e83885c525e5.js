CKEDITOR.plugins.setLang("save","ku",{toolbar:"پاشکەوتکردن"});
