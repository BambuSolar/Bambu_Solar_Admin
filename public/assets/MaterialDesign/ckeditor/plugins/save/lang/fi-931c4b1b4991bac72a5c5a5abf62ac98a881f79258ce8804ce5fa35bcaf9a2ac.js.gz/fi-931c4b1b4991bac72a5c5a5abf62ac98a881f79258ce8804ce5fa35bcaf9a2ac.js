CKEDITOR.plugins.setLang("save","fi",{toolbar:"Tallenna"});
