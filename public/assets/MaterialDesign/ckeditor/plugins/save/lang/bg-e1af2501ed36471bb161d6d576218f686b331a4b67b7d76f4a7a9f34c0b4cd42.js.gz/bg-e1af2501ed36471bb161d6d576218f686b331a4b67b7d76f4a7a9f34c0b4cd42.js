CKEDITOR.plugins.setLang("save","bg",{toolbar:"Запис"});
