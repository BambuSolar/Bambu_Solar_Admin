CKEDITOR.plugins.setLang("save","sr",{toolbar:"Сачувај"});
