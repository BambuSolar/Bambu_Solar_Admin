CKEDITOR.plugins.setLang("save","eo",{toolbar:"Konservi"});
