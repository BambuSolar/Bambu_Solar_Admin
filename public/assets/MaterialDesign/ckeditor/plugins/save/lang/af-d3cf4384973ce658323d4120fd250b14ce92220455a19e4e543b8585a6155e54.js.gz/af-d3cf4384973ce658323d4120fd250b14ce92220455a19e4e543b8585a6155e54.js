CKEDITOR.plugins.setLang("save","af",{toolbar:"Bewaar"});
