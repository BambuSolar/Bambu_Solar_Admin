CKEDITOR.plugins.setLang("save","tr",{toolbar:"Kaydet"});
