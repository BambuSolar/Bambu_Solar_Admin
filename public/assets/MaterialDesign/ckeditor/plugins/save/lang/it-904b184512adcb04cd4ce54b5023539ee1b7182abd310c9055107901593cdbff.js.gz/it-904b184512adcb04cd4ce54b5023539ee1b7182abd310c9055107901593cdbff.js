CKEDITOR.plugins.setLang("save","it",{toolbar:"Salva"});
