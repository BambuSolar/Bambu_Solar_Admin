CKEDITOR.plugins.setLang("save","ro",{toolbar:"Salvează"});
