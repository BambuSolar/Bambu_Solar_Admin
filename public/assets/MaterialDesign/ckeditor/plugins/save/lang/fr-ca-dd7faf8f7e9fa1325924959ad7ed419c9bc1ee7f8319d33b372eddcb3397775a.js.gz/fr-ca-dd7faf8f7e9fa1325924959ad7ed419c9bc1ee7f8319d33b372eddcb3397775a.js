CKEDITOR.plugins.setLang("save","fr-ca",{toolbar:"Sauvegarder"});
