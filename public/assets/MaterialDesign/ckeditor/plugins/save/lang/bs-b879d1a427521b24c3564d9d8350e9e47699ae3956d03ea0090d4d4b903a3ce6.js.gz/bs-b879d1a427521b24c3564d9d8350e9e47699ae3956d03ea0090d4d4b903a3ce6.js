CKEDITOR.plugins.setLang("save","bs",{toolbar:"Snimi"});
