CKEDITOR.plugins.setLang("save","mn",{toolbar:"Хадгалах"});
