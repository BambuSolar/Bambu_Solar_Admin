CKEDITOR.plugins.setLang("save","cs",{toolbar:"Uložit"});
