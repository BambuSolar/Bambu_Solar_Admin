CKEDITOR.plugins.setLang("save","bn",{toolbar:"সংরক্ষন করি"});
