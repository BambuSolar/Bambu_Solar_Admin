CKEDITOR.plugins.setLang("save","pl",{toolbar:"Zapisz"});
