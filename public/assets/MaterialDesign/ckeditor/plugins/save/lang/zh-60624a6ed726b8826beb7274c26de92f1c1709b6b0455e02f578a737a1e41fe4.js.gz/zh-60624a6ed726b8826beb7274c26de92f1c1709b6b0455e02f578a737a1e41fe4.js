CKEDITOR.plugins.setLang("save","zh",{toolbar:"儲存"});
