CKEDITOR.plugins.setLang("save","no",{toolbar:"Lagre"});
