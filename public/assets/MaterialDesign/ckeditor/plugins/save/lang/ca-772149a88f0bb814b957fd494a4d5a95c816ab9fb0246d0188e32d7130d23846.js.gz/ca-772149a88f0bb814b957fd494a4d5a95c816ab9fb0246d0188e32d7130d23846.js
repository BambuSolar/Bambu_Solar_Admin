CKEDITOR.plugins.setLang("save","ca",{toolbar:"Desa"});
