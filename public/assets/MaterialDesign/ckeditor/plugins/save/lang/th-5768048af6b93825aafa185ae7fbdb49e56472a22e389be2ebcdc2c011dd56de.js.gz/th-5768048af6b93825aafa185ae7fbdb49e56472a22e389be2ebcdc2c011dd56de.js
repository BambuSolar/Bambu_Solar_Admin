CKEDITOR.plugins.setLang("save","th",{toolbar:"บันทึก"});
