CKEDITOR.plugins.setLang("save","ja",{toolbar:"保存"});
