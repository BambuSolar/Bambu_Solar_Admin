CKEDITOR.plugins.setLang("save","hu",{toolbar:"Mentés"});
