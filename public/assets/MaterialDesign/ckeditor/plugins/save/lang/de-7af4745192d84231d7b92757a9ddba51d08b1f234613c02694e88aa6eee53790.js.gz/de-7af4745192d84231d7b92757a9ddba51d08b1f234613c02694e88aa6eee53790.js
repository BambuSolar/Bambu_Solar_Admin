CKEDITOR.plugins.setLang("save","de",{toolbar:"Speichern"});
