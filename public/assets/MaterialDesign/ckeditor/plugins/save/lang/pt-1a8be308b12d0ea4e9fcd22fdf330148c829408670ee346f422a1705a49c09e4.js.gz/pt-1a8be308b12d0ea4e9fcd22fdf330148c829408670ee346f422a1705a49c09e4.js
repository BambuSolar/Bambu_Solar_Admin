CKEDITOR.plugins.setLang("save","pt",{toolbar:"Guardar"});
