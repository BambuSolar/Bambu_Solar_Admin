CKEDITOR.plugins.setLang("save","ko",{toolbar:"저장"});
