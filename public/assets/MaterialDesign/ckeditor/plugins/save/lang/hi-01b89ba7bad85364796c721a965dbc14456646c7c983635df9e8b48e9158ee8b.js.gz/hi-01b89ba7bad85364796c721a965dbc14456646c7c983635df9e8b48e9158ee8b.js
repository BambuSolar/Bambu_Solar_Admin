CKEDITOR.plugins.setLang("save","hi",{toolbar:"सेव"});
