CKEDITOR.plugins.setLang("save","el",{toolbar:"Αποθήκευση"});
