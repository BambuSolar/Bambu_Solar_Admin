CKEDITOR.plugins.setLang("save","en-au",{toolbar:"Save"});
