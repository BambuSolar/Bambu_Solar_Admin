CKEDITOR.plugins.setLang("save","fo",{toolbar:"Goym"});
