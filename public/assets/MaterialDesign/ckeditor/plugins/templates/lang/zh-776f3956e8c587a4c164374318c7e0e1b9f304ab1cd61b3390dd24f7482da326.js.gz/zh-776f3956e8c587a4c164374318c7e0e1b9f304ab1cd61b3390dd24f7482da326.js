CKEDITOR.plugins.setLang("templates","zh",{button:"範本",emptyListMsg:"(尚未定義任何範本)",insertOption:"替代實際內容",options:"範本選項",selectPromptMsg:"請選擇要在編輯器中開啟的範本。",title:"內容範本"});
