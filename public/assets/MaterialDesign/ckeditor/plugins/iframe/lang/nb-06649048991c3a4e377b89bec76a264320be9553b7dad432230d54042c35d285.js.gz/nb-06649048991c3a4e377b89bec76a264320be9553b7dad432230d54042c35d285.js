CKEDITOR.plugins.setLang("iframe","nb",{border:"Vis ramme rundt iframe",noUrl:"Vennligst skriv inn URL for iframe",scrolling:"Aktiver scrollefelt",title:"Egenskaper for IFrame",toolbar:"IFrame"});
