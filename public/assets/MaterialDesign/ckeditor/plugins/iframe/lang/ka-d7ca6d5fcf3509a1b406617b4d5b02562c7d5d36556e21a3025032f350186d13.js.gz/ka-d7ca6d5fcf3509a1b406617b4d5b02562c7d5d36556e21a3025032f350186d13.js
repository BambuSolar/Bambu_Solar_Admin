CKEDITOR.plugins.setLang("iframe","ka",{border:"ჩარჩოს გამოჩენა",noUrl:"აკრიფეთ iframe-ის URL",scrolling:"გადახვევის ზოლების დაშვება",title:"IFrame-ის პარამეტრები",toolbar:"IFrame"});
