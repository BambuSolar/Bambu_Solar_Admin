CKEDITOR.plugins.setLang("iframe","sl",{border:"Pokaži obrobo okvirja",noUrl:"Prosimo, vnesite iframe URL",scrolling:"Omogoči drsnike",title:"Lastnosti IFrame",toolbar:"IFrame"});
