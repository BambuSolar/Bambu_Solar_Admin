CKEDITOR.plugins.setLang("iframe","lv",{border:"Rādīt rāmi",noUrl:"Norādiet iframe adresi",scrolling:"Atļaut ritjoslas",title:"IFrame uzstādījumi",toolbar:"IFrame"});
