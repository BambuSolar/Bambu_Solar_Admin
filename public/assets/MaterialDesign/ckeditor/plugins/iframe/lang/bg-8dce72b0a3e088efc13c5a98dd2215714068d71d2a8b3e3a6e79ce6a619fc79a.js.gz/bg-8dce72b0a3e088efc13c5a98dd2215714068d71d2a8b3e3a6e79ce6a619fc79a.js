CKEDITOR.plugins.setLang("iframe","bg",{border:"Показва рамка на карето",noUrl:"Моля въведете URL за iFrame",scrolling:"Вкл. скролбаровете",title:"IFrame настройки",toolbar:"IFrame"});
