CKEDITOR.plugins.setLang("iframe","ar",{border:"إظهار حدود الإطار",noUrl:"فضلا أكتب رابط الـ iframe",scrolling:"تفعيل أشرطة الإنتقال",title:"خصائص iframe",toolbar:"iframe"});
