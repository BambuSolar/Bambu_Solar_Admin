CKEDITOR.plugins.setLang("iframe","af",{border:"Wys rand van raam",noUrl:"Gee die iframe URL",scrolling:"Skuifbalke aan",title:"IFrame Eienskappe",toolbar:"IFrame"});
