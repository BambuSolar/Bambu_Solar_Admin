CKEDITOR.plugins.setLang("iframe","et",{border:"Raami äärise näitamine",noUrl:"Vali iframe URLi liik",scrolling:"Kerimisribade lubamine",title:"IFrame omadused",toolbar:"IFrame"});
