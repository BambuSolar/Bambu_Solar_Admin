CKEDITOR.plugins.setLang("iframe","fo",{border:"Vís frame kant",noUrl:"Vinarliga skriva URL til iframe",scrolling:"Loyv scrollbars",title:"Møguleikar fyri IFrame",toolbar:"IFrame"});
