CKEDITOR.plugins.setLang("iframe","hu",{border:"Legyen keret",noUrl:"Kérem írja be a iframe URL-t",scrolling:"Gördítősáv bekapcsolása",title:"IFrame Tulajdonságok",toolbar:"IFrame"});
