CKEDITOR.plugins.setLang("iframe","ms",{border:"Show frame border",noUrl:"Please type the iframe URL",scrolling:"Enable scrollbars",title:"IFrame Properties",toolbar:"IFrame"});
