CKEDITOR.plugins.setLang("iframe","lt",{border:"Rodyti rėmelį",noUrl:"Nurodykite iframe nuorodą",scrolling:"Įjungti slankiklius",title:"IFrame nustatymai",toolbar:"IFrame"});
