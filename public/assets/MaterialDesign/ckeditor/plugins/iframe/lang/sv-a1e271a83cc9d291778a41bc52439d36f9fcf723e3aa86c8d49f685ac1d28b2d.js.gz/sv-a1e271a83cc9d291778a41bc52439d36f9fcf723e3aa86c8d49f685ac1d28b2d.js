CKEDITOR.plugins.setLang("iframe","sv",{border:"Visa ramkant",noUrl:"Skriv in URL för iFrame",scrolling:"Aktivera rullningslister",title:"iFrame Egenskaper",toolbar:"iFrame"});
