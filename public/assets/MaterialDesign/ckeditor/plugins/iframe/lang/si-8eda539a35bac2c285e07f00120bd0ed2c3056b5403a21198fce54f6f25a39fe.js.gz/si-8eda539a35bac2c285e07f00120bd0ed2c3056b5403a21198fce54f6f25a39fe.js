CKEDITOR.plugins.setLang("iframe","si",{border:"සැකිල්ලේ කඩයිම් ",noUrl:"කරුණාකර රුපයේ URL ලියන්න",scrolling:"සක්ක්‍රිය කරන්න",title:"IFrame Properties",toolbar:"IFrame"});
