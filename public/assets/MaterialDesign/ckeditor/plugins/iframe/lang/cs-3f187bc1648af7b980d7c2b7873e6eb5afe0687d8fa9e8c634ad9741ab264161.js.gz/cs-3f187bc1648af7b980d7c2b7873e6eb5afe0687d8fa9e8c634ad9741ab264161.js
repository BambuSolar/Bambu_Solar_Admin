CKEDITOR.plugins.setLang("iframe","cs",{border:"Zobrazit okraj",noUrl:"Zadejte prosím URL obsahu pro IFrame",scrolling:"Zapnout posuvníky",title:"Vlastnosti IFrame",toolbar:"IFrame"});
