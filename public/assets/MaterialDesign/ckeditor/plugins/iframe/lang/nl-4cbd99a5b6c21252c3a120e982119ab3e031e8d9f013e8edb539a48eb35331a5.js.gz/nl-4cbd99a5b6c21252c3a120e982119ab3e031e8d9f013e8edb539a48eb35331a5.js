CKEDITOR.plugins.setLang("iframe","nl",{border:"Framerand tonen",noUrl:"Vul de IFrame URL in",scrolling:"Scrollbalken inschakelen",title:"IFrame-eigenschappen",toolbar:"IFrame"});
