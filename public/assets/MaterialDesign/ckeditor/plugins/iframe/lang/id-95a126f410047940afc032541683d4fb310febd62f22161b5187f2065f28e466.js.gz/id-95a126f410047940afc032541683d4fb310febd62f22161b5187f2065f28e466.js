CKEDITOR.plugins.setLang("iframe","id",{border:"Tampilkan Batas Bingkai",noUrl:"Please type the iframe URL",scrolling:"Aktifkan Scrollbar",title:"IFrame Properties",toolbar:"IFrame"});
