CKEDITOR.plugins.setLang("iframe","de-ch",{border:"Rahmen anzeigen",noUrl:"Bitte geben Sie die IFrame-URL an",scrolling:"Rollbalken anzeigen",title:"IFrame-Eigenschaften",toolbar:"IFrame"});
