CKEDITOR.plugins.setLang("iframe","it",{border:"Mostra il bordo",noUrl:"Inserire l'URL del campo IFrame",scrolling:"Abilita scrollbar",title:"Proprietà IFrame",toolbar:"IFrame"});
