CKEDITOR.plugins.setLang("iframe","ja",{border:"フレームの枠を表示",noUrl:"iframeのURLを入力してください。",scrolling:"スクロールバーの表示を許可",title:"iFrameのプロパティ",toolbar:"IFrame"});
