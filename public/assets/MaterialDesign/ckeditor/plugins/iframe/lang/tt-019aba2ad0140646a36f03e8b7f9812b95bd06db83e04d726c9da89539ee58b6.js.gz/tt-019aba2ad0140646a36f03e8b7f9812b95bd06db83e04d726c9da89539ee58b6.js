CKEDITOR.plugins.setLang("iframe","tt",{border:"Frame чикләрен күрсәтү",noUrl:"Please type the iframe URL",scrolling:"Enable scrollbars",title:"IFrame үзлекләре",toolbar:"IFrame"});
