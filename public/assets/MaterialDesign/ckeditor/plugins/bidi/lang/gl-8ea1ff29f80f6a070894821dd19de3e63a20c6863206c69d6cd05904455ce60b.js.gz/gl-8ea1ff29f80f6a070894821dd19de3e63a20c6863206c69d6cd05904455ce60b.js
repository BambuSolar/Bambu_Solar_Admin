CKEDITOR.plugins.setLang("bidi","gl",{ltr:"Dirección do texto de esquerda a dereita",rtl:"Dirección do texto de dereita a esquerda"});
