CKEDITOR.plugins.setLang("bidi","es",{ltr:"Dirección del texto de izquierda a derecha",rtl:"Dirección del texto de derecha a izquierda"});
