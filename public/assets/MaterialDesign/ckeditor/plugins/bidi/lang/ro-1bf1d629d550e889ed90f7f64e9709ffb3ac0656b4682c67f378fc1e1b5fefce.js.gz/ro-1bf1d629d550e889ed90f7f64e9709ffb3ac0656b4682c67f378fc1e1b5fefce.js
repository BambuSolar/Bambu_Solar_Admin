CKEDITOR.plugins.setLang("bidi","ro",{ltr:"Direcția textului de la stânga la dreapta",rtl:"Direcția textului de la dreapta la stânga"});
