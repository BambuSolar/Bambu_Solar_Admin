CKEDITOR.plugins.setLang("bidi","en",{ltr:"Text direction from left to right",rtl:"Text direction from right to left"});
