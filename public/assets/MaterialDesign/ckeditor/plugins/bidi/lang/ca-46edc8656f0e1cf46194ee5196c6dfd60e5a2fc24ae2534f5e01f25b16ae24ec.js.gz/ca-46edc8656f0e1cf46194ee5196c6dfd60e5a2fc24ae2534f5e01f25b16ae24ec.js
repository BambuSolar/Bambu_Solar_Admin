CKEDITOR.plugins.setLang("bidi","ca",{ltr:"Direcció del text d'esquerra a dreta",rtl:"Direcció del text de dreta a esquerra"});
