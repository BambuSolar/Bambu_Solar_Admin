CKEDITOR.plugins.setLang("bidi","mn",{ltr:"Зүүнээс баруун тийш бичлэг",rtl:"Баруунаас зүүн тийш бичлэг"});
