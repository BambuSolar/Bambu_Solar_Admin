CKEDITOR.plugins.setLang("bidi","id",{ltr:"Arah penulisan dari kiri ke kanan.",rtl:"Arah penulisan dari kanan ke kiri."});
