CKEDITOR.plugins.setLang("bidi","cs",{ltr:"Směr textu zleva doprava",rtl:"Směr textu zprava doleva"});
