CKEDITOR.plugins.setLang("bidi","eo",{ltr:"Tekstdirekto de maldekstre dekstren",rtl:"Tekstdirekto de dekstre maldekstren"});
