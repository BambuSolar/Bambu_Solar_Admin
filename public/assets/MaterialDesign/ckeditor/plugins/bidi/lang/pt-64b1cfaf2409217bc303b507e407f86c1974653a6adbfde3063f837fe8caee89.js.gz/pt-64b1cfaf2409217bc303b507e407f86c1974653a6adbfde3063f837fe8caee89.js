CKEDITOR.plugins.setLang("bidi","pt",{ltr:"Direção do texto da esquerda para a direita",rtl:"Direção do texto da direita para a esquerda"});
