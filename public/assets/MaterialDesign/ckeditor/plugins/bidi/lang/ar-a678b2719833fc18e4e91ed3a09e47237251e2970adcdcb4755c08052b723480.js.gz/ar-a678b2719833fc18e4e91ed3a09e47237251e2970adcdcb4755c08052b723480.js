CKEDITOR.plugins.setLang("bidi","ar",{ltr:"إتجاه النص من اليسار إلى اليمين",rtl:"إتجاه النص من اليمين إلى اليسار"});
