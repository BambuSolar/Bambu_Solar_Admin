CKEDITOR.plugins.setLang("bidi","tt",{ltr:"Сулдан уңга язылыш",rtl:"Уңнан сулга язылыш"});
