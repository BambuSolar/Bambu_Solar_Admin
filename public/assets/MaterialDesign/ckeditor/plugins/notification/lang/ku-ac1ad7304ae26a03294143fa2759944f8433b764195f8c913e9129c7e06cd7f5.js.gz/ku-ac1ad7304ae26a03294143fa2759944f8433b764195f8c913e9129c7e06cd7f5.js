CKEDITOR.plugins.setLang("notification","ku",{closed:"ئاگادارکەرەوەکە داخرا."});
