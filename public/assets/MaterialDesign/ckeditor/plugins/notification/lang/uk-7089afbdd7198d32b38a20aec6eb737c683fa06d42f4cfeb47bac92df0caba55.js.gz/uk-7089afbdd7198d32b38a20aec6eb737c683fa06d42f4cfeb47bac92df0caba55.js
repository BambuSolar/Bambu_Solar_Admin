CKEDITOR.plugins.setLang("notification","uk",{closed:"Сповіщення закрито."});
