CKEDITOR.plugins.setLang("notification","ru",{closed:"Уведомление закрыто"});
