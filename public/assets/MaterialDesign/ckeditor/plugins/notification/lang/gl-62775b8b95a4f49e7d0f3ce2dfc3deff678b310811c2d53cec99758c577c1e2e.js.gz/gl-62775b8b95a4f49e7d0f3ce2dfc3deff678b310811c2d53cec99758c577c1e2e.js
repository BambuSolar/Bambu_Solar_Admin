CKEDITOR.plugins.setLang("notification","gl",{closed:"Notificación pechada."});
