CKEDITOR.plugins.setLang("notification","nb",{closed:"Varsling lukket."});
