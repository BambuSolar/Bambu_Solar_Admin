CKEDITOR.plugins.setLang("notification","id",{closed:"Pemberitahuan ditutup"});
