CKEDITOR.plugins.setLang("notification","de",{closed:"Benachrichtigung geschlossen."});
