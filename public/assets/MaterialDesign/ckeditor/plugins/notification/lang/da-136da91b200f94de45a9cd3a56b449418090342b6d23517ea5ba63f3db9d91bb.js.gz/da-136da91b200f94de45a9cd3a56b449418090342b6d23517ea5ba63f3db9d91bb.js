CKEDITOR.plugins.setLang("notification","da",{closed:"Notefikation lukket."});
