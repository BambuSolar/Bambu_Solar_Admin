CKEDITOR.plugins.setLang("notification","it",{closed:"Notifica chiusa."});
