CKEDITOR.plugins.setLang("notification","en",{closed:"Notification closed."});
