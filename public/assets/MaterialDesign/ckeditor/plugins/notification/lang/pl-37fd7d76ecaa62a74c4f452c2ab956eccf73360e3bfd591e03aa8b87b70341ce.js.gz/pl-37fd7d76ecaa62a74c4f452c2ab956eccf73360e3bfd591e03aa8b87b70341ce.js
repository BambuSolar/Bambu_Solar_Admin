CKEDITOR.plugins.setLang("notification","pl",{closed:"Powiadomienie zostało zamknięte."});
