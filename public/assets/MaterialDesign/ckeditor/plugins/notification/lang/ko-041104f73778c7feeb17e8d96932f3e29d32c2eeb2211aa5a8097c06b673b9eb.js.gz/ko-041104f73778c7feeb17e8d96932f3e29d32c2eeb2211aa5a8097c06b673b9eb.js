CKEDITOR.plugins.setLang("notification","ko",{closed:"알림이 닫힘."});
