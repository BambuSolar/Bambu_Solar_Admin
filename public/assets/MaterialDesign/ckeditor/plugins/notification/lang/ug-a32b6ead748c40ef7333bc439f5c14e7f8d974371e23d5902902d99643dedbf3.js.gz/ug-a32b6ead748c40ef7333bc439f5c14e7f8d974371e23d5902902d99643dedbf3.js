CKEDITOR.plugins.setLang("notification","ug",{closed:"ئوقتۇرۇش تاقالدى."});
