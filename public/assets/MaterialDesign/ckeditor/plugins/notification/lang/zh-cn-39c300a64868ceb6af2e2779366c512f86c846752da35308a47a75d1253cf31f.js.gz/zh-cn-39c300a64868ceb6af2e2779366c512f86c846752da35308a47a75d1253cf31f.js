CKEDITOR.plugins.setLang("notification","zh-cn",{closed:"通知已关闭。"});
