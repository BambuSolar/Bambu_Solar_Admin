CKEDITOR.plugins.setLang("notification","fr",{closed:"La notification est close."});
