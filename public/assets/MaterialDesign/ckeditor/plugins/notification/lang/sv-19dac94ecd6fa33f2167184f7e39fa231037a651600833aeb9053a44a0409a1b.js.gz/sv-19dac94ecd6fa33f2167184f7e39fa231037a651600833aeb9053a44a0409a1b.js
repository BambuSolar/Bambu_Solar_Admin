CKEDITOR.plugins.setLang("notification","sv",{closed:"Notifiering stängd."});
