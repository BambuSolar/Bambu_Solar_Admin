CKEDITOR.plugins.setLang("notification","pt",{closed:"Notificação encerrada."});
