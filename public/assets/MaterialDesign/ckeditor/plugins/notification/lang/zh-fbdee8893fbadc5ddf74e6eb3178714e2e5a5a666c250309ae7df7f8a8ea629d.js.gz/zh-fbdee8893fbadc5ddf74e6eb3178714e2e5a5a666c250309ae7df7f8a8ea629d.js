CKEDITOR.plugins.setLang("notification","zh",{closed:"通知已關閉。"});
