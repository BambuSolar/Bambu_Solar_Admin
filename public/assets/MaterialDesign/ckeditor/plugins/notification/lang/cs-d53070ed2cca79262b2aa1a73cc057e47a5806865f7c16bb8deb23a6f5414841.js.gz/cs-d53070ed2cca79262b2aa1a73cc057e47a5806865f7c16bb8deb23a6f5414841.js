CKEDITOR.plugins.setLang("notification","cs",{closed:"Oznámení zavřeno."});
