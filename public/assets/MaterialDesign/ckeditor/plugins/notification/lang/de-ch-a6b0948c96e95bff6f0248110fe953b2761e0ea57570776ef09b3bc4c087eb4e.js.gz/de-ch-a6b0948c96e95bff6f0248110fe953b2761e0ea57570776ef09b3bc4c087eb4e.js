CKEDITOR.plugins.setLang("notification","de-ch",{closed:"Benachrichtigung geschlossen."});
