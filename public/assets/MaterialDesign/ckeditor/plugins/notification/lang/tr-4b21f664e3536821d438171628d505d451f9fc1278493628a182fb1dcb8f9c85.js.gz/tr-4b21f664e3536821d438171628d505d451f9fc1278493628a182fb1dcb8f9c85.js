CKEDITOR.plugins.setLang("notification","tr",{closed:"Uyarılar kapatıldı."});
