CKEDITOR.plugins.setLang("notification","eu",{closed:"Jakinarazpena itxita."});
