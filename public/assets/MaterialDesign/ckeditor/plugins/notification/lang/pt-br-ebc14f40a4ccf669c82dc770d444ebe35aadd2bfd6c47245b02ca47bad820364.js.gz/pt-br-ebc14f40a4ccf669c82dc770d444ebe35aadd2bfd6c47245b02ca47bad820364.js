CKEDITOR.plugins.setLang("notification","pt-br",{closed:"Notificação fechada."});
