CKEDITOR.plugins.setLang("notification","km",{closed:"បាន​បិទ​ការ​ផ្ដល់​ដំណឹង។"});
