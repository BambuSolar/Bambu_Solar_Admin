CKEDITOR.plugins.setLang("notification","eo",{closed:"Sciigo fermita"});
