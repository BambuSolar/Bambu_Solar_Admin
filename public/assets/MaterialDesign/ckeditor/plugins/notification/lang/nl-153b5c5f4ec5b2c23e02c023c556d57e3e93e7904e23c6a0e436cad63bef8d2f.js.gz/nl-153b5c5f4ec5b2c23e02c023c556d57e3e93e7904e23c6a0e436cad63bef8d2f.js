CKEDITOR.plugins.setLang("notification","nl",{closed:"Melding gesloten."});
