CKEDITOR.plugins.setLang("justify","eu",{block:"Justifikatu",center:"Erdian",left:"Lerrokatu ezkerrean",right:"Lerrokatu eskuinean"});
