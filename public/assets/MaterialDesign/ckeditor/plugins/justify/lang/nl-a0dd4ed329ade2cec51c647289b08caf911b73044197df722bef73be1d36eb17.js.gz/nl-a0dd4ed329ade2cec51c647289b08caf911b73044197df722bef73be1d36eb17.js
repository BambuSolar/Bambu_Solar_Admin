CKEDITOR.plugins.setLang("justify","nl",{block:"Uitvullen",center:"Centreren",left:"Links uitlijnen",right:"Rechts uitlijnen"});
