CKEDITOR.plugins.setLang("justify","ka",{block:"გადასწორება",center:"შუაში სწორება",left:"მარცხნივ სწორება",right:"მარჯვნივ სწორება"});
