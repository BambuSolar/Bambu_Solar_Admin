CKEDITOR.plugins.setLang("justify","no",{block:"Blokkjuster",center:"Midtstill",left:"Venstrejuster",right:"Høyrejuster"});
