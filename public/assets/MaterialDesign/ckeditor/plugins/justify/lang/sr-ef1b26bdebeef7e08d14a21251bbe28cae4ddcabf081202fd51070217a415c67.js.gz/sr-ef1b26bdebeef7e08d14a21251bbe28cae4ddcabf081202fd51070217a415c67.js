CKEDITOR.plugins.setLang("justify","sr",{block:"Обострано равнање",center:"Центриран текст",left:"Лево равнање",right:"Десно равнање"});
