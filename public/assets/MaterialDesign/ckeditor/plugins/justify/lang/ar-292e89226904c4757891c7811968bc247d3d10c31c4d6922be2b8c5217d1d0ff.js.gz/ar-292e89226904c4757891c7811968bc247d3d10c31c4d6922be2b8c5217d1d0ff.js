CKEDITOR.plugins.setLang("justify","ar",{block:"ضبط",center:"توسيط",left:"محاذاة إلى اليسار",right:"محاذاة إلى اليمين"});
