CKEDITOR.plugins.setLang("justify","vi",{block:"Canh đều",center:"Canh giữa",left:"Canh trái",right:"Canh phải"});
