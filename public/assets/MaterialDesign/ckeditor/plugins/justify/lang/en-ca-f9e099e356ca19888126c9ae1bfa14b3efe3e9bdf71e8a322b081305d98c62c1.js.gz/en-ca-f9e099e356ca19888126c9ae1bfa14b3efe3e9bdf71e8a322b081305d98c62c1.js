CKEDITOR.plugins.setLang("justify","en-ca",{block:"Justify",center:"Centre",left:"Align Left",right:"Align Right"});
