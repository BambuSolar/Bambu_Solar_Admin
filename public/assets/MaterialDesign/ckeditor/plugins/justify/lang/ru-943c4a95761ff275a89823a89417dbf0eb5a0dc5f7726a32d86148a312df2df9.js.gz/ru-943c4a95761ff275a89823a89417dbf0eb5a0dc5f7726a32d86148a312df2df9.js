CKEDITOR.plugins.setLang("justify","ru",{block:"По ширине",center:"По центру",left:"По левому краю",right:"По правому краю"});
