CKEDITOR.plugins.setLang("justify","es",{block:"Justificado",center:"Centrar",left:"Alinear a Izquierda",right:"Alinear a Derecha"});
