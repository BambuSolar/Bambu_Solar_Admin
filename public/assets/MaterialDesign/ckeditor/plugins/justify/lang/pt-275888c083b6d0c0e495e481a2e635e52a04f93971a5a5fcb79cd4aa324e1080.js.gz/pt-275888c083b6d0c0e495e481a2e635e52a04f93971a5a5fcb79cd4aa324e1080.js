CKEDITOR.plugins.setLang("justify","pt",{block:"Justificado",center:"Alinhar ao centro",left:"Alinhar à esquerda",right:"Alinhar à direita"});
