CKEDITOR.plugins.setLang("justify","en",{block:"Justify",center:"Center",left:"Align Left",right:"Align Right"});
