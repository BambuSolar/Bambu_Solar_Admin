CKEDITOR.plugins.setLang("justify","ug",{block:"ئىككى تەرەپتىن توغرىلا",center:"ئوتتۇرىغا توغرىلا",left:"سولغا توغرىلا",right:"ئوڭغا توغرىلا"});
