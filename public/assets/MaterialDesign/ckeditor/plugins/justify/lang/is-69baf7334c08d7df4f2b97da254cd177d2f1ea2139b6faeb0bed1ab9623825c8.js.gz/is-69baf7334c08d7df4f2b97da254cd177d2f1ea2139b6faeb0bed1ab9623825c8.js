CKEDITOR.plugins.setLang("justify","is",{block:"Jafna báðum megin",center:"Miðja texta",left:"Vinstrijöfnun",right:"Hægrijöfnun"});
