CKEDITOR.plugins.setLang("justify","si",{block:"Justify",center:"මධ්‍ය",left:"Align Left",right:"Align Right"});
