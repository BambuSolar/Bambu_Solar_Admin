CKEDITOR.plugins.setLang("justify","gl",{block:"Xustificado",center:"Centrado",left:"Aliñar á esquerda",right:"Aliñar á dereita"});
