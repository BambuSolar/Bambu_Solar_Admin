CKEDITOR.plugins.setLang("justify","km",{block:"តម្រឹម​ពេញ",center:"កណ្ដាល",left:"តម្រឹម​ឆ្វេង",right:"តម្រឹម​ស្ដាំ"});
