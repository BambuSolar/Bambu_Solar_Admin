CKEDITOR.plugins.setLang("justify","et",{block:"Rööpjoondus",center:"Keskjoondus",left:"Vasakjoondus",right:"Paremjoondus"});
