CKEDITOR.plugins.setLang("justify","sk",{block:"Zarovnať do bloku",center:"Zarovnať na stred",left:"Zarovnať vľavo",right:"Zarovnať vpravo"});
