CKEDITOR.plugins.setLang("justify","id",{block:"Rata kiri-kanan",center:"Pusat",left:"Align Left",right:"Align Right"});
