CKEDITOR.plugins.setLang("justify","de",{block:"Blocksatz",center:"Zentriert",left:"Linksbündig",right:"Rechtsbündig"});
