CKEDITOR.plugins.setLang("justify","ms",{block:"Jajaran Blok",center:"Jajaran Tengah",left:"Jajaran Kiri",right:"Jajaran Kanan"});
