CKEDITOR.plugins.setLang("justify","he",{block:"יישור לשוליים",center:"מרכוז",left:"יישור לשמאל",right:"יישור לימין"});
