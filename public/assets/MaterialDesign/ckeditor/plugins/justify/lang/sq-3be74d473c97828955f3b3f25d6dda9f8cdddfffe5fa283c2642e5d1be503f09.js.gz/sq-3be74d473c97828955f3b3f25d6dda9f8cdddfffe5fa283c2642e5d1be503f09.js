CKEDITOR.plugins.setLang("justify","sq",{block:"Zgjero",center:"Qendër",left:"Rreshto majtas",right:"Rreshto Djathtas"});
