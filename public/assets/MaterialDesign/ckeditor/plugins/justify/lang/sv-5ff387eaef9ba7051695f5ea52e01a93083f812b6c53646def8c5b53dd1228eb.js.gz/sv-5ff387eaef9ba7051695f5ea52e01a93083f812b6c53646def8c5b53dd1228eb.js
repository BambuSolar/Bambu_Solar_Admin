CKEDITOR.plugins.setLang("justify","sv",{block:"Justera till marginaler",center:"Centrera",left:"Vänsterjustera",right:"Högerjustera"});
