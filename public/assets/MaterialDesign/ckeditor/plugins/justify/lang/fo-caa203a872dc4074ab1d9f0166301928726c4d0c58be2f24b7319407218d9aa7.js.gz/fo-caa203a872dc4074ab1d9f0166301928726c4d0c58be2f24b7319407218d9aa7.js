CKEDITOR.plugins.setLang("justify","fo",{block:"Javnir tekstkantar",center:"Miðsett",left:"Vinstrasett",right:"Høgrasett"});
