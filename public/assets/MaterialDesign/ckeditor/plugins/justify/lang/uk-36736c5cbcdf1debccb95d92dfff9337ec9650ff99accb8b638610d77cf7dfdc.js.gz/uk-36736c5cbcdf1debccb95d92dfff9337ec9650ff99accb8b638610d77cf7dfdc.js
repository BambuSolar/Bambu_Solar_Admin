CKEDITOR.plugins.setLang("justify","uk",{block:"По ширині",center:"По центру",left:"По лівому краю",right:"По правому краю"});
