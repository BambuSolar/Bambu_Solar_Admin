CKEDITOR.plugins.setLang("justify","lv",{block:"Izlīdzināt malas",center:"Izlīdzināt pret centru",left:"Izlīdzināt pa kreisi",right:"Izlīdzināt pa labi"});
