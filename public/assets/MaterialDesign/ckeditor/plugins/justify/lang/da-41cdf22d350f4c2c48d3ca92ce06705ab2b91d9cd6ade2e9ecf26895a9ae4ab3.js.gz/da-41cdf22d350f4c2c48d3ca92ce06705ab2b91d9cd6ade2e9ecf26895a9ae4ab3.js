CKEDITOR.plugins.setLang("justify","da",{block:"Lige margener",center:"Centreret",left:"Venstrestillet",right:"Højrestillet"});
