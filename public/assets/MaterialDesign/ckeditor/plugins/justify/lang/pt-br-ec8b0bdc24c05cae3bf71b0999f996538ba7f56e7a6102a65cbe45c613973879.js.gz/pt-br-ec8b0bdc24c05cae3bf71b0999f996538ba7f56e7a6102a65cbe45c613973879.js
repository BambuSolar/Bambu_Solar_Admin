CKEDITOR.plugins.setLang("justify","pt-br",{block:"Justificado",center:"Centralizar",left:"Alinhar Esquerda",right:"Alinhar Direita"});
