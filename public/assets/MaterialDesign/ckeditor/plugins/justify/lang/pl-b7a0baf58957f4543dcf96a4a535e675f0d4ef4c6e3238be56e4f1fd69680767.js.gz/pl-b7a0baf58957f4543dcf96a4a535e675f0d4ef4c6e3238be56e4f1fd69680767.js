CKEDITOR.plugins.setLang("justify","pl",{block:"Wyjustuj",center:"Wyśrodkuj",left:"Wyrównaj do lewej",right:"Wyrównaj do prawej"});
