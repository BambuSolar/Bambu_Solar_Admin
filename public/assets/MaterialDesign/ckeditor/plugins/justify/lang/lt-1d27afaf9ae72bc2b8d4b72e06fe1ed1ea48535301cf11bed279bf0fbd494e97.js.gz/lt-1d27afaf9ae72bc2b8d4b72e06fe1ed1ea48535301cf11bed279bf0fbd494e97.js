CKEDITOR.plugins.setLang("justify","lt",{block:"Lygiuoti abi puses",center:"Centruoti",left:"Lygiuoti kairę",right:"Lygiuoti dešinę"});
