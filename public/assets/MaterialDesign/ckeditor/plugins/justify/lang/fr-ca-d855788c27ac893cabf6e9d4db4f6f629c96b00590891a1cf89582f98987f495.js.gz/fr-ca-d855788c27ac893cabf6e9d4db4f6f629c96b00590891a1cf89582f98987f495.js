CKEDITOR.plugins.setLang("justify","fr-ca",{block:"Justifié",center:"Centré",left:"Aligner à gauche",right:"Aligner à Droite"});
