CKEDITOR.plugins.setLang("justify","en-gb",{block:"Justify",center:"Centre",left:"Align Left",right:"Align Right"});
