CKEDITOR.plugins.setLang("justify","it",{block:"Giustifica",center:"Centra",left:"Allinea a sinistra",right:"Allinea a destra"});
