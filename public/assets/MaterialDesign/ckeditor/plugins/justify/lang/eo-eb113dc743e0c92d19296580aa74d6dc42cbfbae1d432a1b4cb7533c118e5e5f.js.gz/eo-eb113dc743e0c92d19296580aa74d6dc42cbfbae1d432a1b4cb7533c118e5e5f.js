CKEDITOR.plugins.setLang("justify","eo",{block:"Ĝisrandigi Ambaŭflanke",center:"Centrigi",left:"Ĝisrandigi maldekstren",right:"Ĝisrandigi dekstren"});
