CKEDITOR.plugins.setLang("justify","th",{block:"จัดพอดีหน้ากระดาษ",center:"จัดกึ่งกลาง",left:"จัดชิดซ้าย",right:"จัดชิดขวา"});
