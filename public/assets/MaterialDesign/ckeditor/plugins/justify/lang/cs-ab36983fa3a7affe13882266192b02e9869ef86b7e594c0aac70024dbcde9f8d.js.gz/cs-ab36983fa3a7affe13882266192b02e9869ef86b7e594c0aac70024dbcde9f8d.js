CKEDITOR.plugins.setLang("justify","cs",{block:"Zarovnat do bloku",center:"Zarovnat na střed",left:"Zarovnat vlevo",right:"Zarovnat vpravo"});
