CKEDITOR.plugins.setLang("justify","hr",{block:"Blok poravnanje",center:"Središnje poravnanje",left:"Lijevo poravnanje",right:"Desno poravnanje"});
