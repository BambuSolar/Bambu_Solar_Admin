CKEDITOR.plugins.setLang("justify","de-ch",{block:"Blocksatz",center:"Zentriert",left:"Linksbündig",right:"Rechtsbündig"});
