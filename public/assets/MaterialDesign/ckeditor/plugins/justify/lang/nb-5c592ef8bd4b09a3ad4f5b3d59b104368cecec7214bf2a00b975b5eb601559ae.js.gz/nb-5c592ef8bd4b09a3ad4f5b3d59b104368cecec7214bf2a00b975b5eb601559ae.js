CKEDITOR.plugins.setLang("justify","nb",{block:"Blokkjuster",center:"Midtstill",left:"Venstrejuster",right:"Høyrejuster"});
