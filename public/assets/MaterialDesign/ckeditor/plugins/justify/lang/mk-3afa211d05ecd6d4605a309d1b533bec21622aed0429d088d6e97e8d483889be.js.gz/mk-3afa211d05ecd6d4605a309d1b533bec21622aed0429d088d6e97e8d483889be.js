CKEDITOR.plugins.setLang("justify","mk",{block:"Justify",center:"Во средина",left:"Align Left",right:"Align Right"});
