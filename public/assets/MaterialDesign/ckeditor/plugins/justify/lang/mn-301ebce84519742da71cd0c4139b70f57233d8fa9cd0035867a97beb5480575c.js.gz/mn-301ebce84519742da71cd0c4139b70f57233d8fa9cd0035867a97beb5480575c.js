CKEDITOR.plugins.setLang("justify","mn",{block:"Тэгшлэх",center:"Голлуулах",left:"Зүүн талд тулгах",right:"Баруун талд тулгах"});
