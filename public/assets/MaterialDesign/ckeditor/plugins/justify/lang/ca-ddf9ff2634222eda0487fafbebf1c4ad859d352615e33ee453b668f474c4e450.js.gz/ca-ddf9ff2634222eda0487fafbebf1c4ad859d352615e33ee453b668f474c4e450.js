CKEDITOR.plugins.setLang("justify","ca",{block:"Justificat",center:"Centrat",left:"Alinea a l'esquerra",right:"Alinea a la dreta"});
