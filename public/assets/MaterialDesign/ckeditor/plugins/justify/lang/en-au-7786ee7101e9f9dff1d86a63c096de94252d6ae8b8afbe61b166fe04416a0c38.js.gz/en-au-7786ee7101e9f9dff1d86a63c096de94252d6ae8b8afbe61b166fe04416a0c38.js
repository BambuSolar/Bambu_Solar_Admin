CKEDITOR.plugins.setLang("justify","en-au",{block:"Justify",center:"Centre",left:"Align Left",right:"Align Right"});
