CKEDITOR.plugins.setLang("justify","bg",{block:"Двустранно подравняване",center:"Център",left:"Подравни в ляво",right:"Подравни в дясно"});
