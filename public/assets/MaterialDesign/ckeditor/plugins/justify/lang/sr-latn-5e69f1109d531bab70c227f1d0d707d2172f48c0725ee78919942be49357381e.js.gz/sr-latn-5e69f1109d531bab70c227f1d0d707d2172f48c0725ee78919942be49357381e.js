CKEDITOR.plugins.setLang("justify","sr-latn",{block:"Obostrano ravnanje",center:"Centriran tekst",left:"Levo ravnanje",right:"Desno ravnanje"});
