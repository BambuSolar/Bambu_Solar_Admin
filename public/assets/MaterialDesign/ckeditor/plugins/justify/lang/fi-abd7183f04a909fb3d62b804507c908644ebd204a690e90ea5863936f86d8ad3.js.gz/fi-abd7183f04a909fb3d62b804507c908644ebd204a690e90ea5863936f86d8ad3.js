CKEDITOR.plugins.setLang("justify","fi",{block:"Tasaa molemmat reunat",center:"Keskitä",left:"Tasaa vasemmat reunat",right:"Tasaa oikeat reunat"});
