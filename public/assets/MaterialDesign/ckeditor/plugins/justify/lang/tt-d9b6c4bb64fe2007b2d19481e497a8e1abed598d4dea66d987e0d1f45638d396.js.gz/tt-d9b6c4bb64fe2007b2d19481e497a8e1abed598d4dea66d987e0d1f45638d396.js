CKEDITOR.plugins.setLang("justify","tt",{block:"Киңлеккә карап тигезләү",center:"Үзәккә тигезләү",left:"Сул як кырыйдан тигезләү",right:"Уң як кырыйдан тигезләү"});
