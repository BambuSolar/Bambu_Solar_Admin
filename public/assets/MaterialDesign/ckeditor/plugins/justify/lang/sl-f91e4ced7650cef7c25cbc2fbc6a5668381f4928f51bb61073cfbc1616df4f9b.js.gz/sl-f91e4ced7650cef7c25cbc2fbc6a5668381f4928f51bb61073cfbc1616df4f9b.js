CKEDITOR.plugins.setLang("justify","sl",{block:"Obojestranska poravnava",center:"Sredinska poravnava",left:"Leva poravnava",right:"Desna poravnava"});
