CKEDITOR.plugins.setLang("justify","fa",{block:"بلوک چین",center:"میان چین",left:"چپ چین",right:"راست چین"});
