CKEDITOR.plugins.setLang("justify","af",{block:"Uitvul",center:"Sentreer",left:"Links oplyn",right:"Regs oplyn"});
