CKEDITOR.plugins.setLang("justify","ku",{block:"هاوستوونی",center:"ناوەڕاست",left:"بەهێڵ کردنی چەپ",right:"بەهێڵ کردنی ڕاست"});
