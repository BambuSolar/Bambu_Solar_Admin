CKEDITOR.plugins.setLang("justify","bs",{block:"Puno poravnanje",center:"Centralno poravnanje",left:"Lijevo poravnanje",right:"Desno poravnanje"});
