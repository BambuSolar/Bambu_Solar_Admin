CKEDITOR.plugins.setLang("justify","tr",{block:"İki Kenara Yaslanmış",center:"Ortalanmış",left:"Sola Dayalı",right:"Sağa Dayalı"});
