CKEDITOR.plugins.setLang("justify","el",{block:"Πλήρης Στοίχιση",center:"Στο Κέντρο",left:"Στοίχιση Αριστερά",right:"Στοίχιση Δεξιά"});
