CKEDITOR.plugins.setLang("smiley","ru",{options:"Выбор смайла",title:"Вставить смайл",toolbar:"Смайлы"});
