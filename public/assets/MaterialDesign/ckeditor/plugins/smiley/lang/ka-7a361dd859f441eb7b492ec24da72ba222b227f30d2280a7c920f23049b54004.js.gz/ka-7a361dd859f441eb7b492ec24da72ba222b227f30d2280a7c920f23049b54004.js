CKEDITOR.plugins.setLang("smiley","ka",{options:"სიცილაკის პარამეტრები",title:"სიცილაკის ჩასმა",toolbar:"სიცილაკები"});
