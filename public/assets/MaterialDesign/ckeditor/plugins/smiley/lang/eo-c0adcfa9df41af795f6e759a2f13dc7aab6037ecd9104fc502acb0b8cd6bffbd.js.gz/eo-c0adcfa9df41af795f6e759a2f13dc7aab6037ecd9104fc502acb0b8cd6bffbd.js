CKEDITOR.plugins.setLang("smiley","eo",{options:"Opcioj pri mienvinjetoj",title:"Enmeti Mienvinjeton",toolbar:"Mienvinjeto"});
