CKEDITOR.plugins.setLang("smiley","cy",{options:"Opsiynau Gwenogluniau",title:"Mewnosod Gwenoglun",toolbar:"Gwenoglun"});
