CKEDITOR.plugins.setLang("smiley","tr",{options:"İfade Seçenekleri",title:"İfade Ekle",toolbar:"İfade"});
