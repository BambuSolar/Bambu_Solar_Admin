CKEDITOR.plugins.setLang("smiley","cs",{options:"Nastavení smajlíků",title:"Vkládání smajlíků",toolbar:"Smajlíci"});
