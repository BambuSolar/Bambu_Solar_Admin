CKEDITOR.plugins.setLang("smiley","mn",{options:"Smiley Options",title:"Тодорхойлолт оруулах",toolbar:"Тодорхойлолт"});
