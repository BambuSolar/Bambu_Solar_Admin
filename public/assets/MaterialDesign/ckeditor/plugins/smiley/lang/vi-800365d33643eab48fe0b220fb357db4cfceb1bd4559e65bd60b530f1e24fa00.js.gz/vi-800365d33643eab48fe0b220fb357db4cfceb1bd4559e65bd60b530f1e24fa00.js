CKEDITOR.plugins.setLang("smiley","vi",{options:"Tùy chọn hình  biểu lộ cảm xúc",title:"Chèn hình biểu lộ cảm xúc (mặt cười)",toolbar:"Hình biểu lộ cảm xúc (mặt cười)"});
