CKEDITOR.plugins.setLang("smiley","fa",{options:"گزینه​های خندانک",title:"گنجاندن خندانک",toolbar:"خندانک"});
