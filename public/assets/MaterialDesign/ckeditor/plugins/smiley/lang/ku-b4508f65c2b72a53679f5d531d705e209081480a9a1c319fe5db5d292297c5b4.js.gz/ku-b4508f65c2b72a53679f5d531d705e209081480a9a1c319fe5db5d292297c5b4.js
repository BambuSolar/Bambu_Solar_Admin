CKEDITOR.plugins.setLang("smiley","ku",{options:"هەڵبژاردەی زەردەخەنه",title:"دانانی زەردەخەنەیەك",toolbar:"زەردەخەنه"});
