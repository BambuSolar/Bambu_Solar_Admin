CKEDITOR.plugins.setLang("smiley","bs",{options:"Smiley Options",title:"Ubaci smješka",toolbar:"Smješko"});
