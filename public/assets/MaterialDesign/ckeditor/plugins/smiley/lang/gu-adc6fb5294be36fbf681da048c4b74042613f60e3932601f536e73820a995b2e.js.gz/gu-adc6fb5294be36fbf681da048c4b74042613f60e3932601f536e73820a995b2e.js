CKEDITOR.plugins.setLang("smiley","gu",{options:"સમ્ય્લી વિકલ્પો",title:"સ્માઇલી  પસંદ કરો",toolbar:"સ્માઇલી"});
