CKEDITOR.plugins.setLang("smiley","sq",{options:"Opsionet e Ikonave",title:"Vendos Ikonë",toolbar:"Ikona"});
