CKEDITOR.plugins.setLang("smiley","sk",{options:"Možnosti smajlíkov",title:"Vložiť smajlíka",toolbar:"Smajlíky"});
