CKEDITOR.plugins.setLang("smiley","sr-latn",{options:"Smiley Options",title:"Unesi smajlija",toolbar:"Smajli"});
