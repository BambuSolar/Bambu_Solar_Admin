CKEDITOR.plugins.setLang("smiley","gl",{options:"Opcións de emoticonas",title:"Inserir unha emoticona",toolbar:"Emoticona"});
