CKEDITOR.plugins.setLang("smiley","fr",{options:"Options des frimousses",title:"Insérer une frimousse",toolbar:"Frimousse"});
