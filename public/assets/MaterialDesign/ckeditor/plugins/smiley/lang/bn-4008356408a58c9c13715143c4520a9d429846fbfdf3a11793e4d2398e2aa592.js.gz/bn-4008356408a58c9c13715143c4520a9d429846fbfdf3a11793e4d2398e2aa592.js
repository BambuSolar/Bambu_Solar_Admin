CKEDITOR.plugins.setLang("smiley","bn",{options:"Smiley Options",title:"স্মাইলী যুক্ত কর",toolbar:"স্মাইলী"});
