CKEDITOR.plugins.setLang("smiley","lt",{options:"Šypsenėlių nustatymai",title:"Įterpti veidelį",toolbar:"Veideliai"});
