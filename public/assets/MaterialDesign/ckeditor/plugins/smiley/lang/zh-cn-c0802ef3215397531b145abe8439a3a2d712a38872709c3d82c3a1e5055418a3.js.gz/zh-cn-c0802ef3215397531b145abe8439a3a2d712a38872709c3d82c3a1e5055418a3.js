CKEDITOR.plugins.setLang("smiley","zh-cn",{options:"表情图标选项",title:"插入表情图标",toolbar:"表情符"});
