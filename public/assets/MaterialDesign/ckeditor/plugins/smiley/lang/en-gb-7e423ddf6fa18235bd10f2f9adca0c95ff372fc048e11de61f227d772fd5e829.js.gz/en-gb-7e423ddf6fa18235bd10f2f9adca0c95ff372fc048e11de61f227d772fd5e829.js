CKEDITOR.plugins.setLang("smiley","en-gb",{options:"Smiley Options",title:"Insert a Smiley",toolbar:"Smiley"});
