CKEDITOR.plugins.setLang("smiley","no",{options:"Alternativer for smil",title:"Sett inn smil",toolbar:"Smil"});
