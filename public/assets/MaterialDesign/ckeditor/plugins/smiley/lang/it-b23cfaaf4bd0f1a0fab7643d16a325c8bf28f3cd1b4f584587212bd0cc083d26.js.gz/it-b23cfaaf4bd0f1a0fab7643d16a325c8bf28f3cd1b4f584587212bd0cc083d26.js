CKEDITOR.plugins.setLang("smiley","it",{options:"Opzioni Smiley",title:"Inserisci emoticon",toolbar:"Emoticon"});
