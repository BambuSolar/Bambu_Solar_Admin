CKEDITOR.plugins.setLang("smiley","af",{options:"Lagbekkie opsies",title:"Voeg lagbekkie by",toolbar:"Lagbekkie"});
