CKEDITOR.plugins.setLang("smiley","th",{options:"ตัวเลือกไอคอนแสดงอารมณ์",title:"แทรกสัญลักษณ์สื่ออารมณ์",toolbar:"รูปสื่ออารมณ์"});
