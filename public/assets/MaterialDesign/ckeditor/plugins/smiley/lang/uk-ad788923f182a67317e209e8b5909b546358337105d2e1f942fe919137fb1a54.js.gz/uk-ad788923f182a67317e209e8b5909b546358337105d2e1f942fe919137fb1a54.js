CKEDITOR.plugins.setLang("smiley","uk",{options:"Опції смайликів",title:"Вставити смайлик",toolbar:"Смайлик"});
