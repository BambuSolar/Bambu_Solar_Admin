CKEDITOR.plugins.setLang("smiley","de",{options:"Smiley-Optionen",title:"Smiley auswählen",toolbar:"Smiley"});
