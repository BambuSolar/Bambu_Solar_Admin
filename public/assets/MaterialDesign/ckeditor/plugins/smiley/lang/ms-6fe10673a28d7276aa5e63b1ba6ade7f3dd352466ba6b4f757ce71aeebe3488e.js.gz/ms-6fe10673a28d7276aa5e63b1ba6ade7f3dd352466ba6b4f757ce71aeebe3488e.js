CKEDITOR.plugins.setLang("smiley","ms",{options:"Smiley Options",title:"Masukkan Smiley",toolbar:"Smiley"});
