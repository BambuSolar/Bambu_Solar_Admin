CKEDITOR.plugins.setLang("smiley","mk",{options:"Smiley Options",title:"Insert a Smiley",toolbar:"Smiley"});
