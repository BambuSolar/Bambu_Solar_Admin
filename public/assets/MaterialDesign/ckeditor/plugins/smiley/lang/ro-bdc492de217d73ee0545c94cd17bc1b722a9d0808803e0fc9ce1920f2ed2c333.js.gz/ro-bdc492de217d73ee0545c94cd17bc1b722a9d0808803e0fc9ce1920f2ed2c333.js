CKEDITOR.plugins.setLang("smiley","ro",{options:"Opțiuni figuri expresive",title:"Inserează o figură expresivă (Emoticon)",toolbar:"Figură expresivă (Emoticon)"});
