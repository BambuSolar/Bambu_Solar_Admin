CKEDITOR.plugins.setLang("smiley","id",{options:"Opsi Smiley",title:"Sisip sebuah Smiley",toolbar:"Smiley"});
