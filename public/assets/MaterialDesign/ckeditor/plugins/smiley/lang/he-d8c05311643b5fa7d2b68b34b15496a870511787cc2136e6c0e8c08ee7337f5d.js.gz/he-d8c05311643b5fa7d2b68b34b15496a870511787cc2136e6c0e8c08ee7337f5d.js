CKEDITOR.plugins.setLang("smiley","he",{options:"אפשרויות סמיילים",title:"הוספת סמיילי",toolbar:"סמיילי"});
