CKEDITOR.plugins.setLang("smiley","ko",{options:"이모티콘 옵션",title:"이모티콘 삽입",toolbar:"이모티콘"});
