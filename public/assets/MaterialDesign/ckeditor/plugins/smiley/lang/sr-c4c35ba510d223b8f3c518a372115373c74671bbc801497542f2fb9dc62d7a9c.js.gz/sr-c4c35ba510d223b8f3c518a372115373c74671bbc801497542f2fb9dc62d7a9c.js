CKEDITOR.plugins.setLang("smiley","sr",{options:"Smiley Options",title:"Унеси смајлија",toolbar:"Смајли"});
