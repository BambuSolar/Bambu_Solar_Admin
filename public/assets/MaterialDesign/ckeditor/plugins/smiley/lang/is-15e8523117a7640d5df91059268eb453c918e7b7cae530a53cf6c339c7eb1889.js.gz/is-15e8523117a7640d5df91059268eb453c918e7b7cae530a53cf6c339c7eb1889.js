CKEDITOR.plugins.setLang("smiley","is",{options:"Smiley Options",title:"Velja svip",toolbar:"Svipur"});
