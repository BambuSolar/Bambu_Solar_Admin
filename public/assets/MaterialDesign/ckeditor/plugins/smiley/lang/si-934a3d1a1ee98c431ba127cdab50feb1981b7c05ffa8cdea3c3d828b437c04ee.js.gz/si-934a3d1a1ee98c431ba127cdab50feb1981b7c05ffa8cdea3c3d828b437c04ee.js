CKEDITOR.plugins.setLang("smiley","si",{options:"හාස්‍ය විකල්ප",title:"හාස්‍යන් ඇතුලත් කිරීම",toolbar:"හාස්‍යන්"});
