CKEDITOR.plugins.setLang("smiley","pt",{options:"Opções de Emoticons",title:"Inserir um Emoticon",toolbar:"Emoticons"});
