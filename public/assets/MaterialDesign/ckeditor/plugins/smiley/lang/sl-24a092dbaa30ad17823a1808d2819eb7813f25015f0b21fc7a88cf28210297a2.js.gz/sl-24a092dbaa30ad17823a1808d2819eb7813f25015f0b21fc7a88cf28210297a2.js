CKEDITOR.plugins.setLang("smiley","sl",{options:"Možnosti Smeška",title:"Vstavi smeška",toolbar:"Smeško"});
