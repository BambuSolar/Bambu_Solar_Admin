CKEDITOR.plugins.setLang("smiley","ar",{options:"خصائص الإبتسامات",title:"إدراج ابتسامات",toolbar:"ابتسامات"});
