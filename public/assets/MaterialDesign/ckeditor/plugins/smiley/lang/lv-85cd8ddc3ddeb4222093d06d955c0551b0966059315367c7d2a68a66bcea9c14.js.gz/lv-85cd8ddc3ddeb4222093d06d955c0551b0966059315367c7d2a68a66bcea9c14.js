CKEDITOR.plugins.setLang("smiley","lv",{options:"Smaidiņu uzstādījumi",title:"Ievietot smaidiņu",toolbar:"Smaidiņi"});
