CKEDITOR.plugins.setLang("smiley","de-ch",{options:"Smiley-Optionen",title:"Smiley auswählen",toolbar:"Smiley"});
