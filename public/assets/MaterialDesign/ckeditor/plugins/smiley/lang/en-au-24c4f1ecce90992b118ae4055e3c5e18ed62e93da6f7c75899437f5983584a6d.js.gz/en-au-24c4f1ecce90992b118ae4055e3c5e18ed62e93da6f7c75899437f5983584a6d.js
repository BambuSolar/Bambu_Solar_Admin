CKEDITOR.plugins.setLang("smiley","en-au",{options:"Smiley Options",title:"Insert a Smiley",toolbar:"Smiley"});
