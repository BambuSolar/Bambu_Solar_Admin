CKEDITOR.plugins.setLang("smiley","es",{options:"Opciones de emoticonos",title:"Insertar un Emoticon",toolbar:"Emoticonos"});
