CKEDITOR.plugins.setLang("smiley","ja",{options:"絵文字オプション",title:"顔文字挿入",toolbar:"絵文字"});
