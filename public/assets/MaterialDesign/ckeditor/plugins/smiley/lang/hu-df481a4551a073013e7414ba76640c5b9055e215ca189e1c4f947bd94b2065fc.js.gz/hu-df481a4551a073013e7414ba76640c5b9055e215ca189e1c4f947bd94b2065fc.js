CKEDITOR.plugins.setLang("smiley","hu",{options:"Hangulatjel opciók",title:"Hangulatjel beszúrása",toolbar:"Hangulatjelek"});
