CKEDITOR.plugins.setLang("smiley","bg",{options:"Опции за усмивката",title:"Вмъкване на усмивка",toolbar:"Усмивка"});
