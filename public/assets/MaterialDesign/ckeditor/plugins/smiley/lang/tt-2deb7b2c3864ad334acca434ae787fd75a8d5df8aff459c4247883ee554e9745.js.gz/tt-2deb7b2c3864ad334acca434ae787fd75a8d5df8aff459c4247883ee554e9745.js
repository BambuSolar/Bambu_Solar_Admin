CKEDITOR.plugins.setLang("smiley","tt",{options:"Смайл көйләүләре",title:"Смайл өстәү",toolbar:"Смайл"});
