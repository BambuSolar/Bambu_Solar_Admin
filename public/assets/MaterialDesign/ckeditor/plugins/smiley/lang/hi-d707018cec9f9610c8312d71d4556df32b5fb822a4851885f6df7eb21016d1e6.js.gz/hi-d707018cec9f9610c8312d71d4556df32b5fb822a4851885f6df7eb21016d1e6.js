CKEDITOR.plugins.setLang("smiley","hi",{options:"Smiley Options",title:"स्माइली इन्सर्ट करें",toolbar:"स्माइली"});
