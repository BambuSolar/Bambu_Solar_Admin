CKEDITOR.plugins.setLang("smiley","fr-ca",{options:"Options d'émoticônes",title:"Insérer un émoticône",toolbar:"Émoticône"});
