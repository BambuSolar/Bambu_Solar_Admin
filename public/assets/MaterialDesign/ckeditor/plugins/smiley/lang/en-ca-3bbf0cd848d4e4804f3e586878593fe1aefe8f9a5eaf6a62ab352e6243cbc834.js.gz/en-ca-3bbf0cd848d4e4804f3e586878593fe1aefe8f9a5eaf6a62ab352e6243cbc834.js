CKEDITOR.plugins.setLang("smiley","en-ca",{options:"Smiley Options",title:"Insert a Smiley",toolbar:"Smiley"});
