CKEDITOR.plugins.setLang("smiley","fo",{options:"Møguleikar fyri Smiley",title:"Vel Smiley",toolbar:"Smiley"});
