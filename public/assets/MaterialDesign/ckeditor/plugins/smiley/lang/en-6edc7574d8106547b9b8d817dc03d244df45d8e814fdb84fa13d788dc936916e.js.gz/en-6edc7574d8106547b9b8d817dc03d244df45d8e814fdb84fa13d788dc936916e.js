CKEDITOR.plugins.setLang("smiley","en",{options:"Smiley Options",title:"Insert a Smiley",toolbar:"Smiley"});
