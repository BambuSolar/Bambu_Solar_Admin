CKEDITOR.plugins.setLang("smiley","pt-br",{options:"Opções de Emoticons",title:"Inserir Emoticon",toolbar:"Emoticon"});
