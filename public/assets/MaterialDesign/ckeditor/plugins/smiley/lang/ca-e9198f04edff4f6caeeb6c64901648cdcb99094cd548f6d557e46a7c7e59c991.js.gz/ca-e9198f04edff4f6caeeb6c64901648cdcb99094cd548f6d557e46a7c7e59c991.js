CKEDITOR.plugins.setLang("smiley","ca",{options:"Opcions d'emoticones",title:"Insereix una icona",toolbar:"Icona"});
