CKEDITOR.plugins.setLang("smiley","pl",{options:"Opcje emotikonów",title:"Wstaw emotikona",toolbar:"Emotikony"});
