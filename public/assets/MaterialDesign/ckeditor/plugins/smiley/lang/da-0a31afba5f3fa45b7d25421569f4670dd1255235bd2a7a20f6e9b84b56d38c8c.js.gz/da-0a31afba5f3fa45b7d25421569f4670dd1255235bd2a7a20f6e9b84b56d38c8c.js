CKEDITOR.plugins.setLang("smiley","da",{options:"Smileymuligheder",title:"Vælg smiley",toolbar:"Smiley"});
