CKEDITOR.plugins.setLang("smiley","et",{options:"Emotikonide valikud",title:"Sisesta emotikon",toolbar:"Emotikon"});
