CKEDITOR.plugins.setLang("smiley","nl",{options:"Smiley opties",title:"Smiley invoegen",toolbar:"Smiley"});
