CKEDITOR.plugins.setLang("smiley","el",{options:"Επιλογές Φατσούλων",title:"Εισάγετε μια Φατσούλα",toolbar:"Φατσούλα"});
