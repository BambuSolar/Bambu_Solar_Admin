CKEDITOR.plugins.setLang("smiley","nb",{options:"Alternativer for smil",title:"Sett inn smil",toolbar:"Smil"});
