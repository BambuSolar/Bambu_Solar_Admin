CKEDITOR.plugins.setLang("smiley","sv",{options:"Smileyinställningar",title:"Infoga smiley",toolbar:"Smiley"});
