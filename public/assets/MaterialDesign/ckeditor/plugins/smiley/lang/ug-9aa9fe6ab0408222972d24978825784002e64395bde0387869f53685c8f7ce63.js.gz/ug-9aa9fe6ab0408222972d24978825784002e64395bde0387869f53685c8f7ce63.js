CKEDITOR.plugins.setLang("smiley","ug",{options:"چىراي ئىپادە سىنبەلگە تاللانمىسى",title:"چىراي ئىپادە سىنبەلگە قىستۇر",toolbar:"چىراي ئىپادە"});
