CKEDITOR.plugins.setLang("smiley","fi",{options:"Hymiön ominaisuudet",title:"Lisää hymiö",toolbar:"Hymiö"});
