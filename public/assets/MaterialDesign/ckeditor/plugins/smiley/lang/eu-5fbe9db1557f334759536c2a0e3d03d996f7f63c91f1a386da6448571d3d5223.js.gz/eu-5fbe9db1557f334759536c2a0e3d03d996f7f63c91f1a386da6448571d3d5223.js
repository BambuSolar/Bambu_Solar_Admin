CKEDITOR.plugins.setLang("smiley","eu",{options:"Aurpegieren aukerak",title:"Txertatu aurpegiera",toolbar:"Aurpegierak"});
