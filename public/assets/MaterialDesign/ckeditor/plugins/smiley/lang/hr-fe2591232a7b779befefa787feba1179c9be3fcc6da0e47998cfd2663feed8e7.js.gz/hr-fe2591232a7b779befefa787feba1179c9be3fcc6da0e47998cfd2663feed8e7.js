CKEDITOR.plugins.setLang("smiley","hr",{options:"Opcije smješka",title:"Ubaci smješka",toolbar:"Smješko"});
